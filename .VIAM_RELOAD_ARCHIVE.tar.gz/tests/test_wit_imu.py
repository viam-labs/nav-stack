"""Tests for WitMotion protocol, IMU shm, and wit-imu helpers."""

from __future__ import annotations

import math
import struct

import pytest

from src.imu.wit_protocol import (
    CMD_UNLOCK,
    TYPE_ACCEL,
    TYPE_GYRO,
    TYPE_ORIENT,
    WitError,
    WitStreamParser,
    config_commands,
    scale_le_u16,
)
from src.shm import imushm


def _frame(typ: int, values_le: bytes) -> bytes:
    """One wit-motion ``ReadString('U')`` line: type|8data|cs|0x55 (11 bytes)."""
    assert len(values_le) == 8
    wire = bytes([0x55, typ]) + values_le
    checksum = sum(wire) & 0xFF
    return bytes([typ]) + values_le + bytes([checksum, 0x55])


def _u16_pair(value: float, r: float) -> bytes:
    """Inverse of scale_le_u16 for test payloads (approximate)."""
    # scale maps uint16/32768 * r into [-r,r) after wrap — use mid-scale 0.
    # For 0: x=0 -> uint such that after transform ~0. Use 0x0000.
    if abs(value) < 1e-9:
        return b"\x00\x00"
    # Encode: want result ≈ value. From scale: x = u/32768 * r; then wrap.
    # Simplified: u = (value / r) * 32768 for value in [-r, r).
    u = int(round((value / r) * 32768.0)) & 0xFFFF
    return struct.pack("<H", u)


def test_scale_le_u16_zero():
    assert scale_le_u16(0, 0, 180.0) == pytest.approx(0.0)


def test_parser_accepts_classic_wire_stream_like_device():
    """Device wire is 0x55|type|data|cs; Go ReadString consumes sync then 11-byte lines."""
    parser = WitStreamParser()
    yaw = struct.pack("<h", 16384)  # +90°
    payload = b"\x00\x00\x00\x00" + yaw + b"\x00\x00"
    # Two classic frames back-to-back (second sync terminates the first Go line).
    wire = b"".join(
        [
            bytes([0x55, TYPE_ORIENT])
            + payload
            + bytes([sum(bytes([0x55, TYPE_ORIENT]) + payload) & 0xFF]),
            bytes([0x55, TYPE_GYRO])
            + (b"\x00" * 8)
            + bytes([sum(bytes([0x55, TYPE_GYRO]) + b"\x00" * 8) & 0xFF]),
        ]
    )
    n = parser.feed(wire)
    assert n >= 1
    assert parser.sample.yaw == pytest.approx(math.radians(90.0))


def test_parser_orient_yaw_90_matches_wit_motion_scale():
    """Official Wit scale (/32768*180) — same as viam-modules/wit-motion."""
    parser = WitStreamParser()
    # Signed int16 for +90°: 90/180*32768 = 16384.
    yaw = struct.pack("<h", 16384)
    payload = b"\x00\x00\x00\x00" + yaw + b"\x00\x00"
    n = parser.feed(_frame(TYPE_ORIENT, payload))
    assert n == 1
    assert parser.sample.yaw == pytest.approx(math.radians(90.0))


def test_parser_rejects_bad_checksum():
    """Checksum is the low 8 bits of the first 10 wire bytes; a mismatch is not a packet."""
    parser = WitStreamParser()
    good = _frame(TYPE_GYRO, b"\x00" * 8)
    bad = bytearray(good)
    bad[9] ^= 0xFF
    assert parser.feed(bytes(bad)) == 0
    assert parser.sample.packets == 0
    assert parser.sample.gyro_packets == 0
    assert parser.feed(good) == 1
    assert parser.sample.gyro_packets == 1


def test_parser_rejects_lcus_ascii():
    """An LCUS-2 ``CH1:`` / ``CH2:`` reply must not count as WitMotion frames."""
    parser = WitStreamParser()
    # 0x51 is a real accel type; the rest is relay text plus a sync. Checksum fails.
    line = bytes([TYPE_ACCEL]) + b"CH1:OFF\n" + bytes([0x00, 0x55])
    assert len(line) == 11
    assert line[9] != ((0x55 + sum(line[:9])) & 0xFF)
    blob = b"CH1: OFF\r\nCH2: OFF\r\n" + line + bytes([0x55]) * 4
    assert parser.feed(blob) == 0
    assert parser.sample.packets == 0


def test_parser_accel_gyro_orient():
    parser = WitStreamParser()
    # Three frames: accel, gyro, orient around zero.
    stream = b"".join(
        [
            _frame(TYPE_ACCEL, b"\x00\x00\x00\x00\x00\x00\x00\x00"),
            _frame(TYPE_GYRO, b"\x00\x00\x00\x00\x00\x00\x00\x00"),
            _frame(TYPE_ORIENT, b"\x00\x00\x00\x00\x00\x00\x00\x00"),
        ]
    )
    n = parser.feed(stream)
    assert n == 3
    assert parser.sample.packets == 3
    assert parser.sample.ax == pytest.approx(0.0)
    assert parser.sample.gx == pytest.approx(0.0)
    assert parser.sample.yaw == pytest.approx(0.0)


def test_imushm_pack_unpack():
    payload = imushm.pack_sample(
        ax=1.0,
        ay=2.0,
        az=9.8,
        gx=0.1,
        gy=0.2,
        gz=3.0,
        roll=0.01,
        pitch=0.02,
        yaw=1.23,
        has_mag=True,
        mx=10.0,
        my=11.0,
        mz=12.0,
    )
    got = imushm.unpack_sample(payload, timestamp_ns=123)
    assert got.ax == pytest.approx(1.0)
    assert got.gz == pytest.approx(3.0)
    assert got.yaw == pytest.approx(1.23)
    assert got.has_mag is True
    assert got.mx == pytest.approx(10.0)
    assert got.timestamp_ns == 123


@pytest.mark.skipif(
    __import__("sys").platform != "linux",
    reason="POSIX shm writer zero-fill differs on macOS CI",
)
def test_imushm_roundtrip():
    name = "/viam-imu-test-navstack"
    w = imushm.Writer(name, region_size=4096)
    try:
        sample = imushm.ImuShmSample(
            ax=1.0,
            ay=2.0,
            az=9.8,
            gx=0.1,
            gy=0.2,
            gz=3.0,
            roll=0.01,
            pitch=0.02,
            yaw=1.23,
            has_mag=False,
        )
        w.write_sample(sample)
        r = imushm.Reader(name, region_size=4096)
        try:
            got = r.read_latest(max_age_s=2.0)
            assert got is not None
            assert got.ax == pytest.approx(1.0)
            assert got.gz == pytest.approx(3.0)
            assert got.yaw == pytest.approx(1.23)
        finally:
            r.close()
    finally:
        w.close()


def test_serial_ports_prefer_by_path_for_imu():
    from src.lidar.serial_ports import list_candidate_serial_ports

    # Just ensure both modes return lists (may be empty on macOS CI).
    a = list_candidate_serial_ports(prefer_cp210=True)
    b = list_candidate_serial_ports(prefer_cp210=False)
    assert isinstance(a, list)
    assert isinstance(b, list)


def test_parser_yaw_decode_matches_datasheet_and_exposes_raw():
    """Datasheet: Yaw = ((YawH<<8)|YawL)/32768*180 deg. 169.14 -> 178.86 must
    decode 1:1 (no extra scaling), and the raw u16 is exposed for verification."""
    parser = WitStreamParser()
    for deg in (169.14, 178.86, -102.31, 90.0):
        payload = b"\x00\x00\x00\x00" + _u16_pair(deg, 180.0) + b"\x00\x00"
        assert parser.feed(_frame(TYPE_ORIENT, payload)) == 1
        s = parser.sample
        assert s.yaw_deg_decoded == pytest.approx(deg, abs=0.01)
        assert math.degrees(s.yaw) == pytest.approx(deg, abs=0.01)
        assert s.yaw_raw_u16 == int(round(deg / 180.0 * 32768.0)) & 0xFFFF
    assert parser.sample.angle_packets == 4
    # A 90 deg physical turn must move decoded yaw 90 deg.
    a = scale_le_u16(*_u16_pair(169.14, 180.0), 180.0)
    b = scale_le_u16(*_u16_pair(169.14 + 90.0 - 360.0, 180.0), 180.0)
    assert ((b - a + 180.0) % 360.0) - 180.0 == pytest.approx(90.0, abs=0.01)


def test_parser_gyro_decode_raw_and_counts():
    parser = WitStreamParser()
    payload = b"\x00\x00\x00\x00" + _u16_pair(45.0, 2000.0) + b"\x00\x00"
    parser.feed(_frame(TYPE_GYRO, payload))
    s = parser.sample
    assert s.gz == pytest.approx(45.0, abs=0.1)
    assert s.gz_raw_u16 == int(round(45.0 / 2000.0 * 32768.0))
    assert s.gyro_packets == 1


def test_config_commands_wit_register_protocol():
    assert config_commands("keep") == []
    assert config_commands("6axis") == [CMD_UNLOCK, bytes.fromhex("ffaa240100")]
    assert config_commands("9axis") == [CMD_UNLOCK, bytes.fromhex("ffaa240000")]
    assert config_commands("6axis", zero_yaw=True) == [
        CMD_UNLOCK,
        bytes.fromhex("ffaa240100"),
        bytes.fromhex("ffaa010400"),
    ]
    assert config_commands("keep", zero_yaw=True) == [
        CMD_UNLOCK,
        bytes.fromhex("ffaa010400"),
    ]
    # Never saves to flash.
    assert all(
        c != bytes.fromhex("ffaa000000")
        for c in config_commands("6axis", zero_yaw=True)
    )
    with pytest.raises(WitError):
        config_commands("3axis")


def test_wit_serial_configure_writes_sequence():
    from src.imu.wit_serial import WitSerial

    class _Port:
        def __init__(self):
            self.writes = []

        def write(self, b):
            self.writes.append(bytes(b))

        def flush(self):
            pass

    dev = WitSerial("/dev/null")
    dev._ser = _Port()  # noqa: SLF001
    n = dev.configure("6axis", zero_yaw=False)
    assert n == 2
    assert dev._ser.writes == [CMD_UNLOCK, bytes.fromhex("ffaa240100")]  # noqa: SLF001

    dev._ser = _Port()  # noqa: SLF001
    n = dev.configure("6axis", gyro_still_threshold_dps=0.05)
    assert n == 3
    assert dev._ser.writes[-1] == bytes.fromhex("ffaa613200")  # noqa: SLF001


def test_config_commands_gyro_still_threshold():
    # 0.05 deg/s -> 50 (0x0032), the WitMotion datasheet example frame.
    assert config_commands("keep", gyro_still_threshold_dps=0.05) == [
        CMD_UNLOCK,
        bytes.fromhex("ffaa613200"),
    ]
    assert config_commands("6axis", gyro_still_threshold_dps=0.05) == [
        CMD_UNLOCK,
        bytes.fromhex("ffaa240100"),
        bytes.fromhex("ffaa613200"),
    ]
    assert config_commands("keep", gyro_still_threshold_dps=1.0)[-1] == bytes.fromhex(
        "ffaa61e803"
    )
    assert config_commands("keep", gyro_still_threshold_dps=None) == []
    with pytest.raises(WitError):
        config_commands("keep", gyro_still_threshold_dps=-0.1)
    with pytest.raises(WitError):
        config_commands("keep", gyro_still_threshold_dps=70.0)


def test_open_first_working_skips_lcus2_relay():
    """A CH340 that answers CH1:/CH2: is closed and not claimed; the WIT is."""
    import src.imu.wit_serial as wit_serial
    from src.imu.wit_serial import WitSerial
    from src.lidar.serial_ports import claimed_owner

    relay = "/dev/serial/by-id/usb-1a86_USB_Serial-relay"
    imu = "/dev/serial/by-id/usb-1a86_USB_Serial-imu"
    opened = []

    class FakeSerial:
        def __init__(self, port=None, **kwargs):
            self.port = port
            self.baudrate = kwargs.get("baudrate")
            self.timeout = kwargs.get("timeout")
            self.parity = kwargs.get("parity")
            self.stopbits = kwargs.get("stopbits")
            self.dsrdtr = kwargs.get("dsrdtr", False)
            self.rtscts = kwargs.get("rtscts", False)
            self.xonxoff = kwargs.get("xonxoff", False)
            self.exclusive = kwargs.get("exclusive")
            self.dtr = True
            self.rts = True
            self.is_open = False
            self.writes = []
            self._buf = b""
            self.opened_as = None
            if port is not None:
                self.open()

        def open(self):
            self.is_open = True
            self.opened_as = (self.baudrate, self.dtr, self.rts)
            opened.append(self)

        def write(self, data):
            self.writes.append(bytes(data))
            return len(data)

        def flush(self):
            pass

        def close(self):
            self.is_open = False

        @property
        def in_waiting(self):
            return len(self._buf)

        def read(self, n=1):
            if not self._buf and self.port == relay and self.writes == [b"\xff"]:
                self._buf = b"CH1: OFF\r\nCH2: OFF\r\n"
            if not self._buf and self.port == imu and self.baudrate == 115200:
                self._buf = b"".join(_frame(TYPE_GYRO, b"\x00" * 8) for _ in range(4))
            chunk = self._buf[:n]
            self._buf = self._buf[n:]
            return chunk

    saved_serial = wit_serial._pyserial
    saved_listen = wit_serial._LCUS2_LISTEN_S
    wit_serial._pyserial = type(
        "M",
        (),
        {"Serial": FakeSerial, "PARITY_NONE": "N", "STOPBITS_ONE": 1},
    )
    wit_serial._LCUS2_LISTEN_S = 0.05
    try:
        dev = WitSerial.open_first_working([relay, imu], rounds=1)
        try:
            assert dev.port == imu
            assert claimed_owner(imu) == "imu"
            assert claimed_owner(relay) is None
        finally:
            dev.close()
    finally:
        wit_serial._pyserial = saved_serial
        wit_serial._LCUS2_LISTEN_S = saved_listen

    relay_opens = [s for s in opened if s.port == relay]
    assert relay_opens
    assert all(s.opened_as == (9600, False, False) for s in relay_opens)
    assert all(s.writes == [b"\xff"] for s in relay_opens)
    assert all(s.is_open is False for s in relay_opens)
    assert all(s.baudrate == 9600 for s in relay_opens)
    imu_probes = [s for s in opened if s.port == imu and s.baudrate == 9600]
    assert imu_probes
    assert all(s.opened_as == (9600, False, False) for s in imu_probes)
    assert any(s.port == imu and s.baudrate == 115200 for s in opened)


def test_lcus2_probe_constants():
    from src.imu.wit_serial import _LCUS2_BAUD, _LCUS2_LISTEN_S, _LCUS2_QUERY

    assert _LCUS2_BAUD == 9600
    assert _LCUS2_QUERY == b"\xff"
    assert _LCUS2_LISTEN_S == pytest.approx(0.25)


def test_wit_imu_gyro_still_threshold_attr():
    from src.models.wit_imu import (
        DEFAULT_GYRO_STILL_THRESHOLD_DPS,
        _parse_gyro_still_threshold,
    )

    assert _parse_gyro_still_threshold({}) == DEFAULT_GYRO_STILL_THRESHOLD_DPS == 0.05
    assert _parse_gyro_still_threshold({"gyro_still_threshold_dps": 0.2}) == 0.2
    assert _parse_gyro_still_threshold({"gyro_still_threshold_dps": None}) is None
    assert _parse_gyro_still_threshold({"gyro_still_threshold_dps": "keep"}) is None
    with pytest.raises(ValueError):
        _parse_gyro_still_threshold({"gyro_still_threshold_dps": 100})
