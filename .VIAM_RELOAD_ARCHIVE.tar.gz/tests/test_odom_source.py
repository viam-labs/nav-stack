import asyncio
import math

import pytest

pytest.importorskip("viam")
pytest.importorskip("viam.spatialmath")

from viam.components.movement_sensor import MovementSensor
from viam.proto.common import GeoPoint, Orientation, Vector3

from src.odom.source import (
    TypedMovementSensorOdom,
    TypedOdomConfig,
    read_typed_heading,
)


class FakeMovementSensor:
    """Minimal MovementSensor stand-in: typed getters + a call counter."""

    def __init__(
        self,
        *,
        angular_velocity=False,
        linear_acceleration=False,
        orientation=False,
        position=False,
        compass_heading=False,
        linear_velocity=False,
        av=(0.0, 0.0, 0.0),
        la=(0.0, 0.0, 0.0),
        lv=(0.0, 0.0, 0.0),
        orient=(0.0, 0.0, 1.0, 0.0),  # o_x, o_y, o_z, theta(deg): identity
        geo=(0.0, 0.0),  # (latitude, longitude)
        compass=0.0,
    ):
        self._props = MovementSensor.Properties(
            linear_acceleration_supported=linear_acceleration,
            angular_velocity_supported=angular_velocity,
            orientation_supported=orientation,
            position_supported=position,
            compass_heading_supported=compass_heading,
            linear_velocity_supported=linear_velocity,
        )
        self._av, self._la, self._lv = av, la, lv
        self._orient, self._geo, self._compass = orient, geo, compass
        self.calls = {}

    def _count(self, name):
        self.calls[name] = self.calls.get(name, 0) + 1

    async def get_properties(self, **kw):
        self._count("get_properties")
        return self._props

    async def get_angular_velocity(self, **kw):
        self._count("get_angular_velocity")
        return Vector3(x=self._av[0], y=self._av[1], z=self._av[2])

    async def get_linear_acceleration(self, **kw):
        self._count("get_linear_acceleration")
        return Vector3(x=self._la[0], y=self._la[1], z=self._la[2])

    async def get_linear_velocity(self, **kw):
        self._count("get_linear_velocity")
        return Vector3(x=self._lv[0], y=self._lv[1], z=self._lv[2])

    async def get_orientation(self, **kw):
        self._count("get_orientation")
        return Orientation(
            o_x=self._orient[0],
            o_y=self._orient[1],
            o_z=self._orient[2],
            theta=self._orient[3],
        )

    async def get_position(self, **kw):
        self._count("get_position")
        return GeoPoint(latitude=self._geo[0], longitude=self._geo[1]), 0.0

    async def get_compass_heading(self, **kw):
        self._count("get_compass_heading")
        return self._compass

    async def get_readings(self, **kw):
        self._count("get_readings")
        # No euler block by default — forces GetOrientation path (OV).
        return {}


def _read(sensor, cfg=None):
    reader = TypedMovementSensorOdom(sensor, cfg)
    return asyncio.run(reader.read()), reader


def test_imu_path_yaw_and_accel_ignores_position():
    # mid360-like IMU: gyro + accel + orientation + position, no linear velocity.
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_acceleration=True,
        orientation=True,
        position=True,
        av=(0.0, 0.0, 30.0),  # 30 deg/s yaw
        la=(0.7, -0.2, 9.81),  # forward accel + gravity on z (level)
    )
    reading, _ = _read(s)
    assert reading.vtheta == pytest.approx(math.radians(30.0))
    assert reading.vx == 0.0 and reading.vy == 0.0
    # Level orientation -> gravity has no horizontal component; ax/ay pass through.
    assert reading.ax == pytest.approx(0.7)
    assert reading.ay == pytest.approx(-0.2)
    assert reading.pose is None  # Position ignored by default (tar pit)
    assert reading.heading_rad is None
    assert "get_position" not in s.calls  # never even queried


def test_wheel_path_uses_linear_velocity_and_skips_accel():
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        linear_acceleration=True,
        orientation=True,
        av=(0.0, 0.0, 10.0),
        lv=(0.5, 0.0, 0.0),
        la=(1.0, 1.0, 9.81),
    )
    # Explicit ROS convention: +x forward (legacy test fixture).
    reading, _ = _read(s, TypedOdomConfig(velocity_convention="ros"))
    assert reading.vx == pytest.approx(0.5)
    assert reading.vy == pytest.approx(0.0)
    assert reading.vtheta == pytest.approx(math.radians(10.0))
    # Velocity-only path dead-reckons an odom pose from twist.
    assert reading.pose is not None
    # Wheel twist present -> never double-integrate accel.
    assert reading.ax is None and reading.ay is None
    assert "get_linear_acceleration" not in s.calls


def test_viam_y_forward_keeps_forward_on_vy():
    """Agilex / wheeled: GetLinearVelocity.y is forward; keep it on odom vy."""
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        av=(0.0, 0.0, 0.0),
        lv=(0.0, 0.009, 0.0),  # proto-style: only y set
    )
    reading, reader = _read(s, TypedOdomConfig(velocity_convention="viam"))
    assert reading.vx == pytest.approx(0.0, abs=1e-12)
    assert reading.vy == pytest.approx(0.009)
    assert reading.vtheta == pytest.approx(0.0)
    assert reading.pose is not None  # twist integrator
    dbg = reader.debug_dict()
    assert dbg["raw_lv_y"] == pytest.approx(0.009)
    assert dbg["raw_lv_x"] == pytest.approx(0.0)
    assert dbg["remapped"] is False
    assert dbg["raw_av_z_deg_s"] == pytest.approx(0.0)
    assert dbg["velocity_convention"] == "viam"


def test_viam_twist_integrator_moves_forward_in_ros_world():
    """Y-forward body vy integrates to +X in the ROS world (theta=0)."""
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        av=(0.0, 0.0, 0.0),
        lv=(0.0, 0.5, 0.0),
    )
    times = iter([100.0, 100.2])
    reader = TypedMovementSensorOdom(
        s,
        TypedOdomConfig(velocity_convention="viam"),
        clock=lambda: next(times),
    )
    first = asyncio.run(reader.read())
    second = asyncio.run(reader.read())
    assert first.pose is not None and second.pose is not None
    assert first.pose.x == pytest.approx(0.0)
    assert second.pose.x == pytest.approx(0.1)  # 0.5 m/s * 0.2 s
    assert second.pose.y == pytest.approx(0.0, abs=1e-12)
    assert second.vy == pytest.approx(0.5)


def test_twist_integrator_holds_last_velocity_across_read_gap():
    """A read gap (busy module loop) must not drop travel.

    Robot drives 0.3 m/s; reads at t=0, 0.1, then nothing until t=2.6. The old
    dt clamp (0.5 s) credited 0.15 m for a 2.5 s gap — map pose fell ~0.6 m
    behind the robot (overshoot until manual refine). Zero-order hold credits
    the held velocity across the gap.
    """
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        av=(0.0, 0.0, 0.0),
        lv=(0.0, 0.3, 0.0),
    )
    times = iter([100.0, 100.1, 102.6])
    reader = TypedMovementSensorOdom(
        s,
        TypedOdomConfig(velocity_convention="viam"),
        clock=lambda: next(times),
    )
    asyncio.run(reader.read())
    asyncio.run(reader.read())
    third = asyncio.run(reader.read())
    assert third.pose is not None
    # 0.1 s + 2.5 s at 0.3 m/s = 0.78 m
    assert third.pose.x == pytest.approx(0.78, abs=1e-6)
    dbg = reader.debug_dict()
    assert dbg["gap_hold_events"] == 1
    assert dbg["last_sample_gap_s"] == pytest.approx(2.5)


def test_twist_integrator_caps_hold_on_very_long_gap():
    """Past MAX_HOLD_GAP_S the held velocity is no longer trusted."""
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        lv=(0.0, 0.3, 0.0),
    )
    times = iter([100.0, 100.1, 110.1])  # 10 s gap
    reader = TypedMovementSensorOdom(
        s,
        TypedOdomConfig(velocity_convention="viam"),
        clock=lambda: next(times),
    )
    asyncio.run(reader.read())
    asyncio.run(reader.read())
    third = asyncio.run(reader.read())
    # 0.1 s + capped 3.0 s at 0.3 m/s = 0.93 m (not 3.03 m)
    assert third.pose.x == pytest.approx(0.03 + 0.3 * reader.MAX_HOLD_GAP_S, abs=1e-6)


def test_twist_integrator_stopped_robot_gap_adds_nothing():
    """Held velocity of zero across a gap stays put."""
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        lv=(0.0, 0.0, 0.0),
    )
    times = iter([100.0, 100.1, 104.0])
    reader = TypedMovementSensorOdom(
        s,
        TypedOdomConfig(velocity_convention="viam"),
        clock=lambda: next(times),
    )
    for _ in range(2):
        asyncio.run(reader.read())
    third = asyncio.run(reader.read())
    assert third.pose.x == pytest.approx(0.0, abs=1e-12)
    assert third.pose.y == pytest.approx(0.0, abs=1e-12)


def test_empty_angular_vector3_is_valid_zero_rate():
    s = FakeMovementSensor(
        angular_velocity=True,
        linear_velocity=True,
        av=(0.0, 0.0, 0.0),
        lv=(0.0, 0.0, 0.0),
    )
    reading, reader = _read(s, TypedOdomConfig(velocity_convention="viam"))
    assert reading.vtheta == 0.0
    assert reader.debug_dict()["raw_av_z_deg_s"] == 0.0


def test_snap_heading_from_orientation():
    # Orientation = pure yaw 90 deg (identity axis +z, theta 90).
    s = FakeMovementSensor(
        angular_velocity=True,
        orientation=True,
        orient=(0.0, 0.0, 1.0, 90.0),
    )
    reading, _ = _read(s, TypedOdomConfig(snap_heading=True))
    assert reading.heading_rad == pytest.approx(math.pi / 2)


def test_trust_pose_reads_geo_overload():
    s = FakeMovementSensor(
        angular_velocity=True,
        orientation=True,
        position=True,
        geo=(2.0, 5.0),  # latitude=y=2, longitude=x=5
    )
    reading, _ = _read(s, TypedOdomConfig(trust_pose=True))
    assert reading.pose is not None
    assert reading.pose.x == pytest.approx(5.0)  # longitude -> x
    assert reading.pose.y == pytest.approx(2.0)  # latitude -> y


def test_properties_fetched_once():
    s = FakeMovementSensor(angular_velocity=True)
    reader = TypedMovementSensorOdom(s)
    asyncio.run(reader.read())
    asyncio.run(reader.read())
    assert s.calls["get_properties"] == 1


def test_empty_sensor_returns_zero_reading():
    s = FakeMovementSensor()  # advertises nothing
    reading, _ = _read(s)
    assert (reading.vx, reading.vy, reading.vtheta) == (0.0, 0.0, 0.0)
    assert reading.ax is None and reading.pose is None


def test_read_typed_heading_from_orientation():
    # OrientationVector: +z axis, theta -62.9 deg → yaw ≈ -62.9 deg.
    s = FakeMovementSensor(
        orientation=True,
        orient=(0.0, 0.0, 1.0, -62.9),
    )
    yaw, source, dbg = asyncio.run(read_typed_heading(s))
    assert source == "orientation"
    assert yaw == pytest.approx(math.radians(-62.9), abs=1e-3)
    assert "get_orientation" in s.calls
    assert dbg["orientation"]["ov_theta_deg"] == pytest.approx(-62.9, abs=1e-3)


def test_read_typed_heading_prefers_native_euler_like_wit_motion():
    """viam-modules/wit-motion exposes EulerAngles.Yaw; prefer readings.yaw."""

    class WitLike(FakeMovementSensor):
        async def get_readings(self, **kw):
            self._count("get_readings")
            return {
                "orientation": {
                    "roll": 0.0,
                    "pitch": 0.0,
                    "yaw": math.radians(90.0),
                }
            }

    s = WitLike(orientation=True, orient=(0.0, 0.0, 1.0, 22.5))  # OV deliberately wrong
    yaw, source, dbg = asyncio.run(read_typed_heading(s))
    assert source == "orientation_euler"
    assert yaw == pytest.approx(math.radians(90.0))
    assert dbg["native_yaw_deg"] == pytest.approx(90.0)
    # OV still captured for probe comparison.
    assert dbg["orientation"]["ov_theta_deg"] == pytest.approx(22.5)


def test_planar_ov_theta_is_yaw_not_axis_atan2():
    from src.geom import conversions as conv

    # 90° about +Z must yield yaw=90°, even with slight axis tilt noise.
    r, p, y = conv.orientation_vector_to_rpy(0.02, -0.01, 0.999, 90.0, theta_unit="deg")
    assert r == pytest.approx(0.0)
    assert p == pytest.approx(0.0)
    assert y == pytest.approx(math.radians(90.0))


def test_sync_heading_aligns_twist_integrator():
    s = FakeMovementSensor(linear_velocity=True, lv=(0.0, 0.5, 0.0))
    times = iter([10.0, 10.2])
    reader = TypedMovementSensorOdom(
        s,
        TypedOdomConfig(velocity_convention="viam"),
        clock=lambda: next(times),
    )
    asyncio.run(reader.read())
    reader.sync_heading(math.radians(90.0))
    second = asyncio.run(reader.read())
    # After sync to +90°, body +y forward integrates along world +Y.
    assert second.pose is not None
    assert second.pose.x == pytest.approx(0.0, abs=1e-9)
    assert second.pose.y == pytest.approx(0.1)
