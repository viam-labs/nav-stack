"""Tests for Viam framesystem → mount / footprint resolution."""

from __future__ import annotations

import asyncio
import math

import numpy as np
import pytest
from viam.proto.common import (
    Geometry,
    Pose,
    PoseInFrame,
    RectangularPrism,
    Transform,
    Vector3,
)
from viam.proto.robot import FrameSystemConfig

from src.config import NavConfig, SlamConfig
from src.viam_frames import (
    apply_framesystem_to_nav_cfg,
    apply_framesystem_to_slam_cfg,
    base_box_forward_lateral,
    fetch_frame_system_config,
    pose_of_frame_in_destination,
)


def _tracer_like_frames():
    base = Transform(
        reference_frame="base",
        pose_in_observer_frame=PoseInFrame(
            reference_frame="world",
            pose=Pose(x=0, y=0, z=90, o_x=0, o_y=0, o_z=1, theta=0),
        ),
        physical_object=Geometry(
            box=RectangularPrism(dims_mm=Vector3(x=590, y=720, z=180))
        ),
    )
    lidar = Transform(
        reference_frame="rplidar",
        pose_in_observer_frame=PoseInFrame(
            reference_frame="base",
            # Viam base: +Y forward, +X right. Lidar ahead/left in that frame.
            pose=Pose(x=-50, y=240, z=150, o_x=0, o_y=0, o_z=1, theta=-90),
        ),
    )
    camera = Transform(
        reference_frame="camera",
        pose_in_observer_frame=PoseInFrame(
            reference_frame="base",
            pose=Pose(
                x=150,
                y=300,
                z=130,
                o_x=0.022545244531911285,
                o_y=0.9997458236716953,
                o_z=0.0,
                theta=-90.0,
            ),
        ),
    )
    return [
        FrameSystemConfig(frame=base),
        FrameSystemConfig(frame=lidar),
        FrameSystemConfig(frame=camera),
    ]


def test_pose_raw_viam_axes_without_y_forward_convert():
    configs = _tracer_like_frames()
    m = pose_of_frame_in_destination(configs, "rplidar", "base", y_forward_base=False)
    assert m is not None
    assert abs(m.x - (-0.05)) < 1e-9
    assert abs(m.y - 0.24) < 1e-9
    assert abs(m.z - 0.15) < 1e-9
    # viam-sdk 0.85: OV θ=-90° extracts as mount θ=-π/2.
    assert abs(m.theta - (-math.pi / 2)) < 1e-6


def test_pose_converts_viam_y_forward_base_to_ros_x_forward():
    """FS is Viam Y-forward; nav-stack mounts are ROS X-forward."""
    configs = _tracer_like_frames()
    m = pose_of_frame_in_destination(configs, "rplidar", "base", y_forward_base=True)
    assert m is not None
    # p_ros = (y_v, -x_v) = (0.24, 0.05)
    assert abs(m.x - 0.24) < 1e-9
    assert abs(m.y - 0.05) < 1e-9
    assert abs(m.z - 0.15) < 1e-9
    # SDK yaw is -π/2; Rz(-π/2) @ Rz(-π/2) = Rz(-π).
    assert abs(abs(m.theta) - math.pi) < 1e-6


def test_fs_mount_round_trips_viam_rotation_and_points():
    """Mount RPY must rebuild Viam's matrix so PCD lands where the 3D scene does."""
    from src.geom.conversions import _mount_rotation, transform_lidar_mount_to_base_link
    from src.lidar.rplidar_protocol import polar_to_xyz_m
    from src.viam_frames import _pose_to_matrix, _viam_y_forward_base_to_ros

    configs = _tracer_like_frames()
    m = pose_of_frame_in_destination(configs, "rplidar", "base", y_forward_base=True)
    assert m is not None
    pose = configs[1].frame.pose_in_observer_frame.pose
    T_ros = _viam_y_forward_base_to_ros(_pose_to_matrix(pose))
    R_mount = _mount_rotation(m.theta, m.pitch, m.roll)
    assert np.allclose(T_ros[:3, :3], R_mount, atol=1e-9)

    xs, ys, zs = polar_to_xyz_m(0.0, 1000.0)
    p_mm = np.array([xs * 1000.0, ys * 1000.0, zs * 1000.0, 1.0])
    via_T = (T_ros @ p_mm)[:3] / 1000.0
    via_mount = transform_lidar_mount_to_base_link(
        np.array([[xs, ys, zs]]),
        x=m.x,
        y=m.y,
        z=m.z,
        theta=m.theta,
        pitch=m.pitch,
        roll=m.roll,
    )[0]
    assert np.allclose(via_T, via_mount, atol=1e-9)
    # Mount yaw is π, so scan angle 0 (sensor −X) lands on base +X.
    assert abs(via_mount[0] - (m.x + 1.0)) < 1e-9
    assert abs(via_mount[1] - m.y) < 1e-9


def test_camera_fs_mount_round_trips_rotation():
    from src.geom.conversions import _mount_rotation
    from src.viam_frames import _pose_to_matrix, _viam_y_forward_base_to_ros

    configs = _tracer_like_frames()
    m = pose_of_frame_in_destination(configs, "camera", "base", y_forward_base=True)
    assert m is not None
    T_ros = _viam_y_forward_base_to_ros(
        _pose_to_matrix(configs[2].frame.pose_in_observer_frame.pose)
    )
    assert np.allclose(
        T_ros[:3, :3], _mount_rotation(m.theta, m.pitch, m.roll), atol=1e-9
    )


def test_tracer_box_reads_viam_y_as_length():
    assert base_box_forward_lateral(_tracer_like_frames(), "base") == pytest.approx(
        (0.72, 0.59)
    )


def test_wide_cart_box_crops_forward_not_the_longer_side():
    """Cart is 0.50 m wide (Viam X) and 0.44 m long (Viam Y). The longer side
    is the width; cropping that as length would eat returns in front of the nose."""
    base = Transform(
        reference_frame="cartbase",
        pose_in_observer_frame=PoseInFrame(
            reference_frame="world",
            pose=Pose(x=0, y=0, z=0, o_x=0, o_y=0, o_z=1, theta=0),
        ),
        physical_object=Geometry(
            box=RectangularPrism(dims_mm=Vector3(x=500, y=440, z=260))
        ),
    )
    configs = [FrameSystemConfig(frame=base)]
    assert base_box_forward_lateral(configs, "cartbase") == pytest.approx((0.44, 0.50))
    cfg = SlamConfig.from_dict(
        {
            "base": "cartbase",
            "movement_sensor": "imu",
            "lidars": [{"name": "livox-pc", "scan_source": "point_cloud"}],
        }
    )
    apply_framesystem_to_slam_cfg(cfg, configs, raw_attrs={"base": "cartbase"})
    lidar = cfg.lidars[0]
    assert lidar.footprint_length_m == pytest.approx(0.44)
    assert lidar.footprint_width_m == pytest.approx(0.50)


def _cart_imu_frames(theta_deg: float) -> list:
    base = Transform(
        reference_frame="cartbase",
        pose_in_observer_frame=PoseInFrame(
            reference_frame="world",
            pose=Pose(x=0, y=0, z=0, o_x=0, o_y=0, o_z=1, theta=0),
        ),
    )
    imu = Transform(
        reference_frame="imu",
        pose_in_observer_frame=PoseInFrame(
            reference_frame="cartbase",
            pose=Pose(x=150, y=0, z=390, o_x=0, o_y=0, o_z=1, theta=theta_deg),
        ),
    )
    return [FrameSystemConfig(frame=base), FrameSystemConfig(frame=imu)]


def test_imu_yaw_from_framesystem_viam_90_is_forward():
    """Viam +90° yaw points the IMU +X along base +Y (forward). In nav-stack
    that is yaw 0, so forward acceleration stays on X."""
    configs = _cart_imu_frames(90)
    cfg = SlamConfig.from_dict(
        {
            "base": "cartbase",
            "movement_sensor": "imu",
            "lidars": [{"name": "livox-pc", "scan_source": "point_cloud"}],
        }
    )
    _, notes = apply_framesystem_to_slam_cfg(
        cfg, configs, raw_attrs={"base": "cartbase", "movement_sensor": "imu"}
    )
    assert cfg.movement_sensor_yaw_deg == pytest.approx(0.0, abs=1e-6)
    assert any("movement sensor imu: yaw from framesystem 0.0°" in n for n in notes)


def test_imu_aligned_with_viam_base_needs_minus_90():
    """Viam yaw 0 keeps IMU +X pointing right. Nav-stack forward is +X, so the
    correction is -90°."""
    configs = _cart_imu_frames(0)
    cfg = SlamConfig.from_dict(
        {
            "base": "cartbase",
            "movement_sensor": "imu",
            "lidars": [{"name": "livox-pc", "scan_source": "point_cloud"}],
        }
    )
    apply_framesystem_to_slam_cfg(
        cfg, configs, raw_attrs={"base": "cartbase", "movement_sensor": "imu"}
    )
    assert cfg.movement_sensor_yaw_deg == pytest.approx(-90.0, abs=1e-6)


def test_explicit_movement_sensor_yaw_overrides_framesystem():
    configs = _cart_imu_frames(0)
    cfg = SlamConfig.from_dict(
        {
            "base": "cartbase",
            "movement_sensor": "imu",
            "movement_sensor_yaw_deg": 15,
            "lidars": [{"name": "livox-pc", "scan_source": "point_cloud"}],
        }
    )
    raw = {
        "base": "cartbase",
        "movement_sensor": "imu",
        "movement_sensor_yaw_deg": 15,
    }
    _, notes = apply_framesystem_to_slam_cfg(cfg, configs, raw_attrs=raw)
    assert cfg.movement_sensor_yaw_deg == pytest.approx(15.0)
    assert any("from config (override)" in n for n in notes)


def test_apply_slam_fills_mount_when_omitted():
    configs = _tracer_like_frames()
    raw = {
        "base": "base",
        "movement_sensor": "odom",
        "lidars": [
            {"name": "rplidar", "scan_source": "point_cloud"},
            {
                "name": "camera",
                "scan_source": "point_cloud",
                "obstacles_only": True,
                "cloud_frame": "camera_optical",
            },
        ],
    }
    cfg = SlamConfig.from_dict(raw)
    assert cfg.lidars[0].x == 0.0
    cfg2, notes = apply_framesystem_to_slam_cfg(cfg, configs, raw_attrs=raw)
    assert any("Y-forward" in n for n in notes)
    assert any("rplidar" in n and "framesystem" in n for n in notes)
    rpl = next(lidar for lidar in cfg2.lidars if lidar.name == "rplidar")
    # Y-forward → X-forward: (x,y)_v=(-0.05,0.24) → (0.24, 0.05)
    assert abs(rpl.x - 0.24) < 1e-9
    assert abs(rpl.y - 0.05) < 1e-9
    assert abs(abs(rpl.theta) - math.pi) < 1e-6
    cam = next(lidar for lidar in cfg2.lidars if lidar.name == "camera")
    assert abs(cam.x - 0.30) < 1e-9
    assert abs(cam.y - (-0.15)) < 1e-9
    # RealSense PCD is optical; FS OV RPY is convention, not lens aim — keep
    # optical remap and identity orientation (translation only from FS).
    assert cam.cloud_frame == "camera_optical"
    assert abs(cam.theta) < 1e-9
    assert abs(cam.pitch) < 1e-9
    assert abs(cam.roll) < 1e-9
    assert any("FS orientation ignored" in n for n in notes)


def test_apply_slam_keeps_explicit_mount():
    configs = _tracer_like_frames()
    raw = {
        "base": "base",
        "movement_sensor": "odom",
        "lidars": [
            {
                "name": "rplidar",
                "mount": {"x": 0.09, "y": 0.05, "z": 0.12, "theta": 3.14159},
            }
        ],
    }
    cfg = SlamConfig.from_dict(raw)
    cfg2, notes = apply_framesystem_to_slam_cfg(cfg, configs, raw_attrs=raw)
    assert any("override" in n for n in notes)
    assert abs(cfg2.lidars[0].x - 0.09) < 1e-9
    assert abs(cfg2.lidars[0].theta - 3.14159) < 1e-5


def test_apply_slam_mutates_lidar_in_place():
    """Live BuiltinSensors holds the same LidarConfig instances."""
    configs = _tracer_like_frames()
    raw = {
        "base": "base",
        "movement_sensor": "odom",
        "lidars": [{"name": "rplidar", "scan_source": "point_cloud"}],
    }
    cfg = SlamConfig.from_dict(raw)
    lidar = cfg.lidars[0]
    apply_framesystem_to_slam_cfg(cfg, configs, raw_attrs=raw)
    assert lidar is cfg.lidars[0]
    assert abs(lidar.x - 0.24) < 1e-9


def test_apply_nav_fills_footprint_from_box():
    configs = _tracer_like_frames()
    raw = {"slam_service": "slam", "base": "base"}
    cfg = NavConfig.from_dict(raw)
    cfg2, notes = apply_framesystem_to_nav_cfg(cfg, configs, raw_attrs=raw)
    assert any("from framesystem" in n for n in notes)
    assert abs(cfg2.footprint_length_m - 0.72) < 1e-9
    assert abs(cfg2.footprint_width_m - 0.59) < 1e-9
    assert cfg2.robot_radius == pytest.approx(0.295)
    assert cfg2.cart_height_m is None


def test_apply_nav_keeps_explicit_footprint():
    configs = _tracer_like_frames()
    raw = {
        "slam_service": "slam",
        "base": "base",
        "footprint_length_m": 0.8,
        "footprint_width_m": 0.5,
        "robot_radius": 0.31,
    }
    cfg = NavConfig.from_dict(raw)
    cfg2, notes = apply_framesystem_to_nav_cfg(cfg, configs, raw_attrs=raw)
    assert any("from config" in n for n in notes)
    assert abs(cfg2.footprint_length_m - 0.8) < 1e-9
    assert abs(cfg2.footprint_width_m - 0.5) < 1e-9
    assert abs(cfg2.robot_radius - 0.31) < 1e-9


def test_apply_nav_one_side_overrides_the_box():
    raw = {"slam_service": "slam", "base": "base", "footprint_width_m": 0.65}
    cfg2, notes = apply_framesystem_to_nav_cfg(
        NavConfig.from_dict(raw), _tracer_like_frames(), raw_attrs=raw
    )
    assert cfg2.footprint_length_m == pytest.approx(0.72)
    assert cfg2.footprint_width_m == pytest.approx(0.65)
    assert any("length=framesystem width=config" in n for n in notes)


@pytest.mark.parametrize("unset", [0, None])
def test_apply_nav_zero_or_null_falls_back_to_the_box(unset):
    raw = {
        "slam_service": "slam",
        "base": "base",
        "footprint_length_m": unset,
        "footprint_width_m": unset,
    }
    cfg2, _ = apply_framesystem_to_nav_cfg(
        NavConfig.from_dict(raw), _tracer_like_frames(), raw_attrs=raw
    )
    assert (cfg2.footprint_length_m, cfg2.footprint_width_m) == pytest.approx(
        (0.72, 0.59)
    )


def test_apply_nav_without_box_uses_robot_radius_for_the_missing_side():
    raw = {
        "slam_service": "slam",
        "base": "base",
        "footprint_length_m": 0.9,
        "robot_radius": 0.3,
    }
    cfg2, _ = apply_framesystem_to_nav_cfg(NavConfig.from_dict(raw), [], raw_attrs=raw)
    assert cfg2.footprint_length_m == pytest.approx(0.9)
    assert cfg2.footprint_width_m == pytest.approx(0.6)
    assert cfg2.robot_radius == pytest.approx(0.3)


def test_apply_nav_radius_only_stays_circular():
    raw = {"slam_service": "slam", "base": "base", "robot_radius": 0.3}
    cfg2, _ = apply_framesystem_to_nav_cfg(NavConfig.from_dict(raw), [], raw_attrs=raw)
    assert cfg2.footprint_length_m is None
    assert cfg2.footprint_width_m is None
    assert cfg2.robot_radius == pytest.approx(0.3)


def test_slam_crop_one_side_overrides_the_box():
    raw = {
        "base": "base",
        "footprint_length_m": 0.9,
        "lidars": [{"name": "rplidar", "scan_source": "point_cloud"}],
    }
    cfg = SlamConfig.from_dict(raw)
    apply_framesystem_to_slam_cfg(cfg, _tracer_like_frames(), raw_attrs=raw)
    lidar = cfg.lidars[0]
    assert (lidar.footprint_length_m, lidar.footprint_width_m) == pytest.approx(
        (0.9, 0.59)
    )


def test_slam_crop_without_box_uses_a_robot_radius_disc():
    raw = {
        "base": "base",
        "robot_radius": 0.3,
        "lidars": [{"name": "rplidar", "scan_source": "point_cloud"}],
    }
    cfg = SlamConfig.from_dict(raw)
    apply_framesystem_to_slam_cfg(cfg, [], raw_attrs=raw)
    lidar = cfg.lidars[0]
    assert lidar.footprint_length_m == 0.0
    assert lidar.footprint_radius_m == pytest.approx(0.3)


@pytest.mark.asyncio
async def test_fetch_frame_system_config_times_out():
    class _SlowRobot:
        async def get_frame_system_config(self):
            await asyncio.sleep(10.0)
            return []

    with pytest.raises(asyncio.TimeoutError):
        await fetch_frame_system_config(_SlowRobot(), timeout_s=0.05)
