"""Unit tests for Motion MoveOnMap on NavServiceBase."""

from __future__ import annotations

import asyncio
from types import SimpleNamespace
from unittest.mock import MagicMock

import pytest

pytest.importorskip("viam")

from grpclib.const import Status
from grpclib.exceptions import GRPCError
from viam.proto.common import Pose, PoseInFrame
from viam.proto.service.motion import PlanState
from viam.services.motion import Motion
from viam.services.navigation import Navigation

from src.config import NavConfig
from src.geom.conversions import Pose2D, viam_pose_to_pose2d
from src.models.navigation import NavigationService, _nav_status_to_plan_state


def test_nav_status_to_plan_state_mapping():
    assert (
        _nav_status_to_plan_state({"active": True}) == PlanState.PLAN_STATE_IN_PROGRESS
    )
    assert (
        _nav_status_to_plan_state({"active": False, "state": "succeeded"})
        == PlanState.PLAN_STATE_SUCCEEDED
    )
    assert (
        _nav_status_to_plan_state({"active": False, "state": "canceled"})
        == PlanState.PLAN_STATE_STOPPED
    )
    assert (
        _nav_status_to_plan_state({"active": False, "state": "failed"})
        == PlanState.PLAN_STATE_FAILED
    )
    assert (
        _nav_status_to_plan_state({"active": False, "state": "aborted"})
        == PlanState.PLAN_STATE_FAILED
    )
    assert (
        _nav_status_to_plan_state({"active": False, "state": "idle"})
        == PlanState.PLAN_STATE_UNSPECIFIED
    )


def test_navigation_registers_as_navigation_service():
    assert NavigationService.API == Navigation.API
    assert issubclass(NavigationService, Navigation)
    assert not issubclass(NavigationService, Motion)


def _configured_nav(
    *, nav_status=None, pose=None
) -> tuple[NavigationService, MagicMock]:
    nav = NavigationService("nav")
    nav._cfg = NavConfig(
        slam_service="slam",
        base="my-base",
        kinematics="differential",
        robot_radius=0.22,
        max_linear_velocity=0.4,
        max_vel_theta=1.0,
        clearance_m=0.2,
    )
    mgr = MagicMock()
    mgr.navigate = MagicMock()
    mgr.cancel = MagicMock()
    mgr.nav_status = MagicMock(
        return_value=nav_status
        if nav_status is not None
        else {"active": True, "state": "idle"}
    )
    mgr.get_pose_in_map = MagicMock(
        return_value=pose if pose is not None else Pose2D(1.0, 2.0, 0.5)
    )
    runtime = SimpleNamespace(manager=mgr, localization_check={})
    nav._resolve_runtime = MagicMock(return_value=runtime)  # type: ignore[method-assign]
    nav._base = MagicMock()
    return nav, mgr


def test_move_on_map_calls_navigate_with_meters_radians():
    nav, mgr = _configured_nav()
    dest = Pose(x=3500.0, y=-1000.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=90.0)
    expected = viam_pose_to_pose2d(dest.x, dest.y, dest.theta)

    execution_id = asyncio.run(
        nav.move_on_map(
            component_name="my-base",
            destination=dest,
            slam_service_name="slam",
        )
    )

    assert isinstance(execution_id, str) and execution_id
    mgr.navigate.assert_called_once()
    args = mgr.navigate.call_args[0]
    assert args[0] == pytest.approx(expected.x)
    assert args[1] == pytest.approx(expected.y)
    assert args[2] == pytest.approx(expected.theta)

    plan = asyncio.run(nav.get_plan("my-base", execution_id=execution_id))
    assert plan.current_plan_with_status.plan.execution_id == execution_id
    assert (
        plan.current_plan_with_status.status.state == PlanState.PLAN_STATE_IN_PROGRESS
    )


def test_stop_plan_cancels_and_marks_stopped():
    nav, mgr = _configured_nav()
    dest = Pose(x=1000.0, y=0.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0)
    execution_id = asyncio.run(nav.move_on_map("my-base", dest, "slam"))
    asyncio.run(nav.stop_plan("my-base"))
    mgr.cancel.assert_called()
    plan = asyncio.run(nav.get_plan("my-base", execution_id=execution_id))
    assert plan.current_plan_with_status.status.state == PlanState.PLAN_STATE_STOPPED


def test_get_plan_syncs_succeeded_from_nav_status():
    nav, mgr = _configured_nav(nav_status={"active": False, "state": "succeeded"})
    dest = Pose(x=500.0, y=500.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0)
    # After navigate returns, sync will see succeeded.
    execution_id = asyncio.run(nav.move_on_map("my-base", dest, "slam"))
    plan = asyncio.run(nav.get_plan("my-base", execution_id=execution_id))
    assert plan.current_plan_with_status.status.state == PlanState.PLAN_STATE_SUCCEEDED


def test_list_plan_statuses_filters_active():
    nav, mgr = _configured_nav(nav_status={"active": True, "state": "idle"})
    dest = Pose(x=0.0, y=0.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0)
    asyncio.run(nav.move_on_map("my-base", dest, "slam"))
    all_statuses = asyncio.run(nav.list_plan_statuses(only_active_plans=False))
    active = asyncio.run(nav.list_plan_statuses(only_active_plans=True))
    assert len(all_statuses) >= 1
    assert len(active) == 1
    assert active[0].status.state == PlanState.PLAN_STATE_IN_PROGRESS


def test_get_pose_returns_map_frame():
    nav, _mgr = _configured_nav(pose=Pose2D(1.5, -0.5, 0.25))
    pose_in_frame = asyncio.run(nav.get_pose("my-base", "map"))
    assert isinstance(pose_in_frame, PoseInFrame)
    assert pose_in_frame.reference_frame == "map"
    assert pose_in_frame.pose.x == pytest.approx(1500.0)
    assert pose_in_frame.pose.y == pytest.approx(-500.0)


def test_move_and_move_on_globe_unimplemented():
    nav, _mgr = _configured_nav()

    with pytest.raises(GRPCError) as move_exc:
        asyncio.run(
            nav.move(
                "my-base",
                PoseInFrame(reference_frame="map", pose=Pose()),
            )
        )
    assert move_exc.value.status == Status.UNIMPLEMENTED

    with pytest.raises(GRPCError) as globe_exc:
        from viam.proto.common import GeoPoint

        asyncio.run(
            nav.move_on_globe(
                "my-base",
                GeoPoint(latitude=0.0, longitude=0.0),
                "gps",
            )
        )
    assert globe_exc.value.status == Status.UNIMPLEMENTED


def test_do_command_navigate_to_point_still_works():
    nav, mgr = _configured_nav()
    result = asyncio.run(
        nav.do_command(
            {"command": "navigate_to_point", "x": 3.5, "y": -1.0, "theta": 0.1}
        )
    )
    assert result["status"] == "navigating"
    mgr.navigate.assert_called_once_with(3.5, -1.0, 0.1)


def test_do_command_cancel_marks_motion_plan_stopped():
    nav, mgr = _configured_nav()
    dest = Pose(x=1000.0, y=0.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0)
    execution_id = asyncio.run(nav.move_on_map("my-base", dest, "slam"))
    asyncio.run(nav.do_command({"command": "cancel"}))
    plan = asyncio.run(nav.get_plan("my-base", execution_id=execution_id))
    assert plan.current_plan_with_status.status.state == PlanState.PLAN_STATE_STOPPED
    mgr.cancel.assert_called()


def test_suspend_resume_move_on_map():
    nav, mgr = _configured_nav(
        nav_status={
            "active": True,
            "state": "active",
            "goal": {"x": 1.0, "y": 0.0, "theta": 0.0},
        }
    )
    dest = Pose(x=1000.0, y=0.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0)
    execution_id = asyncio.run(nav.move_on_map("my-base", dest, "slam"))

    suspended = asyncio.run(nav.do_command({"command": "suspend", "reason": "safety"}))
    assert suspended["status"] == "suspended"
    assert suspended["goal"]["x"] == pytest.approx(1.0)
    assert suspended["goal"]["y"] == pytest.approx(0.0)
    assert suspended["goal"]["motion"] == "builtin"
    assert suspended["goal"]["reason"] == "safety"
    mgr.cancel.assert_called()
    plan = asyncio.run(nav.get_plan("my-base", execution_id=execution_id))
    assert plan.current_plan_with_status.status.state == PlanState.PLAN_STATE_STOPPED
    assert plan.current_plan_with_status.status.reason == "suspended"

    status = asyncio.run(nav.do_command({"command": "get_status"}))
    assert status["suspended"] is True
    assert status["suspended_goal"]["x"] == pytest.approx(1.0)

    mgr.navigate.reset_mock()
    mgr.nav_status.return_value = {
        "active": True,
        "state": "active",
        "goal": {"x": 1.0, "y": 0.0, "theta": 0.0},
    }
    resumed = asyncio.run(nav.do_command({"command": "resume"}))
    assert resumed["status"] == "navigating"
    assert resumed["resumed"] is True
    assert "execution_id" in resumed
    mgr.navigate.assert_called_once_with(1.0, 0.0, 0.0)

    status = asyncio.run(nav.do_command({"command": "get_status"}))
    assert status["suspended"] is False
    assert status["suspended_goal"] is None


def test_suspend_when_idle_raises():
    nav, _mgr = _configured_nav(nav_status={"active": False, "state": "idle"})
    with pytest.raises(ValueError, match="nothing to suspend"):
        asyncio.run(nav.do_command({"command": "suspend"}))


def test_resume_when_not_suspended_raises():
    nav, _mgr = _configured_nav()
    with pytest.raises(ValueError, match="nothing to resume"):
        asyncio.run(nav.do_command({"command": "resume"}))


def test_cancel_clears_suspended_goal():
    nav, mgr = _configured_nav(
        nav_status={
            "active": True,
            "state": "active",
            "goal": {"x": 2.0, "y": 3.0, "theta": 0.5},
        }
    )
    asyncio.run(
        nav.do_command(
            {"command": "navigate_to_point", "x": 2.0, "y": 3.0, "theta": 0.5}
        )
    )
    asyncio.run(nav.do_command({"command": "suspend"}))
    assert nav._suspended is not None
    asyncio.run(nav.do_command({"command": "cancel"}))
    assert nav._suspended is None
    with pytest.raises(ValueError, match="nothing to resume"):
        asyncio.run(nav.do_command({"command": "resume"}))


def test_suspend_already_suspended_is_idempotent():
    nav, mgr = _configured_nav(
        nav_status={
            "active": True,
            "state": "active",
            "goal": {"x": 1.5, "y": -0.5, "theta": 0.1},
        }
    )
    asyncio.run(
        nav.do_command(
            {"command": "navigate_to_point", "x": 1.5, "y": -0.5, "theta": 0.1}
        )
    )
    first = asyncio.run(nav.do_command({"command": "suspend", "reason": "a"}))
    mgr.nav_status.return_value = {"active": False, "state": "canceled"}
    second = asyncio.run(nav.do_command({"command": "suspend", "reason": "b"}))
    assert second["already_suspended"] is True
    assert second["goal"]["reason"] == "b"
    assert first["goal"]["x"] == pytest.approx(1.5)


def _stub_locations(nav: NavigationService, poses: dict) -> None:
    class _Loc:
        def __init__(self, name: str, x: float, y: float, theta: float = 0.0):
            self.name = name
            self.x = x
            self.y = y
            self.theta = theta

    store = MagicMock()
    store.get.side_effect = lambda name: (
        _Loc(name, *poses[name])
        if name in poses
        else (_ for _ in ()).throw(KeyError(name))
    )
    nav._locations = MagicMock(return_value=store)  # type: ignore[method-assign]


def _route_status_queue(mgr: MagicMock) -> list:
    """Drive nav_status from navigate() goals: active once, then succeeded."""
    queue: list = []

    def on_navigate(x, y, theta):
        queue.clear()
        goal = {"x": float(x), "y": float(y), "theta": float(theta)}
        queue.extend(
            [
                {"active": True, "state": "active", "goal": goal},
                {"active": False, "state": "succeeded", "goal": goal},
            ]
        )

    def nav_status():
        if not queue:
            return {"active": False, "state": "idle", "goal": None}
        if len(queue) > 1:
            return queue.pop(0)
        return queue[0]

    mgr.navigate.side_effect = on_navigate
    mgr.nav_status.side_effect = nav_status
    return queue


def test_navigate_route_follows_waypoints_in_order(monkeypatch):
    nav, mgr = _configured_nav()
    _stub_locations(nav, {"dock": (0.0, 0.0, 0.0), "kitchen": (1.0, 2.0, 0.5)})
    _route_status_queue(mgr)
    _real_sleep = asyncio.sleep

    async def _fast_sleep(*_a, **_k):
        await _real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)

    result = asyncio.run(
        nav.do_command(
            {
                "command": "navigate_route",
                "waypoints": ["dock", "kitchen"],
                "wait": True,
            }
        )
    )
    assert result["state"] == "succeeded"
    assert result["total"] == 2
    assert result["location"] == "kitchen"
    assert mgr.navigate.call_count == 2
    assert mgr.navigate.call_args_list[0].args == (0.0, 0.0, 0.0)
    assert mgr.navigate.call_args_list[1].args == (1.0, 2.0, 0.5)


def test_navigate_route_from_saved_route(monkeypatch, tmp_path):
    from src.nav.stores.routes import RouteStore

    nav, mgr = _configured_nav()
    _stub_locations(nav, {"a": (0.0, 0.0, 0.0), "b": (2.0, 0.0, 0.0)})
    store = RouteStore(tmp_path / "routes.json")
    store.add("patrol", ["a", "b"])
    nav._routes = MagicMock(return_value=store)  # type: ignore[method-assign]
    _route_status_queue(mgr)
    _real_sleep = asyncio.sleep

    async def _fast_sleep(*_a, **_k):
        await _real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)

    result = asyncio.run(
        nav.do_command({"command": "navigate_route", "name": "patrol", "wait": True})
    )
    assert result["state"] == "succeeded"
    assert result["name"] == "patrol"
    assert mgr.navigate.call_count == 2


def test_navigate_route_async_exposes_status(monkeypatch):
    nav, mgr = _configured_nav()
    _stub_locations(nav, {"dock": (0.0, 0.0, 0.0), "kitchen": (3.0, 1.0, 0.0)})
    queue = _route_status_queue(mgr)
    # Hold the first leg active until we poll get_status.
    held = {"x": 0.0, "y": 0.0, "theta": 0.0}

    def on_navigate(x, y, theta):
        queue.clear()
        held.update(x=float(x), y=float(y), theta=float(theta))
        queue.append(
            {
                "active": True,
                "state": "active",
                "goal": dict(held),
            }
        )

    def release():
        queue.clear()
        queue.append(
            {
                "active": False,
                "state": "succeeded",
                "goal": dict(held),
            }
        )

    mgr.navigate.side_effect = on_navigate
    mgr.nav_status.side_effect = lambda: (
        queue[0] if queue else {"active": False, "state": "idle"}
    )
    _real_sleep = asyncio.sleep

    async def _fast_sleep(*_a, **_k):
        await _real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)

    # The route task reaches the manager through asyncio.to_thread, so each
    # step needs real time on a busy runner; a fixed number of loop turns is
    # not enough.
    async def _wait_for(check, what):
        deadline = asyncio.get_running_loop().time() + 5.0
        while asyncio.get_running_loop().time() < deadline:
            if await check():
                return
            await _real_sleep(0.01)
        raise AssertionError(f"timed out waiting for {what}")

    async def _route_active():
        status = await nav.do_command({"command": "get_status"})
        return (
            status.get("motion") == "route"
            and status.get("route", {}).get("state") == "active"
        )

    async def _second_leg_active():
        return (
            mgr.navigate.call_count >= 2
            and held["x"] == 3.0
            and bool(queue)
            and queue[0]["state"] == "active"
        )

    async def _route_succeeded():
        return nav._route_status.get("state") == "succeeded"

    async def _run():
        started = await nav.do_command(
            {
                "command": "navigate_route",
                "waypoints": ["dock", "kitchen"],
                "wait": False,
            }
        )
        assert started["status"] == "navigating"
        assert started["motion"] == "route"
        await _wait_for(_route_active, "the route to become active")
        status = await nav.do_command({"command": "get_status"})
        assert status["active"] is True
        assert status["route"]["location"] == "dock"
        release()
        # Releasing before on_navigate has queued the second leg would be
        # overwritten by it, leaving that leg active forever.
        await _wait_for(_second_leg_active, "the second leg to become active")
        release()
        await _wait_for(_route_succeeded, "the route to succeed")

    asyncio.run(_run())


def test_navigate_route_suspend_resume(monkeypatch):
    nav, mgr = _configured_nav()
    _stub_locations(nav, {"dock": (0.0, 0.0, 0.0), "kitchen": (1.0, 0.0, 0.0)})
    queue: list = []

    def on_navigate(x, y, theta):
        queue.clear()
        queue.append(
            {
                "active": True,
                "state": "active",
                "goal": {"x": float(x), "y": float(y), "theta": float(theta)},
            }
        )

    mgr.navigate.side_effect = on_navigate
    mgr.nav_status.side_effect = lambda: (
        queue[0] if queue else {"active": False, "state": "idle", "goal": None}
    )
    _real_sleep = asyncio.sleep

    async def _fast_sleep(*_a, **_k):
        await _real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)

    # The route task reaches the manager through asyncio.to_thread, so each
    # step needs real time on a busy runner; a fixed number of loop turns is
    # not enough.
    async def _wait_for(check, what):
        deadline = asyncio.get_running_loop().time() + 5.0
        while asyncio.get_running_loop().time() < deadline:
            if check():
                return
            await _real_sleep(0.01)
        raise AssertionError(f"timed out waiting for {what}")

    async def _run():
        await nav.do_command(
            {
                "command": "navigate_route",
                "waypoints": ["dock", "kitchen"],
                "wait": False,
            }
        )
        await _wait_for(
            lambda: (
                nav._route_status.get("state") == "active"
                and mgr.navigate.call_count >= 1
            ),
            "the route to become active",
        )
        suspended = await nav.do_command({"command": "suspend", "reason": "safety"})
        assert suspended["status"] == "suspended"
        assert suspended["goal"]["route"] == "inline"
        assert suspended["goal"]["route_index"] == 0
        assert nav._route_status["state"] == "idle"

        # Resume: finish remaining waypoints quickly.
        def finish_leg(x, y, theta):
            queue.clear()
            goal = {"x": float(x), "y": float(y), "theta": float(theta)}
            queue.extend(
                [
                    {"active": True, "state": "active", "goal": goal},
                    {"active": False, "state": "succeeded", "goal": goal},
                ]
            )

        def nav_status():
            if not queue:
                return {"active": False, "state": "idle", "goal": None}
            if len(queue) > 1:
                return queue.pop(0)
            return queue[0]

        mgr.navigate.side_effect = finish_leg
        mgr.nav_status.side_effect = nav_status
        resumed = await nav.do_command({"command": "resume"})
        assert resumed["status"] == "navigating"
        assert resumed["motion"] == "route"
        await _wait_for(
            lambda: nav._route_status.get("state") == "succeeded",
            "the route to succeed",
        )
        assert mgr.navigate.call_count >= 2

    asyncio.run(_run())


def test_navigate_route_start_nearest(monkeypatch):
    nav, mgr = _configured_nav(pose=Pose2D(2.8, 1.0, 0.0))
    _stub_locations(
        nav,
        {
            "dock": (0.0, 0.0, 0.0),
            "kitchen": (3.0, 1.0, 0.0),
            "lobby": (10.0, 10.0, 0.0),
        },
    )
    _route_status_queue(mgr)
    _real_sleep = asyncio.sleep

    async def _fast_sleep(*_a, **_k):
        await _real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)

    result = asyncio.run(
        nav.do_command(
            {
                "command": "navigate_route",
                "waypoints": ["dock", "kitchen", "lobby"],
                "start_nearest": True,
                "wait": True,
            }
        )
    )
    assert result["state"] == "succeeded"
    # Nearest to (2.8, 1.0) is kitchen — should not visit dock first.
    assert mgr.navigate.call_args_list[0].args[:2] == (3.0, 1.0)
    assert mgr.navigate.call_count == 2  # kitchen then lobby


def test_navigate_route_loop_wraps_until_cancel(monkeypatch):
    nav, mgr = _configured_nav()
    _stub_locations(nav, {"a": (0.0, 0.0, 0.0), "b": (1.0, 0.0, 0.0)})
    _route_status_queue(mgr)
    _real_sleep = asyncio.sleep

    async def _fast_sleep(*_a, **_k):
        await _real_sleep(0)

    monkeypatch.setattr(asyncio, "sleep", _fast_sleep)

    async def _run():
        started = await nav.do_command(
            {
                "command": "navigate_route",
                "waypoints": ["a", "b"],
                "loop": True,
                "wait": False,
            }
        )
        assert started["loop"] is True
        # Wait until we've wrapped onto a second lap (3rd navigate = a again).
        # Each leg crosses asyncio.to_thread, so give it real time rather
        # than a fixed number of loop turns (see 409912d).
        deadline = asyncio.get_running_loop().time() + 5.0
        while (
            mgr.navigate.call_count < 3 and asyncio.get_running_loop().time() < deadline
        ):
            await _real_sleep(0.01)
        assert mgr.navigate.call_count >= 3
        assert nav._route_status.get("loop") is True
        assert int(nav._route_status.get("lap", 0)) >= 1
        await nav.do_command({"command": "cancel"})
        assert nav._route_status["state"] == "canceled"

    asyncio.run(_run())
