"""Tests for ViamWorldIO + get_grid encode/decode (ROS-free nav I/O)."""

from __future__ import annotations

import asyncio
import math
import time
from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock

import numpy as np
import pytest

from src.geom import conversions as conv
from src.nav.io.viam_io import (
    ViamWorldIO,
    get_grid_response_to_map,
    map_dict_to_get_grid,
)
from src.nav.io.viz_store import NavVizStore


def test_bridge_map_get_grid_roundtrip():
    grid = np.array([[0, 100], [-1, 50]], dtype=np.int16)
    mp = {
        "grid": grid,
        "resolution": 0.05,
        "origin_x": -1.0,
        "origin_y": -2.0,
    }
    payload = map_dict_to_get_grid(mp)
    assert payload["rows"] == 2
    assert payload["cols"] == 2
    assert payload["cellSize"] == pytest.approx(0.05)
    back = get_grid_response_to_map(payload)
    assert back is not None
    assert back["origin_x"] == pytest.approx(-1.0)
    assert back["origin_y"] == pytest.approx(-2.0)
    np.testing.assert_array_equal(back["grid"], grid)


@pytest.mark.asyncio
async def test_viam_world_io_map_pose_drive():
    loop = asyncio.get_event_loop()
    grid = np.zeros((4, 4), dtype=np.int16)
    grid[1, 1] = 100
    payload = map_dict_to_get_grid(
        {
            "grid": grid,
            "resolution": 0.1,
            "origin_x": 0.0,
            "origin_y": 0.0,
        }
    )

    slam = MagicMock()
    slam.do_command = AsyncMock(return_value=payload)
    pose = SimpleNamespace(
        x=1500.0, y=-500.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=90.0
    )
    slam.get_position = AsyncMock(return_value=pose)

    base = MagicMock()
    base.set_velocity = AsyncMock()

    viz = NavVizStore()
    world = ViamWorldIO(
        slam=slam,
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
        viz=viz,
    )

    mp = await asyncio.to_thread(world.get_map)
    assert mp is not None
    assert mp["grid"][1, 1] == 100
    assert viz.get_map() is not None

    p2 = await asyncio.to_thread(world.get_pose)
    assert p2 is not None
    assert p2.x == pytest.approx(1.5)
    assert p2.y == pytest.approx(-0.5)
    assert p2.theta == pytest.approx(math.pi / 2)

    await asyncio.to_thread(world.set_velocity, 0.2, 0.0, -1.0)
    base.set_velocity.assert_awaited()
    args = base.set_velocity.await_args
    # viam convention: ROS vx -> Viam linear.y; angular is deg/s not rad/s
    assert args.kwargs["linear"].y == pytest.approx(200.0)
    assert args.kwargs["angular"].z == pytest.approx(-math.degrees(1.0))
    drive = world.last_drive()
    assert drive is not None
    assert drive["issued"] is True
    assert drive["body_vtheta_rad_s"] == pytest.approx(-1.0)
    assert drive["viam_angular_z_deg_s"] == pytest.approx(-math.degrees(1.0))


def test_nav_viz_store_snapshot_shape():
    viz = NavVizStore()
    viz.set_map(
        {
            "grid": np.zeros((2, 2), dtype=np.int16),
            "resolution": 0.05,
            "origin_x": 0.0,
            "origin_y": 0.0,
        }
    )
    viz.set_plan(((0.0, 0.0), (1.0, 0.0)), goal=(1.0, 0.0, 0.0))
    viz.set_pose(conv.Pose2D(0.1, 0.2, 0.3))
    snap = viz.viz_snapshot()
    assert snap["map"] is not None
    assert len(snap["global_plan"]) == 2
    assert snap["goal"] == (1.0, 0.0, 0.0)
    assert snap["pose"] == (0.1, 0.2, 0.3)


def test_builtin_nav_host_status():
    from src.config import NavConfig
    from src.nav.control.host import BuiltinNavHost, make_builtin_navigator

    class _World:
        def get_map(self):
            return None

        def get_pose(self):
            return conv.Pose2D(0.0, 0.0, 0.0)

        def get_scan(self, max_age_s=2.0):
            return None

        def set_velocity(self, vx, vy, vtheta):
            pass

        def stop(self):
            pass

        def set_viz_plan(self, path_xy, goal=None):
            pass

        def set_viz_costmap(self, costmap):
            pass

    cfg = NavConfig.from_dict({"slam_service": "s", "base": "b"})
    world = _World()
    viz = NavVizStore()
    nav = make_builtin_navigator(world, cfg)
    host = BuiltinNavHost(nav, world, viz, nav_cfg=cfg)
    assert host.nav_backend() == "builtin"
    assert nav._cfg.control_period_s() == pytest.approx(0.1)  # noqa: SLF001
    assert nav._cfg.builtin.local_costmap_rate_hz == pytest.approx(10.0)  # noqa: SLF001

    fast = NavConfig.from_dict(
        {"slam_service": "s", "base": "b", "control_rate_hz": 20.0}
    )
    fast_nav = make_builtin_navigator(world, fast)
    assert fast_nav._cfg.control_period_s() == pytest.approx(0.05)  # noqa: SLF001
    # Local costmap rate stays independent of control rate.
    assert fast_nav._cfg.builtin.local_costmap_rate_hz == pytest.approx(10.0)  # noqa: SLF001
    tuned = NavConfig.from_dict(
        {
            "slam_service": "s",
            "base": "b",
            "control_rate_hz": 20.0,
            "builtin": {"local_costmap_rate_hz": 2.0},
        }
    )
    tuned_nav = make_builtin_navigator(world, tuned)
    assert tuned_nav._cfg.builtin.local_costmap_rate_hz == pytest.approx(2.0)  # noqa: SLF001
    status = host.nav_status()
    assert status["nav_backend"] == "builtin"


def test_viam_world_io_prefers_shm_scan():
    """Control-loop scan path should hit shm without calling the camera."""
    import time as _time

    from src.config import LidarConfig
    from src.shm import pcshm
    from src.shm.lidar import ShmPointCloudClient

    min_pcd = (
        b"# .PCD v0.7\nVERSION 0.7\nFIELDS x y z\nSIZE 4 4 4\nTYPE F F F\n"
        b"COUNT 1 1 1\nWIDTH 1\nHEIGHT 1\nPOINTS 1\nDATA ascii\n1 0 0\n"
    )
    loop = asyncio.new_event_loop()
    name = "/viam-pc-test-nav"
    writer = pcshm.open_writer(name)
    client = ShmPointCloudClient()
    try:
        writer.write(min_pcd, timestamp_ns=_time.time_ns())
        lidar = LidarConfig(
            name="lidar",
            shm_name=name,
            shm_required=True,
            scan_source="point_cloud",
            points_in_base_link=True,
        )
        cam = MagicMock()
        cam.get_point_cloud = AsyncMock(
            side_effect=AssertionError("gRPC should not be used")
        )
        world = ViamWorldIO(
            slam=MagicMock(),
            base=MagicMock(),
            loop=loop,
            cameras={"lidar": cam},
            lidars=[lidar],
            shm_lidar=client,
            scan_max_age_s=2.0,
        )
        scan = world.get_scan()
        assert scan is not None
        assert conv.scan_has_returns(scan)
        cam.get_point_cloud.assert_not_called()
        stats = client.status()[pcshm.normalize_name(name)]
        assert stats["hits"] >= 1
    finally:
        client.close()
        writer.close()
        pcshm._try_unlink(name)
        loop.close()


@pytest.mark.asyncio
async def test_viam_world_io_prefers_slam_get_position_pose2d_sync():
    loop = asyncio.get_event_loop()
    live = {"pose": conv.Pose2D(-0.130, 0.607, math.radians(84.7))}

    class _Slam:
        def get_position_pose2d(self):
            return live["pose"]

        async def get_position(self):
            raise AssertionError("async GetPosition must not run when sync pose works")

        async def do_command(self, *_a, **_k):
            return {}

    world = ViamWorldIO(
        slam=_Slam(),
        base=MagicMock(),
        loop=loop,
        cameras={},
        lidars=[],
        # Provider is secondary to local slam sync helper.
        pose_provider=lambda: conv.Pose2D(0.0, 0.0, 0.0),
        map_provider=lambda: {
            "grid": np.zeros((2, 2), dtype=np.int16),
            "resolution": 0.05,
            "origin_x": 0.0,
            "origin_y": 0.0,
        },
    )
    p2 = await asyncio.to_thread(world.get_pose)
    assert p2 is not None
    assert p2.x == pytest.approx(-0.130)
    assert p2.y == pytest.approx(0.607)
    assert p2.theta == pytest.approx(math.radians(84.7))
    assert world.pose_source() == "get_position_sync"
    live["pose"] = conv.Pose2D(1.0, 2.0, 0.5)
    p3 = await asyncio.to_thread(world.get_pose)
    assert p3.x == pytest.approx(1.0)
    assert p3.y == pytest.approx(2.0)


@pytest.mark.asyncio
async def test_viam_world_io_prefers_pose_provider_over_async_get_position():
    """Sync provider must win so SetVelocity keeps event-loop bandwidth."""
    loop = asyncio.get_event_loop()

    async def _boom():
        raise AssertionError("async GetPosition must not run when pose_provider works")

    slam = MagicMock(spec=["get_position", "do_command"])
    slam.get_position = AsyncMock(side_effect=_boom)
    slam.do_command = AsyncMock(return_value={})
    live = {"pose": conv.Pose2D(-0.130, 0.607, math.radians(84.7))}
    world = ViamWorldIO(
        slam=slam,
        base=MagicMock(),
        loop=loop,
        cameras={},
        lidars=[],
        pose_provider=lambda: live["pose"],
    )
    p2 = await asyncio.to_thread(world.get_pose)
    assert p2.x == pytest.approx(-0.130)
    assert world.pose_source() == "in_process"
    slam.get_position.assert_not_awaited()


@pytest.mark.asyncio
async def test_viam_world_io_uses_async_get_position_when_no_sync_source():
    loop = asyncio.get_event_loop()
    slam = MagicMock(spec=["get_position", "do_command"])
    slam.get_position = AsyncMock(
        return_value=SimpleNamespace(
            x=-130.0, y=607.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=84.7
        )
    )
    slam.do_command = AsyncMock(return_value={})
    world = ViamWorldIO(
        slam=slam,
        base=MagicMock(),
        loop=loop,
        cameras={},
        lidars=[],
    )
    p2 = await asyncio.to_thread(world.get_pose)
    assert p2 is not None
    assert p2.x == pytest.approx(-0.130)
    assert p2.y == pytest.approx(0.607)
    assert world.pose_source() == "get_position"
    slam.get_position.assert_awaited()


@pytest.mark.asyncio
async def test_viam_world_io_last_drive_issued_only_after_set_velocity():
    loop = asyncio.get_event_loop()
    base = MagicMock()
    base.name = "tracer"
    base.set_velocity = AsyncMock()
    slam = MagicMock(spec=["get_position", "do_command"])
    slam.get_position = AsyncMock(
        return_value=SimpleNamespace(
            x=0.0, y=0.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0
        )
    )
    world = ViamWorldIO(
        slam=slam,
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
    )
    await asyncio.to_thread(world.set_velocity, 0.2, 0.0, -1.0)
    drive = world.last_drive()
    assert drive is not None
    assert drive["issued"] is True
    assert drive["error"] is None
    assert drive["base"] == "tracer"
    assert drive["viam_linear_y_mm_s"] == pytest.approx(200.0)
    assert drive["viam_angular_z_deg_s"] == pytest.approx(-math.degrees(1.0))
    base.set_velocity.assert_awaited()

    base.set_velocity = AsyncMock(side_effect=RuntimeError("base refused"))
    with pytest.raises(RuntimeError, match="base refused"):
        await asyncio.to_thread(world.set_velocity, 0.3, 0.0, 0.0)
    drive = world.last_drive()
    assert drive["issued"] is False
    assert "refused" in (drive["error"] or "").lower()
    assert drive["viam_linear_y_mm_s"] == pytest.approx(300.0)


@pytest.mark.asyncio
async def test_set_velocity_leaves_command_pending_when_loop_busy():
    """Soft-loc occupying the module loop must not cancel SetVelocity."""
    loop = asyncio.get_event_loop()
    base = MagicMock()
    base.name = "tracer"
    release = asyncio.Event()

    async def _slow_set_velocity(**kwargs):
        del kwargs
        await release.wait()

    base.set_velocity = _slow_set_velocity
    slam = MagicMock(spec=["get_position", "do_command"])
    world = ViamWorldIO(
        slam=slam,
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
        drive_timeout_s=5.0,
    )
    world._drive_ack_timeout_s = 0.05

    t0 = time.monotonic()
    await asyncio.to_thread(world.set_velocity, 0.2, 0.0, 0.0)
    assert time.monotonic() - t0 < 1.0
    drive = world.last_drive()
    assert drive["issued"] is False
    assert drive.get("pending") is True
    assert drive.get("error") is None

    release.set()
    await asyncio.sleep(0.05)
    drive = world.last_drive()
    assert drive["issued"] is True
    assert drive.get("error") is None


@pytest.mark.asyncio
async def test_set_velocity_skips_duplicate_twist():
    """Identical sanitized cmds must not schedule another SetVelocity RPC."""
    loop = asyncio.get_event_loop()
    base = MagicMock()
    base.name = "tracer"
    base.set_velocity = AsyncMock()
    world = ViamWorldIO(
        slam=MagicMock(spec=["get_position", "do_command"]),
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
    )
    await asyncio.to_thread(world.set_velocity, 0.2, 0.0, 0.0)
    await asyncio.to_thread(world.set_velocity, 0.2, 0.0, 0.0)
    assert base.set_velocity.await_count == 1
    drive = world.last_drive()
    assert drive["skipped"] is True
    assert drive["issued"] is True
    stats = world.drive_stats()
    assert stats["calls"] == 1
    assert stats["skipped"] == 1

    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.0)
    assert base.set_velocity.await_count == 2
    assert world.drive_stats()["calls"] == 2


@pytest.mark.asyncio
async def test_set_velocity_refreshes_duplicate_before_base_watchdog():
    """Held twists must be re-issued so the base does not coast to a stop."""
    loop = asyncio.get_event_loop()
    base = MagicMock()
    base.name = "tracer"
    base.set_velocity = AsyncMock()
    world = ViamWorldIO(
        slam=MagicMock(spec=["get_position", "do_command"]),
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
    )
    world._drive_refresh_s = 0.05  # noqa: SLF001
    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.6)
    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.6)
    assert base.set_velocity.await_count == 1
    await asyncio.sleep(0.06)
    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.6)
    assert base.set_velocity.await_count == 2
    assert world.last_drive().get("skipped") is not True
    assert world.drive_stats()["calls"] == 2


@pytest.mark.asyncio
async def test_set_velocity_coalesces_instead_of_superseding():
    """Rapid control ticks must not cancel an in-flight SetVelocity.

    Cancelling mid-RPC left last_drive.error=superseded and the robot never
    turned — stall detector then failed the goal.
    """
    loop = asyncio.get_event_loop()
    base = MagicMock()
    base.name = "tracer"
    release = asyncio.Event()
    calls: list[float] = []

    async def _slow_set_velocity(**kwargs):
        ang = float(kwargs["angular"].z)
        calls.append(ang)
        await release.wait()

    base.set_velocity = _slow_set_velocity
    world = ViamWorldIO(
        slam=MagicMock(spec=["get_position", "do_command"]),
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
        drive_timeout_s=5.0,
    )
    world._drive_ack_timeout_s = 0.05

    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.6)
    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.5)
    drive = world.last_drive()
    assert drive.get("coalesced") is True
    assert drive.get("error") != "superseded"
    assert drive.get("skipped") is not True
    assert len(calls) == 1  # second cmd waited; did not cancel the first

    release.set()
    await asyncio.sleep(0.1)
    assert len(calls) == 2
    drive = world.last_drive()
    assert drive["issued"] is True
    assert drive.get("error") is None
    assert abs(drive["body_vtheta_rad_s"]) == pytest.approx(0.5)
    assert world.drive_stats()["coalesced"] == 1


@pytest.mark.asyncio
async def test_near_zero_rpm_retry_widens_arc_instead_of_spinning():
    """A translating arc the base rejects (inner wheel ~0) must be retried as a
    wider arc, not converted to a pure spin — spins mid-path throw the heading."""
    loop = asyncio.get_event_loop()
    base = MagicMock()
    base.name = "tracer"
    rpm_err = Exception("Cannot move motor at an RPM that is nearly 0")
    base.set_velocity = AsyncMock(side_effect=[rpm_err, None])
    world = ViamWorldIO(
        slam=MagicMock(spec=["get_position", "do_command"]),
        base=base,
        loop=loop,
        cameras={},
        lidars=[],
        base_velocity_convention="viam",
    )
    await asyncio.to_thread(world.set_velocity, 0.15, 0.0, 0.6)
    assert base.set_velocity.await_count == 2
    retry = base.set_velocity.await_args_list[1].kwargs
    # Still translating (viam convention: ROS vx → linear.y), faster than asked.
    assert retry["linear"].y > 150.0
    assert retry["angular"].z == pytest.approx(math.degrees(0.6))
    drive = world.last_drive()
    assert drive["issued"] is True
    assert drive["retry"]["kind"] == "widen_arc"

    # A rejected pure spin still retries as a spin.
    base.set_velocity = AsyncMock(side_effect=[rpm_err, None])
    await asyncio.to_thread(world.set_velocity, 0.0, 0.0, 0.3)
    retry = base.set_velocity.await_args_list[1].kwargs
    assert retry["linear"].y == 0.0
    assert world.last_drive()["retry"]["kind"] == "spin"


def test_sync_slam_pose_provider_uses_registered_service(monkeypatch):
    from src.models import navigation as nav_mod

    class _Svc:
        def get_position_pose2d(self):
            return conv.Pose2D(1.25, -0.5, 0.3)

    monkeypatch.setattr(nav_mod, "get_slam_service", lambda _n: _Svc())
    monkeypatch.setattr(nav_mod, "get_slam", lambda _n: None)
    provider = nav_mod._sync_slam_pose_provider("slam")
    assert provider() == conv.Pose2D(1.25, -0.5, 0.3)


@pytest.mark.asyncio
async def test_obstacles_only_scan_never_blocks_on_point_cloud():
    """Hot-path get_scan must return cache without waiting on RealSense PCD."""
    import time

    from src.config import LidarConfig

    loop = asyncio.get_running_loop()

    async def _hang(*_a, **_k):
        await asyncio.sleep(3600.0)

    cam = MagicMock()
    cam.get_point_cloud = AsyncMock(side_effect=_hang)
    slam = MagicMock(spec=["get_position", "do_command"])
    slam.get_position = AsyncMock(
        return_value=SimpleNamespace(
            x=0.0, y=0.0, z=0.0, o_x=0.0, o_y=0.0, o_z=1.0, theta=0.0
        )
    )
    # Fresh enough that kick skips scheduling a refresh.
    depth = LidarConfig(
        name="camera",
        scan_source="point_cloud",
        obstacles_only=True,
        cloud_frame="camera_optical",
        shm_name=None,
    )
    world = ViamWorldIO(
        slam=slam,
        base=MagicMock(),
        loop=loop,
        cameras={"camera": cam},
        lidars=[depth],
        obstacles_only_period_s=0.1,
    )
    assert world._obstacles_only_period_s == pytest.approx(0.1)  # noqa: SLF001
    seeded = conv.points_to_scan(np.array([[1.0, 0.0]]), num_bins=360)
    seeded = conv.LaserScan2D(
        ranges=seeded.ranges,
        angle_min=seeded.angle_min,
        angle_increment=seeded.angle_increment,
        range_min=seeded.range_min,
        range_max=seeded.range_max,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )
    world._per_lidar_scan["camera"] = (seeded, time.monotonic())  # noqa: SLF001

    t0 = time.monotonic()
    scan = await asyncio.to_thread(world.get_scan, 2.0)
    assert time.monotonic() - t0 < 1.0
    assert scan is not None
    cam.get_point_cloud.assert_not_awaited()


def test_align_obstacles_scan_drops_when_pose_moved_too_far():
    """Stale depth after a large move must not paint phantom obstacles."""
    from src.config import LidarConfig

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[
            LidarConfig(name="camera", scan_source="point_cloud", obstacles_only=True)
        ],
    )
    scan = conv.points_to_scan(np.array([[1.5, 0.0]]), num_bins=72)
    scan = conv.LaserScan2D(
        ranges=scan.ranges,
        angle_min=scan.angle_min,
        angle_increment=scan.angle_increment,
        range_min=scan.range_min,
        range_max=scan.range_max,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )
    # Moved 0.5 m — beyond _obstacles_max_shift_m.
    assert (
        world._align_obstacles_scan_to_pose(scan, conv.Pose2D(0.5, 0.0, 0.0))  # noqa: SLF001
        is None
    )


def test_align_obstacles_scan_motion_compensates_small_shift():
    """Small pose change should warp depth hits into the live base_link."""
    from src.config import LidarConfig

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[
            LidarConfig(name="camera", scan_source="point_cloud", obstacles_only=True)
        ],
    )
    # Hit 1 m ahead at capture pose.
    scan = conv.points_to_scan(np.array([[1.0, 0.0]]), num_bins=72)
    scan = conv.LaserScan2D(
        ranges=scan.ranges,
        angle_min=scan.angle_min,
        angle_increment=scan.angle_increment,
        range_min=scan.range_min,
        range_max=scan.range_max,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )
    # Robot moved +0.2 m in x; same hit is now 0.8 m ahead in body frame.
    aligned = world._align_obstacles_scan_to_pose(  # noqa: SLF001
        scan, conv.Pose2D(0.2, 0.0, 0.0)
    )
    assert aligned is not None
    pts = aligned.to_points()
    assert pts.shape[0] >= 1
    assert abs(float(pts[0, 0]) - 0.8) < 0.08
    assert abs(float(pts[0, 1])) < 0.08


def test_align_obstacles_scan_small_shift_still_warps():
    """Regression: sub-8 cm moves must warp, not restamp capture_pose only."""
    from src.config import LidarConfig

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[
            LidarConfig(name="camera", scan_source="point_cloud", obstacles_only=True)
        ],
    )
    scan = conv.points_to_scan(np.array([[1.0, 0.0]]), num_bins=72)
    scan = conv.LaserScan2D(
        ranges=scan.ranges,
        angle_min=scan.angle_min,
        angle_increment=scan.angle_increment,
        range_min=scan.range_min,
        range_max=scan.range_max,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )
    # 5 cm — previously took the broken early-exit that skipped the warp.
    aligned = world._align_obstacles_scan_to_pose(  # noqa: SLF001
        scan, conv.Pose2D(0.05, 0.0, 0.0)
    )
    assert aligned is not None
    pts = aligned.to_points()
    assert abs(float(pts[0, 0]) - 0.95) < 0.08


def test_get_scan_can_exclude_obstacles_only_lidars():
    """Loc refine (include_obstacles_only=False) must not merge depth."""
    from src.config import LidarConfig

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[
            LidarConfig(name="lidar", scan_source="get_laser_scan"),
            LidarConfig(name="camera", scan_source="point_cloud", obstacles_only=True),
        ],
    )
    lidar_scan = conv.LaserScan2D(
        ranges=np.full(8, 2.0),
        angle_min=-math.pi,
        angle_increment=math.pi / 4,
        range_min=0.05,
        range_max=10.0,
    )
    depth_scan = conv.LaserScan2D(
        ranges=np.full(8, 0.8),
        angle_min=-math.pi,
        angle_increment=math.pi / 4,
        range_min=0.05,
        range_max=10.0,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )

    def _read(lidar, max_age_s=2.0):
        if lidar.name == "lidar":
            return lidar_scan
        return depth_scan

    world.get_pose = MagicMock(return_value=conv.Pose2D(0.0, 0.0, 0.0))
    world._read_lidar_scan_sync = MagicMock(side_effect=_read)  # noqa: SLF001

    full = world.get_scan(2.0, include_obstacles_only=True)
    lidar_only = world.get_scan(2.0, include_obstacles_only=False)
    assert full is not None and lidar_only is not None
    # Real depth closer than lidar is kept; lidar-only stays far.
    assert float(np.nanmin(full.ranges)) == pytest.approx(0.8)
    assert float(np.nanmin(lidar_only.ranges)) > 1.5

    # Near depth that lidar contradicts is treated as a phantom.
    phantom = conv.LaserScan2D(
        ranges=np.full(8, 0.05),
        angle_min=-math.pi,
        angle_increment=math.pi / 4,
        range_min=0.05,
        range_max=10.0,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )

    def _read_phantom(lidar, max_age_s=2.0):
        if lidar.name == "lidar":
            return lidar_scan
        return phantom

    world._scan_cache = None  # noqa: SLF001
    world._read_lidar_scan_sync = MagicMock(side_effect=_read_phantom)  # noqa: SLF001
    full_phantom = world.get_scan(2.0, include_obstacles_only=True)
    assert full_phantom is not None
    assert float(np.nanmin(full_phantom.ranges)) == pytest.approx(2.0)


def test_get_scan_moves_a_late_lidar_frame_to_the_current_pose():
    """A wall 2 m ahead, seen 0.2 s ago while driving 0.5 m/s, is 1.9 m now."""
    from src.config import LidarConfig

    captured = conv.Pose2D(1.0, 0.0, 0.0)
    current = conv.Pose2D(1.1, 0.0, 0.0)
    asked = []

    def _pose_at(t):
        asked.append(t)
        return captured

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[LidarConfig(name="lidar", scan_source="get_laser_scan")],
        pose_at_provider=_pose_at,
    )
    wall = conv.points_to_scan(
        np.array([[2.0, y] for y in np.linspace(-0.3, 0.3, 13)]),
        angle_min=-math.pi,
        angle_max=math.pi,
        num_bins=360,
        range_min=0.05,
        range_max=10.0,
    )

    def _read(lidar, max_age_s=2.0):
        world._read_captured_at[lidar.name] = 42.0  # noqa: SLF001
        return wall

    world.get_pose = MagicMock(return_value=current)
    world._read_lidar_scan_sync = MagicMock(side_effect=_read)  # noqa: SLF001

    got = world.get_scan(2.0)
    assert got is not None
    assert asked == [42.0]
    assert got.capture_pose == current
    ahead = got.to_points()
    ahead = ahead[np.abs(ahead[:, 1]) < 0.05]
    assert float(np.median(ahead[:, 0])) == pytest.approx(1.9, abs=0.01)


def test_get_scan_lidar_only_does_not_fall_back_to_depth():
    """include_obstacles_only=False must not return depth when lidar is silent."""
    from src.config import LidarConfig

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[
            LidarConfig(name="lidar", scan_source="get_laser_scan"),
            LidarConfig(name="camera", scan_source="point_cloud", obstacles_only=True),
        ],
    )
    depth_scan = conv.LaserScan2D(
        ranges=np.full(8, 0.05),
        angle_min=-math.pi,
        angle_increment=math.pi / 4,
        range_min=0.05,
        range_max=10.0,
        capture_pose=conv.Pose2D(0.0, 0.0, 0.0),
    )

    def _read(lidar, max_age_s=2.0):
        if lidar.name == "lidar":
            return None
        return depth_scan

    world.get_pose = MagicMock(return_value=conv.Pose2D(0.0, 0.0, 0.0))
    world._read_lidar_scan_sync = MagicMock(side_effect=_read)  # noqa: SLF001

    assert world.get_scan(2.0, include_obstacles_only=False) is None
    full = world.get_scan(2.0, include_obstacles_only=True)
    assert full is not None
    assert float(np.nanmin(full.ranges)) == pytest.approx(0.05)


def test_get_scan_drops_cache_when_lidar_frames_stop():
    """A dead lidar must not keep serving the last ranges forever."""
    from src.config import LidarConfig

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[LidarConfig(name="lidar", scan_source="get_laser_scan")],
    )
    old = conv.points_to_scan(np.array([[2.0, 0.0]]), num_bins=16)
    world._scan_cache = old  # noqa: SLF001
    world._scan_cache_at = time.monotonic() - 10.0  # noqa: SLF001
    world._read_lidar_scan_sync = MagicMock(return_value=None)  # noqa: SLF001

    assert world.get_scan(2.0) is None

    world._scan_cache_at = time.monotonic()  # noqa: SLF001
    held = world.get_scan(2.0)
    assert held is old


def test_get_scan_drops_cache_when_no_lidars_configured():
    """An empty lidar list must not keep serving a dead provider's last scan."""
    scan = conv.points_to_scan(np.array([[2.0, 0.0]]), num_bins=16)
    provided = {"scan": scan}

    def _provider(_max_age_s: float):
        return provided["scan"]

    world = ViamWorldIO(
        slam=MagicMock(),
        base=MagicMock(),
        loop=MagicMock(),
        lidars=[],
        scan_provider=_provider,
    )
    world.get_pose = MagicMock(return_value=conv.Pose2D(0.0, 0.0, 0.0))
    first = world.get_scan(2.0)
    assert first is not None

    provided["scan"] = None
    world._scan_cache_at = time.monotonic() - 10.0  # noqa: SLF001
    assert world.get_scan(2.0) is None
    # Loc refine never falls back to the obstacle cache.
    assert world.get_scan(2.0, include_obstacles_only=False) is None

    world._scan_cache_at = time.monotonic()  # noqa: SLF001
    # Moved past the short-horizon cache hit, so this is the no-lidar fallback.
    world.get_pose = MagicMock(return_value=conv.Pose2D(1.0, 0.0, 0.0))
    assert world.get_scan(2.0) is first
    # max_age_s <= 0 asks not to expire, matching a missed lidar read.
    world._scan_cache_at = time.monotonic() - 10.0  # noqa: SLF001
    assert world.get_scan(0.0) is first
