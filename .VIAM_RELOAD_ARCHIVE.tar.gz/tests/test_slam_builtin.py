"""Unit tests for ROS-free builtin occupancy SLAM."""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np
import pytest

from src.config import (
    SLAM_BACKEND_BUILTIN,
    SlamConfig,
)
from src.geom import conversions as conv
from src.nav.io.viam_io import get_grid_response_to_map, map_dict_to_get_grid
from src.nav.stores.maps import MapStore
from src.slam_builtin import occupancy as occ
from src.slam_builtin import persistence, scan_match
from src.slam_builtin.engine import BuiltinSlamEngine
from src.slam_builtin.host import BuiltinSlamHost


def test_slam_backend_default_is_builtin():
    cfg = SlamConfig.from_dict({"base": "b", "lidar": "front"})
    assert cfg.slam_backend == SLAM_BACKEND_BUILTIN
    assert cfg.uses_builtin_slam()
    assert cfg.mapping_revisit_check is True
    assert cfg.mapping_revisit_while_moving is True
    assert cfg.builtin_rebuild_map_on_revisit is True


def test_slam_backend_toolbox_and_invalid():
    with pytest.raises(
        ValueError, match="pre-ros-removal|slam_toolbox|no longer supported"
    ):
        SlamConfig.from_dict(
            {"base": "b", "lidar": "front", "slam_backend": "slam_toolbox"}
        )
    with pytest.raises(ValueError, match="slam_backend"):
        SlamConfig.from_dict(
            {"base": "b", "lidar": "front", "slam_backend": "cartographer"}
        )


def test_map_handle_occupancy_readiness(tmp_path: Path):
    store = MapStore(str(tmp_path))
    handle = store.get_or_create_map("m1")
    assert not handle.has_serialized_map()
    assert not handle.has_occupancy_map()
    assert not handle.has_any_map()

    grid = occ.empty_grid(resolution=0.05, size_m=4.0)
    # Mark a few cells occupied so save is meaningful.
    grid.log_odds[40, 40] = 2.0
    persistence.save_occupancy(handle.root, grid)
    assert handle.has_occupancy_map()
    assert handle.has_any_map()
    listed = {m["name"]: m for m in store.list_maps()}
    assert listed["m1"]["has_map"] is True
    assert listed["m1"]["has_occupancy"] is True
    assert listed["m1"]["has_posegraph"] is False


def test_occupancy_insert_and_roundtrip(tmp_path: Path):
    grid = occ.empty_grid(resolution=0.05, size_m=10.0, origin_x=-5.0, origin_y=-5.0)
    # Single forward beam hits a wall at 2 m.
    ranges = np.array([2.0])
    grid = occ.insert_scan(
        grid,
        0.0,
        0.0,
        0.0,
        ranges,
        0.0,
        0.0,
        range_min=0.1,
        range_max=10.0,
    )
    int16 = occ.to_occupancy_int16(grid)
    row, col = grid.world_to_cell(2.0, 0.0)
    assert int16[row, col] == 100
    row_m, col_m = grid.world_to_cell(1.0, 0.0)
    # One free update may land in the mid-probability band; must not be occupied.
    assert int16[row_m, col_m] < 50
    assert int16[row_m, col_m] >= 0

    persistence.save_occupancy(tmp_path, grid)
    loaded = persistence.load_log_odds(tmp_path)
    assert loaded is not None
    assert loaded.resolution == pytest.approx(0.05)
    assert loaded.origin_x == pytest.approx(grid.origin_x)
    roundtrip = occ.to_occupancy_int16(loaded)
    assert roundtrip[row, col] == 100


def test_get_grid_roundtrip_encoding():
    grid = np.full((8, 10), -1, dtype=np.int16)
    grid[2:6, 3:7] = 0
    grid[4, 5] = 100
    map_data = {
        "grid": grid,
        "resolution": 0.05,
        "origin_x": -1.0,
        "origin_y": -2.0,
    }
    payload = map_dict_to_get_grid(map_data)
    back = get_grid_response_to_map(payload)
    assert back is not None
    assert back["resolution"] == pytest.approx(0.05)
    assert back["origin_x"] == pytest.approx(-1.0)
    assert back["origin_y"] == pytest.approx(-2.0)
    assert np.array_equal(back["grid"], grid)


def test_refine_pose_tracks_prior():
    # Synthetic corridor: occupied walls at y=±1.
    res = 0.05
    size = 80
    grid = np.full((size, size), 0, dtype=np.int16)
    origin = -size * res / 2
    for col in range(size):
        for wall_y in (-1.0, 1.0):
            row = int(math.floor((wall_y - origin) / res))
            if 0 <= row < size:
                grid[row, col] = 100
    occ_map = scan_match.occupancy_map_from_int16(
        grid, resolution=res, origin_x=origin, origin_y=origin
    )
    # Scan seeing both walls from origin.
    n = 60
    angles = np.linspace(-math.pi / 2, math.pi / 2, n)
    ranges = np.array([1.0 / max(abs(math.sin(a)), 0.2) for a in angles])
    ranges = np.clip(ranges, 0.2, 5.0)
    scan = conv.LaserScan2D(
        ranges, float(angles[0]), float(angles[1] - angles[0]), 0.1, 10.0
    )
    prior = conv.Pose2D(0.15, -0.10, math.radians(6.0))
    matched, score, prior_score, _rival = scan_match.refine_pose(
        occ_map,
        scan,
        prior,
        xy_half_m=0.25,
        yaw_half_deg=12.0,
        min_score=-0.5,
    )
    # Beams past this 4 m grid are unmapped, not wrong: the wide pass must
    # not slide the pose back to keep them inside.
    # With distance-weighted gating a modest offset may be rejected; either a
    # clear improvement toward origin or an explicit reject is OK.
    if matched is not None:
        assert abs(matched.x) < 0.12
        assert abs(matched.y) < 0.12
        assert score >= prior_score
    else:
        assert score < prior_score + scan_match._required_improvement(  # noqa: SLF001
            prior_score,
            0.15,
            math.radians(6.0),
        )


def test_refine_pose_rejects_weak_improvement():
    res = 0.05
    size = 40
    grid = np.full((size, size), 0, dtype=np.int16)
    origin = -size * res / 2
    # Sparse occupied speckles — any pose scores poorly.
    grid[20, 20] = 100
    occ_map = scan_match.occupancy_map_from_int16(
        grid, resolution=res, origin_x=origin, origin_y=origin
    )
    ranges = np.full(40, 1.0)
    scan = conv.LaserScan2D(ranges, -math.pi / 2, math.pi / 40, 0.1, 10.0)
    prior = conv.Pose2D(0.0, 0.0, 0.0)
    matched, score, prior_score, _rival = scan_match.refine_pose(
        occ_map, scan, prior, min_score=0.5
    )
    assert matched is None


def test_apply_match_small_correction_applies_immediately():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine._last_prior_score = 0.5  # noqa: SLF001
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    # 0.10 m correction = drift tracking; applied on the first frame.
    small = conv.Pose2D(0.10, 0.0, 0.0)
    assert engine._apply_match(predicted, small, None) is True  # noqa: SLF001
    # alpha 0.6 * 0.10 m
    assert engine.get_pose().x == pytest.approx(0.06, abs=1e-6)


def test_apply_match_large_jump_requires_two_frames():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine._last_prior_score = 0.5  # noqa: SLF001
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    peak_a = conv.Pose2D(0.40, 0.0, 0.0)
    peak_b = conv.Pose2D(-0.40, 0.0, 0.0)

    # Frame 1: see A — hold predicted.
    assert engine._apply_match(predicted, peak_a, None) is False  # noqa: SLF001
    assert engine.get_pose().x == pytest.approx(0.0)

    # Frame 2: flip to B — reset streak, still hold.
    assert engine._apply_match(predicted, peak_b, None) is False  # noqa: SLF001
    assert engine.get_pose().x == pytest.approx(0.0)

    # Two agreeing B frames — apply blended/clamped step toward B.
    assert engine._apply_match(predicted, peak_b, None) is True  # noqa: SLF001
    # alpha 0.6 * 0.40 = 0.24 m, inside the 0.25 m large-jump clamp.
    assert engine.get_pose().x == pytest.approx(-0.24, abs=1e-6)

    # Streak persists: the next agreeing frame keeps applying immediately.
    assert engine._apply_match(engine.get_pose(), peak_b, None) is True  # noqa: SLF001


def _nav_track_engine(monkeypatch, **cfg_extra):
    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidar": "front",
            "maps_dir": "/tmp",
            "mode": "localizing",
            **cfg_extra,
        }
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    monkeypatch.setattr(engine, "_navigation_active", lambda: True)
    engine._last_prior_score = 0.45  # noqa: SLF001
    engine._last_match_score = 0.60  # noqa: SLF001
    engine._last_yaw_rate = 0.0  # noqa: SLF001
    engine._last_scan_age_s = 0.02  # noqa: SLF001
    return engine


def test_apply_match_tracks_drift_during_nav(monkeypatch):
    """A fitting prior and a lone peak pull the pose back while driving."""
    engine = _nav_track_engine(monkeypatch)
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    small = conv.Pose2D(0.10, 0.04, math.radians(2.0))
    assert engine._apply_match(predicted, small, None) is True  # noqa: SLF001
    pose = engine.get_pose()
    assert pose.x == pytest.approx(0.06, abs=1e-6)
    assert pose.y == pytest.approx(0.024, abs=1e-6)
    assert pose.theta == pytest.approx(math.radians(1.2), abs=1e-6)
    assert engine.diagnostics()["drive_applies"] == 1


def test_apply_match_holds_during_nav_without_a_clear_peak(monkeypatch):
    """A spinning scan, a weak prior, or a close rival keeps odometry."""
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    small = conv.Pose2D(0.10, 0.0, 0.0)

    turning = _nav_track_engine(monkeypatch)
    turning._last_yaw_rate = math.radians(30.0)  # noqa: SLF001
    assert turning._apply_match(predicted, small, None) is False  # noqa: SLF001

    weak_prior = _nav_track_engine(monkeypatch)
    weak_prior._last_prior_score = 0.20  # noqa: SLF001
    assert weak_prior._apply_match(predicted, small, None) is False  # noqa: SLF001

    # A corridor ridge: a cell 0.4 m away scores within 0.08 of the winner.
    ridge = _nav_track_engine(monkeypatch)
    ridge._last_match_rival_score = 0.56  # noqa: SLF001
    assert ridge._apply_match(predicted, small, None) is False  # noqa: SLF001
    for eng in (turning, weak_prior, ridge):
        assert eng.get_pose().x == pytest.approx(0.0)
        assert eng.diagnostics()["drive_applies"] == 0


def test_apply_match_walks_a_strong_jump_in_while_driving(monkeypatch):
    """A 0.4 m slip with a strong lone peak closes at the drift step."""
    engine = _nav_track_engine(monkeypatch)
    engine._last_prior_score = -0.1  # noqa: SLF001 - the pose is off the wall
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    large = conv.Pose2D(0.40, 0.0, 0.0)
    assert engine._apply_match(predicted, large, None) is False  # noqa: SLF001
    assert engine._apply_match(predicted, large, None) is True  # noqa: SLF001
    # alpha 0.6 * 0.40 = 0.24 m, capped at the 0.15 m drift step while driving.
    assert engine.get_pose().x == pytest.approx(0.15, abs=1e-6)

    weak = _nav_track_engine(monkeypatch)
    weak._last_match_score = 0.40  # noqa: SLF001 - under the recovery floor
    assert weak._apply_match(predicted, large, None) is False  # noqa: SLF001
    assert weak._apply_match(predicted, large, None) is False  # noqa: SLF001
    assert weak.get_pose().x == pytest.approx(0.0)


def test_predict_rejects_a_heading_step_the_body_cannot_turn():
    """35 deg in one 10 Hz sample is a magnetometer snap; 8 deg is a turn."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=10.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 10.0
    engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0, 0.0, 0.0, pose=conv.Pose2D(0.0, 0.0, 0.0), heading_rad=0.0
        ),
        t0,
    )
    # Wheels say 2 deg; the heading sensor jumps 35 deg. Wheels win.
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            0.0,
            pose=conv.Pose2D(0.0, 0.0, math.radians(2.0)),
            heading_rad=math.radians(35.0),
        ),
        t0 + 0.1,
    )
    assert pose.theta == pytest.approx(math.radians(2.0), abs=1e-6)
    assert engine.diagnostics()["heading"]["snaps_rejected"] == 1
    # A real 80 deg/s turn is inside the body rate and is taken from the sensor.
    engine._pose = pose  # noqa: SLF001
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            0.0,
            pose=conv.Pose2D(0.0, 0.0, math.radians(9.0)),
            heading_rad=math.radians(43.0),
        ),
        t0 + 0.2,
    )
    assert pose.theta == pytest.approx(math.radians(10.0), abs=1e-6)


def test_predict_twist_path_rejects_a_heading_snap_and_keeps_the_gyro():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=10.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 20.0
    engine._predict(conv.OdomReading(0.0, 0.0, 0.1, heading_rad=0.0), t0)  # noqa: SLF001
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(0.0, 0.0, 0.1, heading_rad=math.radians(30.0)), t0 + 0.1
    )
    # gyro 0.1 rad/s over 0.1 s
    assert pose.theta == pytest.approx(0.01, abs=1e-6)
    assert engine.diagnostics()["heading"]["snaps_rejected"] == 1


def test_yaw_only_correction_turns_a_driving_pose_back(monkeypatch):
    """A held full match still closes the heading while a goal is active."""
    engine = _nav_track_engine(monkeypatch)
    engine._last_prior_score = -0.2  # noqa: SLF001 - XY is off, full match held
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    far = conv.Pose2D(0.9, 0.0, math.radians(10.0))
    engine._last_match_score = 0.30  # noqa: SLF001 - under the recovery floor
    yaw_fix = (math.radians(10.0), 0.55, 0.10, 0.05)
    assert engine._apply_match(predicted, far, None, yaw_fix=yaw_fix) is True  # noqa: SLF001
    pose = engine.get_pose()
    assert pose.x == pytest.approx(0.0)
    # alpha 0.5 * 10 deg, capped at the 4 deg step
    assert pose.theta == pytest.approx(math.radians(4.0), abs=1e-6)
    diag = engine.diagnostics()
    assert diag["yaw_only_applies"] == 1
    assert diag["heading"]["scan_corrections"] == 1
    assert diag["heading"]["scan_corrected_deg"] == pytest.approx(4.0, abs=0.01)

    # Two headings that score alike are not a direction.
    tie = (math.radians(10.0), 0.55, 0.10, 0.50)
    assert engine._apply_match(predicted, far, None, yaw_fix=tie) is False  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(0.0)
    # Idle: the heading-only path stays off.
    monkeypatch.setattr(engine, "_navigation_active", lambda: False)
    assert engine._apply_match(predicted, far, None, yaw_fix=yaw_fix) is False  # noqa: SLF001


def test_refine_yaw_finds_the_heading_in_a_corridor():
    """Along a hall XY is a toss-up; the heading is still observable."""
    res = 0.05
    size = 160
    grid = np.full((size, size), 0, dtype=np.int16)
    origin = -size * res / 2
    for col in range(size):
        for wall_y in (-1.0, 1.0):
            row = int(math.floor((wall_y - origin) / res))
            grid[row, col] = 100
    occ_map = scan_match.occupancy_map_from_int16(
        grid, resolution=res, origin_x=origin, origin_y=origin
    )
    truth = conv.Pose2D(0.0, 0.0, 0.0)
    scan = _room_scan(truth, half_x=3.9, half_y=1.0)
    # The pose is 1.5 m down the hall and 12 deg off.
    prior = conv.Pose2D(1.5, 0.0, math.radians(12.0))
    yaw, best, prior_score, rival = scan_match.refine_yaw(occ_map, scan, prior)
    assert yaw is not None
    assert abs(conv.normalize_angle(yaw)) <= math.radians(2.0)
    assert best > prior_score + 0.05
    assert best - rival >= 0.08


def test_apply_match_strong_lone_peak_recovers_a_lost_prior_when_idle():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine._last_prior_score = -0.3  # noqa: SLF001
    engine._last_match_score = 0.62  # noqa: SLF001
    engine._last_match_rival_score = 0.21  # noqa: SLF001
    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    peak = conv.Pose2D(0.0, 0.50, math.radians(15.0))
    assert engine._apply_match(predicted, peak, None) is False  # noqa: SLF001
    assert engine._apply_match(predicted, peak, None) is True  # noqa: SLF001
    pose = engine.get_pose()
    assert pose.y == pytest.approx(0.25, abs=1e-6)
    assert pose.theta == pytest.approx(math.radians(9.0), abs=1e-6)


def test_apply_match_odom_only_when_prior_untrusted(monkeypatch):
    """Idle/paused with a bad prior must not creep toward local twins."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    monkeypatch.setattr(engine, "_navigation_active", lambda: False)

    predicted = conv.Pose2D(0.0, 0.0, 0.0)
    engine._last_prior_score = -0.4  # noqa: SLF001
    small = conv.Pose2D(0.10, 0.0, 0.0)
    large = conv.Pose2D(0.40, 0.0, 0.0)
    assert engine._apply_match(predicted, small, None) is False  # noqa: SLF001
    assert engine._apply_match(predicted, large, None) is False  # noqa: SLF001
    assert engine._apply_match(predicted, large, None) is False  # noqa: SLF001
    assert engine.get_pose().x == pytest.approx(0.0)

    # Trusted prior: small drift still applies when idle.
    engine._last_prior_score = 0.45  # noqa: SLF001
    assert engine._apply_match(predicted, small, None) is True  # noqa: SLF001
    assert engine.get_pose().x == pytest.approx(0.06, abs=1e-6)


def test_predict_absolute_odom_uses_deltas_and_gates_jumps():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(5.0, 5.0, math.radians(90.0)))

    t0 = 50.0
    # First absolute odom sample only seeds the reference — no pose change,
    # even though the odom frame (0,0,0) is nowhere near the map pose.
    odom0 = conv.OdomReading(0.0, 0.0, 0.0, pose=conv.Pose2D(0.0, 0.0, 0.0))
    p0 = engine._predict(odom0, t0)  # noqa: SLF001
    assert p0.x == pytest.approx(5.0)
    assert p0.theta == pytest.approx(math.radians(90.0))

    # Forward 0.1 m in the odom frame → forward 0.1 m along map heading (90°).
    odom1 = conv.OdomReading(0.0, 0.0, 0.0, pose=conv.Pose2D(0.1, 0.0, 0.0))
    engine._pose = p0  # noqa: SLF001
    p1 = engine._predict(odom1, t0 + 0.1)  # noqa: SLF001
    assert p1.x == pytest.approx(5.0, abs=1e-6)
    assert p1.y == pytest.approx(5.1, abs=1e-6)

    # A 90° heading snap in the odom pose (magnetometer jump) is rejected.
    odom2 = conv.OdomReading(
        0.0, 0.0, 0.0, pose=conv.Pose2D(0.1, 0.0, math.radians(90.0))
    )
    engine._pose = p1  # noqa: SLF001
    p2 = engine._predict(odom2, t0 + 0.2)  # noqa: SLF001
    assert p2.x == pytest.approx(p1.x)
    assert p2.y == pytest.approx(p1.y)
    assert p2.theta == pytest.approx(p1.theta)


def test_follow_command_intermediate_target_never_marks_done():
    from src.nav.control.controller import FollowerConfig, compute_follow_command
    from src.nav.types import Pose2D

    cfg = FollowerConfig()
    cfg.motion.xy_tolerance_m = 0.25
    current = Pose2D(0.0, 0.0, 0.0)
    target = Pose2D(0.1, 0.0, 0.0)  # within 0.5 * xy_tol
    cmd = compute_follow_command(current, target, cfg=cfg, final_yaw=None)
    assert not cmd.done


def test_host_relocalize_applies_drift_correction():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    host = BuiltinSlamHost(engine)
    engine.set_pose(conv.Pose2D(1.0, 1.0, 0.0))

    # 0.2 m drift fix from periodic relocalize should apply (not soft-gated).
    host.relocalize(conv.Pose2D(1.2, 1.0, 0.0))
    assert engine.get_pose().x == pytest.approx(1.2)


def test_host_relocalize_soft_seed():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    host = BuiltinSlamHost(engine)
    engine.set_pose(conv.Pose2D(1.0, 1.0, 0.0))

    # Tiny nudge within the continuous matcher's band is still a no-op.
    host.relocalize(conv.Pose2D(1.1, 1.05, math.radians(5.0)))
    assert engine.get_pose().x == pytest.approx(1.0)
    assert engine.get_pose().y == pytest.approx(1.0)

    # A genuinely different pose (recovery) still hard-applies.
    host.relocalize(conv.Pose2D(3.0, 1.0, 0.0))
    assert engine.get_pose().x == pytest.approx(3.0)

    # set_initial_pose stays a hard snap regardless of distance.
    host.set_initial_pose(conv.Pose2D(3.05, 1.0, 0.0))
    assert engine.get_pose().x == pytest.approx(3.05)


def test_predict_uses_heading_delta_not_absolute():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    store = MapStore("/tmp")
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), store, rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(1.0, 2.0, math.radians(30.0)))
    # First sample seeds heading; pose yaw must stay at map 30°.
    t0 = 100.0
    odom0 = conv.OdomReading(0.0, 0.0, 0.0, heading_rad=math.radians(90.0))
    p0 = engine._predict(odom0, t0)  # noqa: SLF001
    assert p0.theta == pytest.approx(math.radians(30.0), abs=1e-6)
    # +10° heading change → map yaw advances by ~10°, not snaps to 100°.
    odom1 = conv.OdomReading(0.0, 0.0, 0.0, heading_rad=math.radians(100.0))
    p1 = engine._predict(odom1, t0 + 0.1)  # noqa: SLF001
    assert p1.theta == pytest.approx(math.radians(40.0), abs=1e-3)
    assert abs(p1.theta - math.radians(100.0)) > 0.5


def _livox_mapping_cfg(**extra):
    raw = {
        "base": "b",
        "lidar": {"name": "livox", "scan_source": "point_cloud"},
        "movement_sensor": "imu",
        "maps_dir": "/tmp",
        "mode": "mapping",
    }
    raw.update(extra)
    return SlamConfig.from_dict(raw)


def test_large_resting_accel_is_absorbed_and_then_stops():
    """A Livox can sit on a constant accel larger than the deadband. That
    must not integrate forever (the parked cart sliding backward)."""
    cfg = _livox_mapping_cfg()
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 12.0
    # Seed the baseline at 0, then a steady negative reading (gravity leftover).
    rest = conv.OdomReading(0.0, 0.0, 0.0, ax=0.0, ay=0.0)
    parked = conv.OdomReading(0.0, 0.0, 0.0, ax=-0.6, ay=0.3)
    engine._pose = engine._predict(rest, t0)  # noqa: SLF001
    engine._pose = engine._predict(rest, t0 + 0.2)  # noqa: SLF001
    t = t0 + 0.2
    for _ in range(40):
        t += 0.2
        engine._pose = engine._predict(parked, t)  # noqa: SLF001
    stopped_at = engine.get_pose().x
    engine._pose = engine._predict(parked, t + 1.0)  # noqa: SLF001
    assert engine.get_pose().x == pytest.approx(stopped_at, abs=1e-6)
    assert engine.get_pose().y == pytest.approx(0.0, abs=1e-9)


def test_constant_accel_is_baseline_and_does_not_walk():
    """A Livox-style IMU can sit on a constant accel (tilt / leftover
    gravity). That steady reading is the zero, so a parked cart stays put."""
    cfg = _livox_mapping_cfg()
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 20.0
    parked = conv.OdomReading(0.0, 0.0, 0.0, ax=0.45, ay=1.0)

    def step(t, sample):
        engine._pose = engine._predict(sample, t)  # noqa: SLF001

    step(t0, parked)
    step(t0 + 0.5, parked)
    step(t0 + 1.5, parked)
    pose = engine.get_pose()
    assert pose.x == pytest.approx(0.0, abs=1e-6)
    assert pose.y == pytest.approx(0.0, abs=1e-9)


def test_accel_change_from_baseline_moves_along_map_x():
    """A Wit-style IMU rests near zero. A shove away from that baseline
    still moves the pose, and a sideways reading does not."""
    cfg = _livox_mapping_cfg()
    assert cfg.imu_odom_mode == "accel_only"
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 20.0
    rest = conv.OdomReading(0.0, 0.0, 0.0, ax=0.0, ay=1.0)
    shove = conv.OdomReading(0.0, 0.0, 0.0, ax=0.5, ay=1.0)

    def step(t, sample):
        engine._pose = engine._predict(sample, t)  # noqa: SLF001

    step(t0, rest)
    step(t0 + 0.2, rest)
    step(t0 + 0.4, shove)
    step(t0 + 0.6, shove)
    pose = engine.get_pose()
    assert pose.x > 0.02
    assert pose.y == pytest.approx(0.0, abs=1e-9)


def test_parked_gyro_bias_does_not_spin_accel_only_pose():
    """A few deg/s at rest must not walk heading. That plus the 1 s insert
    heartbeat is what smears a still cart into arcs."""
    cfg = _livox_mapping_cfg()
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 30.0
    bias = conv.OdomReading(0.0, 0.0, math.radians(2.0), ax=0.0, ay=0.0)
    engine._pose = engine._predict(bias, t0)  # noqa: SLF001
    engine._pose = engine._predict(bias, t0 + 2.0)  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(0.0, abs=1e-9)

    spin = conv.OdomReading(0.0, 0.0, math.radians(30.0), ax=0.0, ay=0.0)
    engine._pose = engine._predict(spin, t0 + 2.2)  # noqa: SLF001
    # The 2°/s resting rate stays in the bias; only the extra 28°/s turns.
    assert engine.get_pose().theta == pytest.approx(math.radians(28.0) * 0.2, abs=1e-6)


def test_coast_mode_still_integrates_small_yaw():
    """Wheel/laser setups keep slow gyro yaw. The still-gate is accel_only."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "mapping"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 4.0
    sample = conv.OdomReading(0.0, 0.0, math.radians(2.0))
    engine._pose = engine._predict(sample, t0)  # noqa: SLF001
    engine._pose = engine._predict(sample, t0 + 0.4)  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(math.radians(2.0) * 0.4, abs=1e-6)


def test_accel_below_deadband_does_not_creep():
    cfg = _livox_mapping_cfg()
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 5.0
    sample = conv.OdomReading(0.0, 0.0, 0.0, ax=0.05, ay=0.05)
    engine._predict(sample, t0)  # noqa: SLF001
    pose = engine._predict(sample, t0 + 1.0)  # noqa: SLF001
    assert pose.x == pytest.approx(0.0, abs=1e-9)
    assert pose.y == pytest.approx(0.0, abs=1e-9)


def test_accel_pulse_then_coasts():
    cfg = _livox_mapping_cfg()
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 8.0
    rest = conv.OdomReading(0.0, 0.0, 0.0, ax=0.0, ay=0.0)
    push = conv.OdomReading(0.0, 0.0, 0.0, ax=0.5, ay=0.0)
    engine._pose = engine._predict(rest, t0)  # noqa: SLF001
    engine._pose = engine._predict(rest, t0 + 0.2)  # noqa: SLF001
    engine._pose = engine._predict(push, t0 + 0.4)  # noqa: SLF001
    posed = engine.get_pose()
    assert posed.x > 0.01
    coast = conv.OdomReading(0.0, 0.0, 0.0, ax=0.0, ay=0.0)
    engine._pose = engine._predict(coast, t0 + 0.6)  # noqa: SLF001
    stopped = engine.get_pose()
    assert stopped.x == pytest.approx(posed.x, abs=1e-9)
    engine._pose = engine._predict(coast, t0 + 1.6)  # noqa: SLF001
    assert engine.get_pose().x == pytest.approx(stopped.x, abs=1e-9)


def test_wheel_twist_ignores_accel():
    """A reported linear velocity owns translation, even in accel_only mode."""
    cfg = _livox_mapping_cfg()
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 50.0
    wheels = conv.OdomReading(0.0, 0.5, 0.0, ax=3.0, ay=0.0)
    engine._predict(wheels, t0)  # noqa: SLF001
    pose = engine._predict(wheels, t0 + 0.2)  # noqa: SLF001
    assert pose.x == pytest.approx(0.1)
    assert pose.y == pytest.approx(0.0, abs=1e-12)


def test_laser_odom_config_does_not_integrate_accel():
    """Tracer-style laser SLAM defaults to coast and must not walk on accel."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "mapping"}
    )
    assert cfg.imu_odom_mode == "coast"
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 3.0
    sample = conv.OdomReading(0.0, 0.0, 0.0, ax=1.0, ay=0.0)
    engine._predict(sample, t0)  # noqa: SLF001
    pose = engine._predict(sample, t0 + 0.5)  # noqa: SLF001
    assert pose.x == pytest.approx(0.0, abs=1e-12)
    assert pose.y == pytest.approx(0.0, abs=1e-12)


def test_predict_viam_twist_forward_on_vy():
    """Default viam convention: body vy is forward → map +X at theta=0."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "mapping"}
    )
    store = MapStore("/tmp")
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), store, rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 50.0
    engine._predict(conv.OdomReading(0.0, 0.5, 0.0), t0)  # noqa: SLF001
    pose = engine._predict(conv.OdomReading(0.0, 0.5, 0.0), t0 + 0.2)  # noqa: SLF001
    assert pose.x == pytest.approx(0.1)
    assert pose.y == pytest.approx(0.0, abs=1e-12)


def test_predict_pose_plus_heading_uses_heading_delta_for_yaw():
    """Wheel pose + dedicated heading: yaw follows heading_sensor, not gyro."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "mapping"}
    )
    store = MapStore("/tmp")
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), store, rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 10.0
    odom0 = conv.OdomReading(
        0.0,
        0.0,
        0.5,  # noisy gyro rate — must not drive yaw when heading is present
        pose=conv.Pose2D(0.0, 0.0, math.radians(10.0)),
        heading_rad=math.radians(10.0),
    )
    engine._predict(odom0, t0)  # noqa: SLF001
    odom1 = conv.OdomReading(
        0.0,
        0.0,
        0.5,
        pose=conv.Pose2D(0.0, 0.0, math.radians(25.0)),
        heading_rad=math.radians(25.0),
    )
    pose = engine._predict(odom1, t0 + 0.1)  # noqa: SLF001
    assert pose.x == pytest.approx(0.0, abs=1e-9)
    assert pose.theta == pytest.approx(math.radians(15.0), abs=1e-6)


def test_odom_yaw_hold_matches_reader():
    from src.odom.source import TypedMovementSensorOdom

    assert (
        BuiltinSlamEngine._ODOM_YAW_HOLD_MAX_S == TypedMovementSensorOdom.MAX_HOLD_GAP_S
    )


def test_predict_rejects_parked_heading_flip_after_long_gap():
    """A magnetometer step of 180° while stopped is not map yaw, at any gap."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 1000.0
    engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0, 0.0, 0.0, pose=conv.Pose2D(1.0, 2.0, 0.2), heading_rad=0.2
        ),
        t0,
    )
    flipped = conv.normalize_angle(0.2 + math.pi)
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            0.0,
            pose=conv.Pose2D(1.0, 2.0, flipped),
            heading_rad=flipped,
        ),
        t0 + 30.0,
    )
    assert pose.theta == pytest.approx(0.0, abs=1e-6)
    # The rejected snap is absorbed into the odom baseline, so the same
    # heading on the next tick does not rotate the map either.
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            0.0,
            pose=conv.Pose2D(1.0, 2.0, flipped),
            heading_rad=flipped,
        ),
        t0 + 30.1,
    )
    assert pose.theta == pytest.approx(0.0, abs=1e-6)


def test_predict_accepts_yaw_the_prior_rate_can_explain():
    """A late sample may carry the spin already underway, and no more than the hold."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "localizing"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    t0 = 50.0
    rate = 1.2
    engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0, 0.0, rate, pose=conv.Pose2D(0.0, 0.0, 0.0), heading_rad=0.0
        ),
        t0,
    )
    turned = 1.0  # rad, within 1.2 rad/s over 1 s, and past the 40° floor
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            rate,
            pose=conv.Pose2D(0.0, 0.0, turned),
            heading_rad=turned,
        ),
        t0 + 1.0,
    )
    assert pose.theta == pytest.approx(turned, abs=1e-6)

    # A slower prior rate cannot explain a large step, even after a long stall.
    # 0.3 rad/s held for the reader's 3 s is 0.9 rad; 1.2 rad is past that.
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    slow = 0.3
    t1 = 80.0
    engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0, 0.0, slow, pose=conv.Pose2D(0.0, 0.0, 0.0), heading_rad=0.0
        ),
        t1,
    )
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            slow,
            pose=conv.Pose2D(0.0, 0.0, 1.2),
            heading_rad=1.2,
        ),
        t1 + 10.0,
    )
    assert pose.theta == pytest.approx(0.0, abs=1e-6)

    # Within the 3 s hold (0.8 < 0.3 * 3), the same long gap is applied.
    engine.set_pose(conv.Pose2D(0.0, 0.0, 0.0))
    engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0, 0.0, slow, pose=conv.Pose2D(0.0, 0.0, 0.0), heading_rad=0.0
        ),
        t1,
    )
    pose = engine._predict(  # noqa: SLF001
        conv.OdomReading(
            0.0,
            0.0,
            slow,
            pose=conv.Pose2D(0.0, 0.0, 0.8),
            heading_rad=0.8,
        ),
        t1 + 10.0,
    )
    assert pose.theta == pytest.approx(0.8, abs=1e-6)


class _FakeSensors:
    def __init__(self, scan=None, odom=None):
        self._scan = scan
        self._odom = odom

    def get_scan(self, max_age_s: float = 2.0):
        del max_age_s
        return self._scan

    def get_odom(self):
        return self._odom


def test_engine_set_pose_and_get_map(tmp_path: Path):
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    store = MapStore(str(tmp_path))
    store.get_or_create_map("default")
    store.set_active_map("default")
    sensors = _FakeSensors()
    engine = BuiltinSlamEngine(cfg, sensors, store, rate_hz=5.0)  # type: ignore[arg-type]
    engine.set_pose(conv.Pose2D(1.0, 2.0, 0.5))
    assert engine.get_pose().x == pytest.approx(1.0)
    assert engine.get_pose().y == pytest.approx(2.0)

    # Seed a wall and export via host.
    with engine._lock:  # noqa: SLF001
        engine._grid = occ.insert_scan(  # noqa: SLF001
            engine._grid,
            0.0,
            0.0,
            0.0,
            np.full(20, 1.5),
            -0.5,
            0.05,
            range_min=0.1,
            range_max=10.0,
        )
        engine._generation += 1
        engine._invalidate_occ_cache()  # noqa: SLF001
    host = BuiltinSlamHost(engine)
    map_data = host.get_map()
    assert map_data is not None
    assert map_data["grid"].shape[0] > 0
    assert host.get_pose_in_map().x == pytest.approx(1.0)

    handle = store.active_handle()
    assert handle is not None
    host.save_map(handle.serialization_stem)
    assert handle.has_occupancy_map()

    diag = host.slam_diagnostics()
    assert diag["slam_backend"] == "builtin"


def test_pose_graph_render_after_world_correction():
    from src.slam_builtin import pose_graph as pg

    graph = pg.PoseGraph(node_spacing_m=0.4)
    scan = conv.LaserScan2D(np.array([2.0]), 0.0, 0.0, 0.1, 10.0)
    graph.add_scan(conv.Pose2D(0.0, 0.0, 0.0), scan)
    grid_ok = pg.render_grid(graph.snapshot(), resolution=0.05)
    row, col = grid_ok.world_to_cell(2.0, 0.0)
    assert occ.to_occupancy_int16(grid_ok)[row, col] == 100

    anchor = graph.earliest_node_near(conv.Pose2D(0.0, 0.0, 0.0))
    assert anchor == 0
    # Drifted leg after the anchor is corrected; anchor keyframe stays fixed.
    graph.add_scan(conv.Pose2D(0.0, 0.5, 0.0), scan)
    assert len(graph) == 2
    graph.apply_world_correction_from(anchor + 1, conv.Pose2D(0.0, -0.5, 0.0))
    grid_fixed = pg.render_grid(graph.snapshot(), resolution=0.05)
    row_f, col_f = grid_fixed.world_to_cell(2.0, 0.0)
    assert occ.to_occupancy_int16(grid_fixed)[row_f, col_f] == 100
    row_g, col_g = grid_fixed.world_to_cell(2.0, 0.5)
    assert occ.to_occupancy_int16(grid_fixed)[row_g, col_g] != 100


def test_pose_graph_world_correction_is_map_frame():
    """A rotated keyframe moves by the same map-frame shift as the others."""
    from src.slam_builtin import pose_graph as pg

    graph = pg.PoseGraph(node_spacing_m=0.4)
    scan = conv.LaserScan2D(np.array([2.0]), 0.0, 0.0, 0.1, 10.0)
    graph.add_scan(conv.Pose2D(0.0, 0.0, 0.0), scan)
    graph.add_scan(conv.Pose2D(1.0, 0.0, math.pi / 2), scan)
    graph.apply_world_correction_from(0, conv.Pose2D(0.0, -0.5, 0.0))
    assert graph.nodes[0].pose.y == pytest.approx(-0.5)
    assert graph.nodes[1].pose.x == pytest.approx(1.0)
    assert graph.nodes[1].pose.y == pytest.approx(-0.5)


def test_pose_graph_optimize_spreads_loop_error():
    """Square loop with a heading drift: the loop edge pulls the end home and
    the error is spread along the chain instead of jumping the last node."""
    from src.slam_builtin import pose_graph as pg

    true = []
    for side in range(4):
        for k in range(5):
            ang = side * math.pi / 2
            base = [(0, 0), (5, 0), (5, 5), (0, 5)][side]
            true.append(
                conv.Pose2D(
                    base[0] + math.cos(ang) * k,
                    base[1] + math.sin(ang) * k,
                    ang,
                )
            )
    true.append(conv.Pose2D(0.0, 0.0, 2 * math.pi))
    # Odometry with a small yaw bias per step.
    bias = math.radians(1.0)
    est = [true[0]]
    edges = []
    for i in range(1, len(true)):
        rel = conv.compose_poses(conv.invert_pose(true[i - 1]), true[i])
        drifted = conv.Pose2D(rel.x, rel.y, rel.theta + bias)
        est.append(conv.compose_poses(est[-1], drifted))
        edges.append(pg.GraphEdge(i - 1, i, drifted, pg.odometry_info(drifted)))
    end_err = math.hypot(est[-1].x, est[-1].y)
    assert end_err > 1.0
    edges.append(
        pg.GraphEdge(
            0,
            len(true) - 1,
            conv.Pose2D(0.0, 0.0, 0.0),
            pg.info_from_sigmas(0.03, math.radians(0.5)),
            loop=True,
        )
    )
    poses = np.array([[p.x, p.y, p.theta] for p in est])
    result = pg.optimize(poses, edges, first_free=1)
    assert result.chi2_after < result.chi2_before
    final = result.poses[-1]
    assert math.hypot(final[0], final[1]) < 0.1
    errs = [
        math.hypot(result.poses[i, 0] - true[i].x, result.poses[i, 1] - true[i].y)
        for i in range(len(true))
    ]
    assert max(errs) < 0.5


def test_apply_map_pose_correction_rebuilds_grid():
    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidar": "front",
            "maps_dir": "/tmp",
            "mode": "mapping",
            "mapping_revisit_min_shift_m": 0.05,
            "mapping_revisit_min_shift_deg": 1.0,
        }
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore("/tmp"), rate_hz=5.0)  # type: ignore[arg-type]
    host = BuiltinSlamHost(engine)
    scan = conv.LaserScan2D(np.array([2.0]), 0.0, 0.0, 0.1, 10.0)

    with engine._lock:  # noqa: SLF001
        engine._grid = occ.insert_scan(  # noqa: SLF001
            engine._grid,
            0.0,
            0.0,
            0.0,
            np.array([2.0]),
            0.0,
            0.0,
            range_min=0.1,
            range_max=10.0,
        )
        engine._graph.add_scan(conv.Pose2D(0.0, 0.0, 0.0), scan)  # noqa: SLF001
        engine._pose = conv.Pose2D(0.0, 0.5, 0.0)

    result = host.apply_map_pose_correction(conv.Pose2D(0.0, 0.0, 0.0))
    assert result["applied"] is True
    # The only node is the newest one: the drift is after it, so the pose
    # moves and the map (one keyframe) is left as drawn.
    assert result["rebuilt"] is False
    assert result["method"] == "pose_only"
    assert engine.get_pose().y == pytest.approx(0.0)
    with engine._lock:  # noqa: SLF001
        int16 = occ.to_occupancy_int16(engine._grid)  # noqa: SLF001
        row, col = engine._grid.world_to_cell(2.0, 0.0)  # noqa: SLF001
    assert int16[row, col] == 100


def test_host_slam_bridge_status_reports_odom_twist():
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": "/tmp", "mode": "mapping"}
    )
    odom = conv.OdomReading(0.2, 0.0, 0.1, pose=conv.Pose2D(0.0, 0.0, 0.0))
    engine = BuiltinSlamEngine(
        cfg,
        _FakeSensors(odom=odom),
        MapStore("/tmp"),
        rate_hz=5.0,
    )  # type: ignore[arg-type]
    host = BuiltinSlamHost(engine)
    engine._predict(odom, 1.0)  # noqa: SLF001
    status = host.slam_bridge_status()
    assert status["odom_velocity"]["vx"] == pytest.approx(0.2)
    assert status["odom_velocity"]["vtheta"] == pytest.approx(0.1)


class _WitLike:
    """heading_sensor stub: absolute AHRS yaw + (possibly empty) gyro."""

    def __init__(self, yaw_deg: float, gz_deg_s: float = 0.0):
        self.yaw_deg = yaw_deg
        self.gz_deg_s = gz_deg_s
        self.orientation_ok = True

    async def get_angular_velocity(self, **_):
        from viam.proto.common import Vector3

        return Vector3(x=0.0, y=0.0, z=self.gz_deg_s)

    async def get_orientation(self, **_):
        from viam.proto.common import Orientation

        if not self.orientation_ok:
            raise NotImplementedError("no orientation")
        return Orientation(o_x=0.0, o_y=0.0, o_z=1.0, theta=self.yaw_deg)

    async def get_readings(self, **_):
        if not self.orientation_ok:
            return {}
        return {"orientation": {"yaw": math.radians(self.yaw_deg)}}


def _sensors_with_heading(wit, **cfg_extra):
    import asyncio

    from src.slam_builtin.io_sensors import BuiltinSensors

    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidar": "f",
            "movement_sensor": "odom",
            "heading_sensor": "wit",
            **cfg_extra,
        }
    )
    return BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=wit,
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )


def test_apply_heading_prefers_absolute_ahrs_yaw_over_gyro():
    import asyncio

    wit = _WitLike(167.69, gz_deg_s=0.0)
    sensors = _sensors_with_heading(wit)
    sample = conv.OdomReading(0.0, 0.1, 0.0)
    out = asyncio.run(sensors._apply_heading(sample))  # noqa: SLF001
    dbg = sensors.heading_debug()
    assert dbg["source"] == "orientation_euler"
    assert dbg["heading_deg"] == pytest.approx(167.69, abs=0.01)
    assert dbg["ahrs_yaw_deg"] == pytest.approx(167.69, abs=0.01)
    assert dbg["gyro_z_deg_s"] == 0.0
    assert out.heading_rad == pytest.approx(math.radians(167.69))
    # 90 deg physical turn moves the prior 90 deg even with a dead gyro.
    wit.yaw_deg = -102.31
    out = asyncio.run(sensors._apply_heading(sample))  # noqa: SLF001
    assert math.degrees(
        conv.normalize_angle(out.heading_rad - math.radians(167.69))
    ) == pytest.approx(90.0, abs=0.01)


def test_apply_heading_yaw_offset_not_compounded():
    import asyncio

    wit = _WitLike(10.0)
    sensors = _sensors_with_heading(wit, heading_sensor_yaw_deg=30.0)
    sample = conv.OdomReading(0.0, 0.0, 0.0)
    for _ in range(5):
        out = asyncio.run(sensors._apply_heading(sample))  # noqa: SLF001
    assert math.degrees(out.heading_rad) == pytest.approx(-20.0, abs=1e-6)


def test_apply_heading_gyro_fallback_only_without_orientation():
    import asyncio

    wit = _WitLike(0.0, gz_deg_s=90.0)
    wit.orientation_ok = False
    sensors = _sensors_with_heading(wit)
    sample = conv.OdomReading(0.0, 0.0, 0.0)
    out = asyncio.run(sensors._apply_heading(sample))  # noqa: SLF001
    assert sensors.heading_debug()["source"] == "gyro_integrated"
    assert out.vtheta == pytest.approx(math.radians(90.0))
    sensors._gyro_heading_t -= 0.2  # noqa: SLF001  pretend 200 ms elapsed
    out = asyncio.run(sensors._apply_heading(sample))  # noqa: SLF001
    assert math.degrees(out.heading_rad) == pytest.approx(18.0, abs=0.5)


def _wall_scan(n: int = 360, dist: float = 3.0) -> conv.LaserScan2D:
    return conv.LaserScan2D(
        ranges=np.full(n, dist),
        angle_min=-math.pi,
        angle_increment=2 * math.pi / n,
        range_min=0.1,
        range_max=10.0,
    )


def _room_scan(
    pose: conv.Pose2D, n: int = 360, half_x: float = 2.0, half_y: float = 1.5
):
    """Base-frame scan from inside an axis-aligned room centred on the origin."""
    angles = -math.pi + np.arange(n) * (2 * math.pi / n)
    ranges = np.empty(n)
    for i, a in enumerate(angles):
        dx, dy = math.cos(pose.theta + a), math.sin(pose.theta + a)
        hits = []
        if abs(dx) > 1e-9:
            hits += [(half_x - pose.x) / dx, (-half_x - pose.x) / dx]
        if abs(dy) > 1e-9:
            hits += [(half_y - pose.y) / dy, (-half_y - pose.y) / dy]
        ranges[i] = min(t for t in hits if t > 0)
    return conv.LaserScan2D(
        ranges=ranges,
        angle_min=-math.pi,
        angle_increment=2 * math.pi / n,
        range_min=0.1,
        range_max=10.0,
    )


def test_engine_pose_at_undoes_odometry_since_then(tmp_path: Path):
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), MapStore(str(tmp_path)))  # type: ignore[arg-type]
    pose = conv.Pose2D(0.0, 0.0, 0.0)
    for k in range(1, 6):
        after = conv.compose_poses(pose, conv.Pose2D(0.05, 0.0, math.radians(2.0)))
        engine._record_odom_step(pose, after, 10.0 + 0.1 * k)  # noqa: SLF001
        pose = after
    engine._pose = pose  # noqa: SLF001
    back = engine.get_pose_at(10.3)
    assert back is not None
    expected = conv.Pose2D(0.0, 0.0, 0.0)
    for _ in range(3):
        expected = conv.compose_poses(
            expected, conv.Pose2D(0.05, 0.0, math.radians(2.0))
        )
    assert back.x == pytest.approx(expected.x, abs=1e-9)
    assert back.y == pytest.approx(expected.y, abs=1e-9)
    assert back.theta == pytest.approx(expected.theta, abs=1e-9)
    # Halfway between samples interpolates the step.
    mid = engine.get_pose_at(10.25)
    assert mid.theta == pytest.approx(math.radians(5.0), abs=1e-6)
    # A correction moves the past with the present: same relative motion.
    engine._pose = conv.Pose2D(5.0, -1.0, math.pi / 2)  # noqa: SLF001
    shifted = engine.get_pose_at(10.3)
    rel_before = conv.compose_poses(conv.invert_pose(back), pose)
    rel_after = conv.compose_poses(conv.invert_pose(shifted), engine.get_pose())
    assert rel_after.x == pytest.approx(rel_before.x, abs=1e-9)
    assert rel_after.y == pytest.approx(rel_before.y, abs=1e-9)
    assert rel_after.theta == pytest.approx(rel_before.theta, abs=1e-9)
    # Outside the history: unknown, not a guess.
    assert engine.get_pose_at(9.0) is None
    assert engine.get_pose_at(12.0).x == pytest.approx(5.0)


@pytest.mark.parametrize("report_capture", [True, False])
def test_engine_matches_a_late_scan_at_the_pose_it_was_taken(
    tmp_path: Path, monkeypatch, report_capture
):
    """The robot drives at 0.5 m/s; each scan reaches SLAM 0.2 s after capture.

    Matching it at the current pose pulled the pose back 10 cm toward where
    the scan was taken, every match. Matched at its capture pose and carried
    forward, the pose stays on the robot.
    """
    import src.slam_builtin.engine as engine_mod

    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "localizing"}
    )
    clock = {"t": 100.0}
    monkeypatch.setattr(engine_mod.time, "monotonic", lambda: clock["t"])
    latency_s, speed = 0.2, 0.5
    truth_at = lambda t: conv.Pose2D(-0.8 + speed * (t - 100.0), 0.1, 0.0)  # noqa: E731

    class _Sensors(_FakeSensors):
        def get_scan(self, max_age_s: float = 2.0, *, fresh: bool = False):
            return _room_scan(truth_at(clock["t"] - latency_s))

        def get_odom(self):
            return conv.OdomReading(0.0, 0.0, 0.0, pose=truth_at(clock["t"]))

    if report_capture:
        _Sensors.scan_captured_at = lambda self: clock["t"] - latency_s

    engine = BuiltinSlamEngine(
        cfg,
        _Sensors(),
        MapStore(str(tmp_path)),
        match_period_s=0.0,  # type: ignore[arg-type]
    )
    grid = occ.empty_grid(resolution=0.05, size_m=6.0)
    room = _room_scan(conv.Pose2D(0.0, 0.0, 0.0))
    for _ in range(4):
        grid = occ.insert_scan(
            grid,
            0.0,
            0.0,
            0.0,
            room.ranges,
            room.angle_min,
            room.angle_increment,
            range_min=0.1,
            range_max=10.0,
            max_beams=360,
        )
    with engine._lock:  # noqa: SLF001
        engine._grid = grid  # noqa: SLF001
        engine._seed_localize_pending = False  # noqa: SLF001
        engine._invalidate_occ_cache()  # noqa: SLF001
    engine.set_pose(truth_at(clock["t"]))
    for _ in range(16):
        clock["t"] += 0.1
        engine._tick()  # noqa: SLF001
    truth = truth_at(clock["t"])
    lag = truth.x - engine.get_pose().x
    if report_capture:
        assert abs(lag) < 0.03
        assert engine.diagnostics()["last_scan_latency_s"] == pytest.approx(latency_s)
    else:
        # Without a capture time the old behaviour remains: the pose trails.
        assert lag > 0.05


def test_engine_does_not_reinsert_same_scan_while_heading_turns(tmp_path: Path):
    """A scan object already inserted must not be painted again at new yaw."""
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    scan = _wall_scan()
    heading = {"th": 0.0}

    class _Sensors(_FakeSensors):
        def get_scan(self, max_age_s: float = 2.0, *, fresh: bool = False):
            assert fresh  # engine must ask for a fresh scan
            return self._scan

        def get_odom(self):
            return conv.OdomReading(
                0.0,
                0.0,
                0.0,
                pose=conv.Pose2D(0.0, 0.0, heading["th"]),
                heading_rad=heading["th"],
            )

        def scan_age_s(self):
            return 0.01

    sensors = _Sensors(scan=scan)
    engine = BuiltinSlamEngine(cfg, sensors, MapStore(str(tmp_path)), rate_hz=10.0)  # type: ignore[arg-type]
    engine._tick()  # noqa: SLF001  prev pose seeds
    engine._tick()  # noqa: SLF001  first insert of this scan
    inserted = engine._updates  # noqa: SLF001
    assert inserted == 1
    # Heading rotates 10 deg per tick; the same scan object must not be re-inserted.
    for i in range(1, 8):
        heading["th"] = math.radians(10.0 * i)
        engine._tick()  # noqa: SLF001
    assert engine._updates == inserted  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(math.radians(70.0), abs=1e-6)
    assert engine.diagnostics()["last_scan_age_s"] == pytest.approx(0.01)
    # A new scan object is inserted once more.
    sensors._scan = _wall_scan()  # noqa: SLF001
    engine._tick()  # noqa: SLF001
    assert engine._updates == inserted + 1  # noqa: SLF001


def test_engine_skips_insert_when_spinning_fast(tmp_path: Path):
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    heading = {"th": 0.0}

    class _Sensors(_FakeSensors):
        def __init__(self):
            super().__init__()
            self.n = 0

        def get_scan(self, max_age_s: float = 2.0, *, fresh: bool = False):
            self.n += 1
            return _wall_scan(dist=3.0 + 0.001 * self.n)  # new object each tick

        def get_odom(self):
            return conv.OdomReading(
                0.0,
                0.0,
                0.0,
                pose=conv.Pose2D(0.0, 0.0, heading["th"]),
                heading_rad=heading["th"],
            )

    sensors = _Sensors()
    engine = BuiltinSlamEngine(cfg, sensors, MapStore(str(tmp_path)), rate_hz=10.0)  # type: ignore[arg-type]
    engine._tick()  # noqa: SLF001
    engine._tick()  # noqa: SLF001
    before = engine._updates  # noqa: SLF001
    # 10 deg per 10 Hz tick = 100 deg/s → insert skipped, pose still tracks.
    for k in range(1, 4):
        engine._last_tick_at -= 0.1  # noqa: SLF001
        heading["th"] = math.radians(10.0 * k)
        engine._tick()  # noqa: SLF001
    assert engine._updates == before  # noqa: SLF001
    assert engine.diagnostics()["insert_skips_turning"] == 3
    assert engine.get_pose().theta == pytest.approx(math.radians(30.0), abs=1e-6)


def test_builtin_sensors_get_scan_fresh_dedupes_same_revolution(monkeypatch):
    import asyncio

    from src.slam_builtin.io_sensors import BuiltinSensors

    cfg = SlamConfig.from_dict({"base": "b", "lidar": "front"})
    sensors = BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=None,
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )
    scans = [_wall_scan(dist=3.0), _wall_scan(dist=3.0), _wall_scan(dist=3.2)]
    calls = {"n": 0}

    def _read(lidar, *, max_age_s):
        del lidar, max_age_s
        s = scans[min(calls["n"], len(scans) - 1)]
        calls["n"] += 1
        return s

    monkeypatch.setattr(sensors, "_read_lidar_scan_sync", _read)
    monkeypatch.setattr(sensors, "_SCAN_MIN_REFETCH_S", 0.0)
    a = sensors.get_scan(0.75, fresh=True)
    b = sensors.get_scan(0.75, fresh=True)  # identical content → same object
    assert a is b
    c = sensors.get_scan(0.75, fresh=True)  # changed content → new object
    assert c is not a
    assert calls["n"] == 3
    # Non-fresh callers keep the cache without refetching.
    assert sensors.get_scan(2.0) is c
    assert calls["n"] == 3
    assert sensors.scan_age_s() < 0.5


def test_builtin_sensors_reports_when_the_scan_was_captured(monkeypatch):
    import asyncio

    from src.slam_builtin.io_sensors import BuiltinSensors

    cfg = SlamConfig.from_dict({"base": "b", "lidar": "front"})
    sensors = BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=None,
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )
    assert math.isnan(sensors.scan_captured_at())
    reads = [
        (_wall_scan(dist=3.0), 5.0),
        (_wall_scan(dist=3.0), 5.3),
        (_wall_scan(dist=3.2), 5.6),
    ]
    calls = {"n": 0}

    def _read(lidar, *, max_age_s):
        del max_age_s
        scan, captured = reads[min(calls["n"], len(reads) - 1)]
        calls["n"] += 1
        sensors._read_captured_at[lidar.name] = captured  # noqa: SLF001
        return scan

    monkeypatch.setattr(sensors, "_read_lidar_scan_sync", _read)
    monkeypatch.setattr(sensors, "_SCAN_MIN_REFETCH_S", 0.0)
    sensors.get_scan(0.75, fresh=True)
    assert sensors.scan_captured_at() == pytest.approx(5.0)
    # Same revolution read again: still the time it was first captured.
    sensors.get_scan(0.75, fresh=True)
    assert sensors.scan_captured_at() == pytest.approx(5.0)
    sensors.get_scan(0.75, fresh=True)
    assert sensors.scan_captured_at() == pytest.approx(5.6)


def test_builtin_sensors_get_scan_accepts_replay_after_dropout(monkeypatch):
    """A camera that returns after a gap often replays its last cloud.

    Identical bytes while the cache is still fresh stay one object (no smear).
    After a real gap they are a new observation so localization can resume.
    """
    import asyncio
    import time

    from src.slam_builtin.io_sensors import BuiltinSensors

    cfg = SlamConfig.from_dict({"base": "b", "lidar": "front"})
    sensors = BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=None,
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )
    wall = _wall_scan(dist=3.0)
    reads = {"n": 0}

    def _read(lidar, *, max_age_s):
        del lidar, max_age_s
        reads["n"] += 1
        if reads["n"] == 3:
            return None
        return wall

    monkeypatch.setattr(sensors, "_read_lidar_scan_sync", _read)
    monkeypatch.setattr(sensors, "_SCAN_MIN_REFETCH_S", 0.0)
    first = sensors.get_scan(0.75, fresh=True)
    assert first is wall
    # Still-fresh identical cloud, no dropout: keep the same object.
    again = sensors.get_scan(0.75, fresh=True)
    assert again is first
    # Dropout long enough that the cached cloud is stale.
    sensors._scan_cache_at = time.monotonic() - 10.0  # noqa: SLF001
    missed = sensors.get_scan(0.75, fresh=True)
    assert missed is None
    recovered = sensors.get_scan(0.75, fresh=True)
    assert recovered is not None
    assert recovered is not first
    assert sensors.scan_age_s() < 0.5
    # A frozen live stream (no gap) still must not be republished once stale.
    sensors._scan_cache_at = time.monotonic() - 10.0  # noqa: SLF001
    sensors._scan_had_gap = False  # noqa: SLF001
    assert sensors.get_scan(0.75, fresh=True) is None


def test_lidar_grpc_returns_a_fast_scan_on_the_same_call():
    import asyncio
    import threading

    from src.slam_builtin.io_sensors import BuiltinSensors

    loop = asyncio.new_event_loop()
    thread = threading.Thread(target=loop.run_forever, daemon=True)
    thread.start()
    try:
        cfg = SlamConfig.from_dict({"base": "b", "lidar": "front"})
        sensors = BuiltinSensors(
            cfg=cfg,
            cameras={"front": object()},
            movement_sensor=None,
            heading_sensor=None,
            shm_lidar=None,
            loop=loop,
            odom_reader=None,
        )
        wall = _wall_scan(dist=2.5)

        async def _grpc(_cam, _lidar):
            return wall

        sensors._read_lidar_scan_grpc = _grpc  # noqa: SLF001
        got = sensors._read_lidar_scan_sync(cfg.lidars[0], max_age_s=1.0)  # noqa: SLF001
        assert got is wall
        assert sensors._lidar_futs == {}  # noqa: SLF001
        assert sensors._lidar_pending == set()  # noqa: SLF001
    finally:
        loop.call_soon_threadsafe(loop.stop)
        thread.join(timeout=2.0)
        loop.close()


def test_lidar_grpc_does_not_pile_up_when_camera_hangs():
    """A GetPointCloud that ignores cancel must not stack one RPC per tick.

    That pile wedged the module loop, so scans never resumed after the
    camera or lidar came back until nav-stack was restarted.
    """
    import asyncio
    import threading
    import time

    from src.slam_builtin.io_sensors import BuiltinSensors

    loop = asyncio.new_event_loop()
    thread = threading.Thread(target=loop.run_forever, daemon=True)
    thread.start()
    release = threading.Event()
    try:
        calls = {"n": 0}

        class _Cam:
            async def get_point_cloud(self, **_kwargs):
                calls["n"] += 1
                await asyncio.get_running_loop().run_in_executor(None, release.wait)
                return (b"",)

        cfg = SlamConfig.from_dict(
            {
                "base": "b",
                "lidars": [{"name": "front", "scan_source": "point_cloud"}],
            }
        )
        sensors = BuiltinSensors(
            cfg=cfg,
            cameras={"front": _Cam()},
            movement_sensor=None,
            heading_sensor=None,
            shm_lidar=None,
            loop=loop,
            odom_reader=None,
        )
        sensors._LIDAR_RPC_WAIT_S = 0.05  # noqa: SLF001
        sensors._LIDAR_RPC_STUCK_S = 0.2  # noqa: SLF001
        lidar = cfg.lidars[0]

        t0 = time.monotonic()
        assert sensors._read_lidar_scan_sync(lidar, max_age_s=1.0) is None  # noqa: SLF001
        assert time.monotonic() - t0 < 0.4
        assert sensors._read_lidar_scan_sync(lidar, max_age_s=1.0) is None  # noqa: SLF001
        assert calls["n"] == 1
        time.sleep(0.25)
        assert sensors._read_lidar_scan_sync(lidar, max_age_s=1.0) is None  # noqa: SLF001
        assert calls["n"] == 2
    finally:
        release.set()
        time.sleep(0.1)
        loop.call_soon_threadsafe(loop.stop)
        thread.join(timeout=2.0)
        loop.close()


def test_builtin_sensors_get_scan_skips_obstacles_only(monkeypatch):
    import asyncio

    from src.slam_builtin.io_sensors import BuiltinSensors

    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidars": [
                {"name": "front"},
                {"name": "depth", "obstacles_only": True},
            ],
        }
    )
    sensors = BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=None,
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )
    seen = []

    def _read(lidar, *, max_age_s):
        del max_age_s
        seen.append(lidar.name)
        return _wall_scan(dist=2.0)

    monkeypatch.setattr(sensors, "_read_lidar_scan_sync", _read)
    monkeypatch.setattr(sensors, "_SCAN_MIN_REFETCH_S", 0.0)
    assert sensors.get_scan(1.0, fresh=True) is not None
    assert seen == ["front"]


def test_apply_heading_from_shm_skips_grpc():
    import asyncio

    from src.shm import imushm
    from src.slam_builtin.io_sensors import BuiltinSensors

    class _HeadingBoom:
        async def get_angular_velocity(self, **_):
            raise AssertionError("heading must come from shm")

        async def get_orientation(self, **_):
            raise AssertionError("heading must come from shm")

        async def get_readings(self, **_):
            raise AssertionError("heading must come from shm")

    class _FakeImuShm:
        def read_latest(self, max_age_s=None):
            del max_age_s
            return imushm.ImuShmSample(
                ax=0,
                ay=0,
                az=9.8,
                gx=0,
                gy=0,
                gz=12.0,
                roll=0,
                pitch=0,
                yaw=math.radians(42.0),
            )

    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidar": "f",
            "heading_sensor": "wit",
            "imu_shm_name": "/viam-imu-wit",
        }
    )
    sensors = BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=_HeadingBoom(),
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )
    sensors._imu_shm = _FakeImuShm()  # noqa: SLF001
    out = sensors._apply_heading_from_shm(conv.OdomReading(0.1, 0.0, 0.0))  # noqa: SLF001
    assert out is not None
    assert math.degrees(out.heading_rad) == pytest.approx(42.0)
    assert out.vtheta == pytest.approx(math.radians(12.0))
    assert sensors.heading_debug()["source"] == "imu_shm"


def test_get_odom_does_not_block_slam_tick_on_busy_loop():
    """Wheel odom is a gRPC round-trip on the module loop. When that loop is
    busy (soft-loc / global_localize) the SLAM tick must return immediately,
    keep the read in flight, and collect it later — not block 1 s and cancel
    (which froze map translation while the robot kept driving)."""
    import asyncio
    import threading
    import time

    from src.slam_builtin.io_sensors import BuiltinSensors

    loop = asyncio.new_event_loop()
    t = threading.Thread(target=loop.run_forever, daemon=True)
    t.start()
    try:
        release = threading.Event()
        calls = {"n": 0}

        class _Reader:
            async def read(self):
                calls["n"] += 1
                # Simulate the loop being owned by something slow.
                await asyncio.get_running_loop().run_in_executor(None, release.wait)
                return conv.OdomReading(0.0, 0.3, 0.0, pose=conv.Pose2D(1.0, 0.0, 0.0))

        cfg = SlamConfig.from_dict(
            {"base": "b", "lidar": "f", "movement_sensor": "odom"}
        )
        sensors = BuiltinSensors(
            cfg=cfg,
            cameras={},
            movement_sensor=object(),
            heading_sensor=None,
            shm_lidar=None,
            loop=loop,
            odom_reader=_Reader(),
        )

        t0 = time.monotonic()
        assert sensors.get_odom() is None  # pending, no IMU fallback configured
        assert time.monotonic() - t0 < 0.5
        assert sensors.get_odom() is None  # still the same in-flight read
        assert calls["n"] == 1
        st = sensors.odom_status()
        assert st["misses"] == 2
        assert st["inflight_s"] >= 0.0
        assert st["source"] == "wheels_pending"

        release.set()
        deadline = time.monotonic() + 2.0
        got = None
        while got is None and time.monotonic() < deadline:
            got = sensors.get_odom()
            time.sleep(0.01)
        assert got is not None
        assert got.pose.x == pytest.approx(1.0)
        st = sensors.odom_status()
        assert st["reads"] == 1
        assert st["source"] == "wheels"
        assert st["age_s"] is not None and st["age_s"] < 1.0
    finally:
        loop.call_soon_threadsafe(loop.stop)
        t.join(timeout=2.0)
        loop.close()


def test_last_pose_roundtrip(tmp_path: Path):
    pose = conv.Pose2D(3.25, -1.5, math.radians(42.0))
    persistence.save_last_pose(tmp_path, pose)
    loaded = persistence.load_last_pose(tmp_path)
    assert loaded is not None
    assert loaded.x == pytest.approx(3.25)
    assert loaded.y == pytest.approx(-1.5)
    assert loaded.theta == pytest.approx(math.radians(42.0))
    stale = persistence.load_last_pose(tmp_path, max_age_s=1e-9)
    assert stale is None


def test_engine_restores_last_pose_on_localizing(tmp_path: Path):
    store = MapStore(str(tmp_path))
    handle = store.get_or_create_map("office")
    store.set_active_map("office")
    grid = occ.empty_grid(resolution=0.05, size_m=8.0)
    grid.log_odds[40, 40] = 2.0
    persistence.save_occupancy(handle.root, grid)
    persistence.save_last_pose(handle.root, conv.Pose2D(1.25, 2.5, math.radians(90.0)))

    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidar": "front",
            "maps_dir": str(tmp_path),
            "mode": "localizing",
            "persist_pose": True,
        }
    )
    engine = BuiltinSlamEngine(cfg, _FakeSensors(), store, rate_hz=5.0)  # type: ignore[arg-type]
    engine.configure_mode("localizing", handle.root)
    pose = engine.get_pose()
    assert pose.x == pytest.approx(1.25)
    assert pose.y == pytest.approx(2.5)
    assert pose.theta == pytest.approx(math.radians(90.0))
    assert engine.pose_restored_from_disk() is True
    assert engine.diagnostics()["seed_localize_pending"] is False

    # set_pose / stop keep the file fresh for the next restart.
    engine.set_pose(conv.Pose2D(4.0, 5.0, 0.1))
    engine.stop()
    again = persistence.load_last_pose(handle.root)
    assert again is not None
    assert again.x == pytest.approx(4.0)
    assert again.y == pytest.approx(5.0)


def test_rewind_spin_poses_keeps_the_turn_and_takes_the_matched_heading():
    from src.slam_builtin.engine import rewind_spin_poses

    odom = [
        conv.Pose2D(0.0, 0.0, 0.0),
        conv.Pose2D(0.0, 0.0, math.pi / 2),
    ]
    # Wheels ended 0.2 rad past the heading that matches the map.
    end = conv.Pose2D(0.0, 0.0, math.pi / 2 - 0.2)
    poses = rewind_spin_poses(odom, end)
    assert poses[1].theta == pytest.approx(end.theta)
    assert poses[0].theta == pytest.approx(-0.2)


def test_mapping_recovers_heading_when_scan_fits_another_yaw(
    tmp_path: Path, monkeypatch
):
    """Wheel yaw slipped, but the scan still matches the map at the true heading."""
    import src.slam_builtin.engine as engine_mod

    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    heading = {"th": 0.0}
    clock = {"t": 100.0}
    monkeypatch.setattr(engine_mod.time, "monotonic", lambda: clock["t"])

    class _Sensors(_FakeSensors):
        def get_scan(self, max_age_s: float = 2.0, *, fresh: bool = False):
            # Always the view from heading 0, even when the wheels say otherwise.
            return _room_scan(conv.Pose2D(0.0, 0.0, 0.0))

        def get_odom(self):
            return conv.OdomReading(
                0.0,
                0.0,
                0.0,
                pose=conv.Pose2D(0.0, 0.0, heading["th"]),
                heading_rad=heading["th"],
            )

    engine = BuiltinSlamEngine(cfg, _Sensors(), MapStore(str(tmp_path)), rate_hz=10.0)  # type: ignore[arg-type]
    engine._tick()  # noqa: SLF001
    assert engine._updates == 1  # noqa: SLF001
    # 30 deg over 10 s is a turn the body can make, and keeps the yaw rate
    # under the in-place spin hold, so this tick is judged against the map.
    clock["t"] += 10.0
    heading["th"] = math.radians(30.0)
    engine._tick()  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(0.0, abs=math.radians(6.0))
    assert engine._updates >= 2  # noqa: SLF001
    assert engine._heading_recovers == 1  # noqa: SLF001
    assert engine._insert_skips_unmatched == 0  # noqa: SLF001


def test_mapping_does_not_paint_a_scan_that_misses_every_heading(
    tmp_path: Path, monkeypatch
):
    """No yaw recovers a scan that does not belong on this map — still refuse."""
    import src.slam_builtin.engine as engine_mod

    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    clock = {"t": 100.0}
    monkeypatch.setattr(engine_mod.time, "monotonic", lambda: clock["t"])
    pose = {"p": conv.Pose2D(0.0, 0.0, 0.0)}
    use_junk = {"v": False}

    class _Sensors(_FakeSensors):
        def get_scan(self, max_age_s: float = 2.0, *, fresh: bool = False):
            if use_junk["v"]:
                # Ranges that never line up with the painted room walls.
                n = 72
                return conv.LaserScan2D(
                    ranges=np.full(n, 0.35, dtype=float),
                    angle_min=-math.pi,
                    angle_increment=2 * math.pi / n,
                    range_min=0.1,
                    range_max=10.0,
                )
            return _room_scan(pose["p"])

        def get_odom(self):
            p = pose["p"]
            return conv.OdomReading(0.0, 0.0, 0.0, pose=p, heading_rad=p.theta)

    engine = BuiltinSlamEngine(cfg, _Sensors(), MapStore(str(tmp_path)), rate_hz=10.0)  # type: ignore[arg-type]
    engine._tick()  # noqa: SLF001
    assert engine._updates == 1  # noqa: SLF001
    clock["t"] += 10.0
    pose["p"] = conv.Pose2D(0.4, 0.0, 0.0)
    use_junk["v"] = True
    engine._tick()  # noqa: SLF001
    assert engine._updates == 1  # noqa: SLF001
    assert engine._insert_skips_unmatched == 1  # noqa: SLF001
    assert engine._heading_recovers == 0  # noqa: SLF001


def test_spin_is_painted_at_the_heading_that_matches(tmp_path: Path):
    cfg = SlamConfig.from_dict(
        {"base": "b", "lidar": "front", "maps_dir": str(tmp_path), "mode": "mapping"}
    )
    heading = {"th": 0.0}
    view = {"th": 0.0}

    class _Sensors(_FakeSensors):
        def get_scan(self, max_age_s: float = 2.0, *, fresh: bool = False):
            return _room_scan(conv.Pose2D(0.0, 0.0, view["th"]))

        def get_odom(self):
            return conv.OdomReading(
                0.0,
                0.0,
                0.0,
                pose=conv.Pose2D(0.0, 0.0, heading["th"]),
                heading_rad=heading["th"],
            )

    engine = BuiltinSlamEngine(cfg, _Sensors(), MapStore(str(tmp_path)), rate_hz=10.0)  # type: ignore[arg-type]
    engine._tick()  # noqa: SLF001
    assert engine._updates == 1  # noqa: SLF001
    # In-place spin. The scan is what the room looks like at the true heading,
    # which stays 0 while the wheels run 30 degrees ahead.
    view["th"] = 0.0
    for k in range(1, 4):
        engine._last_tick_at -= 0.1  # noqa: SLF001
        heading["th"] = math.radians(10.0 * k)
        engine._tick()  # noqa: SLF001
    assert engine._updates == 1  # noqa: SLF001
    assert engine._spin_hold  # noqa: SLF001
    engine._last_tick_at -= 2.0  # noqa: SLF001
    engine._tick()  # noqa: SLF001
    assert engine._updates > 1  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(0.0, abs=math.radians(6.0))
    assert not engine._spin_hold  # noqa: SLF001
    painted = engine._updates  # noqa: SLF001
    engine._last_tick_at -= 0.1  # noqa: SLF001
    engine._tick()  # noqa: SLF001
    assert not engine._spin_hold  # noqa: SLF001
    assert engine.get_pose().theta == pytest.approx(0.0, abs=math.radians(6.0))
    assert engine._updates >= painted  # noqa: SLF001


def _room_occ_map(truth: conv.Pose2D, half_x: float = 3.0, half_y: float = 2.0):
    grid = occ.empty_grid(resolution=0.05, size_m=10.0)
    room = _room_scan(truth, half_x=half_x, half_y=half_y)
    for _ in range(4):
        grid = occ.insert_scan(
            grid,
            truth.x,
            truth.y,
            truth.theta,
            room.ranges,
            room.angle_min,
            room.angle_increment,
            range_min=0.1,
            range_max=10.0,
            max_beams=360,
        )
    return scan_match.occupancy_map_from_int16(
        occ.to_occupancy_int16(grid),
        resolution=grid.resolution,
        origin_x=grid.origin_x,
        origin_y=grid.origin_y,
    )


def test_score_reads_the_same_next_to_unexplored_space():
    """Beams into unknown cells are left out of the fraction, not counted against it."""
    truth = conv.Pose2D(0.0, 0.0, 0.0)
    full = _room_occ_map(truth, half_x=3.0, half_y=2.0)
    scan = _room_scan(truth, half_x=3.0, half_y=2.0)
    g = full.grid.copy()
    xs = full.origin_x + (np.arange(g.shape[1]) + 0.5) * full.resolution
    g[:, xs > 0.5] = -1  # nothing mapped to the right of the robot yet
    half = scan_match.occupancy_map_from_int16(
        g, resolution=full.resolution, origin_x=full.origin_x, origin_y=full.origin_y
    )
    assert scan_match.score_at_pose(full, scan, truth) == pytest.approx(1.0)
    assert scan_match.score_at_pose(half, scan, truth) == pytest.approx(1.0)
    assert scan_match.scan_map_fit(half, scan, truth) == "fit"
    # A heading that turns the mapped walls into free space is still a miss.
    turned = conv.Pose2D(0.0, 0.0, math.radians(30.0))
    assert scan_match.score_at_pose(half, scan, turned) < 0.0
    assert scan_match.scan_map_fit(half, scan, turned) == "miss"


def test_candidate_cannot_win_by_shedding_beams_into_unknown():
    """Sliding toward the frontier hides misses; the coverage guard refuses it."""
    truth = conv.Pose2D(0.0, 0.0, 0.0)
    full = _room_occ_map(truth, half_x=3.0, half_y=2.0)
    g = full.grid.copy()
    xs = full.origin_x + (np.arange(g.shape[1]) + 0.5) * full.resolution
    g[:, xs > 0.5] = -1
    half = scan_match.occupancy_map_from_int16(
        g, resolution=full.resolution, origin_x=full.origin_x, origin_y=full.origin_y
    )
    scan = _room_scan(truth, half_x=3.0, half_y=2.0)
    xy = scan_match.scan_endpoints_base_link(scan)
    lookup = scan_match._inflate_occupied(half.grid >= 50, 2)  # noqa: SLF001
    _s, cov_truth = scan_match._prior_score_and_coverage(  # noqa: SLF001
        half, xy, truth, occupied_lookup=lookup
    )
    _s, cov_shed = scan_match._prior_score_and_coverage(  # noqa: SLF001
        half, xy, conv.Pose2D(0.6, 0.0, 0.0), occupied_lookup=lookup
    )
    assert cov_shed < cov_truth - 0.05
    scores = scan_match._candidate_scores(  # noqa: SLF001
        half,
        xy,
        np.array([0.6]),
        np.array([0.0]),
        0.0,
        occupied_lookup=lookup,
        min_coverage=cov_truth - 0.05,
    )
    assert scores[0] == float("-inf")


def test_refine_pose_finds_a_slip_past_the_fine_window():
    """A skid of 0.5 m and 18° is outside ±0.3 m / ±12°; the wide pass sees it."""
    truth = conv.Pose2D(0.8, 0.4, 0.0)
    occ_map = _room_occ_map(truth)
    scan = _room_scan(truth, half_x=3.0, half_y=2.0)
    prior = conv.Pose2D(truth.x + 0.45, truth.y - 0.30, math.radians(18.0))
    matched, score, prior_score, rival = scan_match.refine_pose(occ_map, scan, prior)
    assert matched is not None
    assert prior_score < 0.35
    assert math.hypot(matched.x - truth.x, matched.y - truth.y) < 0.08
    assert abs(conv.normalize_angle(matched.theta)) < math.radians(3.0)
    assert score >= 0.45
    assert score - rival >= 0.08


def test_refine_pose_keeps_the_tight_window_when_aligned():
    """A fitting prior stays on the fine search (cost and alias guard)."""
    truth = conv.Pose2D(0.8, 0.4, 0.0)
    occ_map = _room_occ_map(truth)
    scan = _room_scan(truth, half_x=3.0, half_y=2.0)
    prior = conv.Pose2D(truth.x + 0.04, truth.y, math.radians(1.0))
    matched, score, prior_score, _rival = scan_match.refine_pose(occ_map, scan, prior)
    assert prior_score >= 0.35
    if matched is not None:
        assert math.hypot(matched.x - truth.x, matched.y - truth.y) < 0.06
        assert score >= prior_score


def test_match_scan_leaves_out_a_depth_camera(monkeypatch):
    """A depth camera feeds mapping, not the scan that moves the pose."""
    import asyncio

    from src.slam_builtin.io_sensors import BuiltinSensors

    cfg = SlamConfig.from_dict(
        {
            "base": "b",
            "lidars": [
                {"name": "front"},
                {"name": "depth", "cloud_frame": "camera_optical"},
            ],
        }
    )
    sensors = BuiltinSensors(
        cfg=cfg,
        cameras={},
        movement_sensor=None,
        heading_sensor=None,
        shm_lidar=None,
        loop=asyncio.new_event_loop(),
        odom_reader=None,
    )

    def _read(lidar, *, max_age_s):
        del max_age_s
        dist = 1.0 if lidar.name == "depth" else 3.0
        return _wall_scan(dist=dist)

    monkeypatch.setattr(sensors, "_read_lidar_scan_sync", _read)
    monkeypatch.setattr(sensors, "_SCAN_MIN_REFETCH_S", 0.0)
    scan = sensors.get_scan(1.0, fresh=True)
    assert scan is not None
    finite = scan.ranges[np.isfinite(scan.ranges)]
    assert finite.min() == pytest.approx(3.0)
    names = [lidar.name for lidar, _ in sensors.mapping_frames()]
    assert names == ["front", "depth"]


def test_camera_hit_survives_a_lidar_beam_at_another_height():
    """A later lidar ray past a camera hit does not erase that hit."""
    from src.slam_builtin.height_bands import compress_bands, paint_bands

    pose = conv.Pose2D(0.0, 0.0, 0.0)
    camera = np.array([[1.0, 0.0, 0.80]])
    lidar_past = np.array([[3.0, 0.0, 0.21]])
    bands = paint_bands(
        {},
        [camera],
        pose,
        resolution=0.05,
        num_bins=360,
        range_min=0.05,
        range_max=30.0,
    )
    bands = paint_bands(
        bands,
        [lidar_past],
        pose,
        resolution=0.05,
        num_bins=360,
        range_min=0.05,
        range_max=30.0,
    )
    fused = compress_bands(bands)

    def odds(x, y):
        row, col = fused.world_to_cell(x, y)
        return float(fused.log_odds[row, col])

    assert odds(1.0, 0.0) >= 0.5
    assert odds(3.0, 0.0) >= 0.5
