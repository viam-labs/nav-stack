"""Resolve mounts and footprint from the Viam robot framesystem.

Viam frames use millimetres and orientation-vector degrees; nav-stack mounts use
metres and yaw/pitch/roll radians. Config JSON still wins when ``mount`` or
footprint fields are set explicitly.
"""

from __future__ import annotations

import asyncio
import logging
import math
from dataclasses import dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

import numpy as np

from .geom.conversions import mm_to_m

LOGGER = logging.getLogger(__name__)

# Parent RobotClient RPCs must stay on the module event loop. Bound the wait so
# a wedged parent cannot stall slam/nav forever after startup.
FRAME_SYSTEM_TIMEOUT_S = 5.0


@dataclass(frozen=True)
class MountPose:
    """Sensor pose in ``base`` / base_link (metres, radians)."""

    x: float
    y: float
    z: float
    theta: float  # yaw
    pitch: float = 0.0
    roll: float = 0.0

    def as_dict(self) -> Dict[str, float]:
        return {
            "x": self.x,
            "y": self.y,
            "z": self.z,
            "theta": self.theta,
            "pitch": self.pitch,
            "roll": self.roll,
        }


def _pose_to_matrix(pose) -> np.ndarray:
    """4×4 SE(3) from a Viam Pose (mm + OV degrees)."""
    from viam.proto.common import Orientation
    from viam.spatialmath import OrientationVector

    ov = OrientationVector.from_proto(
        Orientation(
            o_x=float(pose.o_x),
            o_y=float(pose.o_y),
            o_z=float(pose.o_z),
            theta=float(pose.theta),
        )
    )
    R = np.asarray(ov.to_quaternion().to_rotation_matrix().elements, dtype=float)
    R = R.reshape(3, 3)
    # Use the rotation viam-sdk 0.85 returns. That matrix is the transpose of
    # the 0.79 matrix for the same orientation vector. This robot's map was
    # built with the 0.85 matrix (rplidar mount yaw π, wit heading −180°).
    # Transposing it turns those mounts around and the map pose points backward.
    T = np.eye(4, dtype=float)
    T[:3, :3] = R
    T[0, 3] = float(pose.x)
    T[1, 3] = float(pose.y)
    T[2, 3] = float(pose.z)
    return T


def _matrix_to_mount(T: np.ndarray) -> MountPose:
    """Convert a base←sensor matrix (mm) into a nav-stack mount pose (m/rad).

    Yaw/pitch/roll are solved for nav-stack's ``Rz(yaw) @ Ry(pitch) @ Rx(roll)``
    (see ``geom.conversions._mount_rotation``). Do **not** use Viam EulerAngles
    / OV θ directly: on viam-sdk 0.85 a pure Z rotation of OV θ=-90° extracts
    as mount θ=-π/2, and reading θ itself was a consistent 90° CW localization
    error.
    """
    R = np.asarray(T[:3, :3], dtype=float)
    # R = Rz(yaw) Ry(pitch) Rx(roll): R[2,0] = -sin(pitch).
    pitch = math.atan2(
        -float(R[2, 0]),
        math.sqrt(float(R[2, 1]) ** 2 + float(R[2, 2]) ** 2),
    )
    if abs(math.cos(pitch)) > 1e-6:
        roll = math.atan2(float(R[2, 1]), float(R[2, 2]))
        yaw = math.atan2(float(R[1, 0]), float(R[0, 0]))
    else:
        # Gimbal lock: fold into yaw, zero roll.
        roll = 0.0
        yaw = math.atan2(-float(R[0, 1]), float(R[1, 1]))
    return MountPose(
        x=mm_to_m(float(T[0, 3])),
        y=mm_to_m(float(T[1, 3])),
        z=mm_to_m(float(T[2, 3])),
        theta=float(yaw),
        pitch=float(pitch),
        roll=float(roll),
    )


def _viam_y_forward_base_to_ros(T: np.ndarray) -> np.ndarray:
    """Map a pose expressed in Viam Y-forward ``base`` into ROS X-forward ``base_link``.

    Viam wheeled / Tracer / MiR: +Y forward, +X right, +Z up.
    Nav-stack mounts + SLAM map: +X forward, +Y left, +Z up (ROS).

    ``p_ros = Rz(-π/2) @ p_viam`` so forward (+Y_v) → (+X_r) and right (+X_v) → (−Y_r).
    Odom already applies this via ``base_velocity_convention: viam``; framesystem
    mounts must too or every scan is painted 90° CW relative to drive.
    """
    r_vr = np.array(
        [
            [0.0, 1.0, 0.0, 0.0],
            [-1.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ],
        dtype=float,
    )
    return r_vr @ np.asarray(T, dtype=float)


def _frame_entries(configs: Sequence[Any]) -> Dict[str, Any]:
    """Map frame name → FrameSystemConfig / Transform."""
    out: Dict[str, Any] = {}
    for cfg in configs:
        frame = getattr(cfg, "frame", None) or cfg
        name = str(getattr(frame, "reference_frame", "") or "")
        if name:
            out[name] = frame
    return out


def pose_of_frame_in_destination(
    configs: Sequence[Any],
    frame_name: str,
    destination: str,
    *,
    y_forward_base: bool = False,
) -> Optional[MountPose]:
    """Compose framesystem transforms so ``frame_name`` is expressed in ``destination``.

    Each framesystem entry is the named frame's pose in its parent (observer).

    When ``y_forward_base`` is true (Viam/Tracer/MiR ``base``), the result is
    converted into nav-stack ROS X-forward ``base_link`` axes.
    """
    frames = _frame_entries(configs)
    if frame_name not in frames and frame_name != destination:
        return None
    if frame_name == destination:
        return MountPose(0.0, 0.0, 0.0, 0.0)

    # Build dest_T_frame by walking frame → … → destination.
    T = np.eye(4, dtype=float)
    cur = frame_name
    seen = set()
    while cur != destination:
        if cur in seen:
            LOGGER.warning(
                "framesystem cycle while resolving %s → %s", frame_name, destination
            )
            return None
        seen.add(cur)
        entry = frames.get(cur)
        if entry is None:
            LOGGER.warning(
                "framesystem missing frame %r while resolving %s → %s",
                cur,
                frame_name,
                destination,
            )
            return None
        pif = entry.pose_in_observer_frame
        parent = str(getattr(pif, "reference_frame", "") or "")
        if not parent:
            LOGGER.warning("framesystem frame %r has empty parent", cur)
            return None
        # entry pose is cur in parent → parent_T_cur
        parent_T_cur = _pose_to_matrix(pif.pose)
        # We have …_T_cur accumulating as we walk up: want dest_T_cur.
        # After step: parent_T_cur_full = parent_T_cur @ (old cur_T_leaf)
        T = parent_T_cur @ T
        cur = parent
        if len(seen) > 64:
            LOGGER.warning(
                "framesystem chain too deep for %s → %s", frame_name, destination
            )
            return None
    if y_forward_base:
        T = _viam_y_forward_base_to_ros(T)
    return _matrix_to_mount(T)


def base_box_forward_lateral(
    configs: Sequence[Any],
    base_name: str,
) -> Optional[Tuple[float, float]]:
    """``(length_m, width_m)`` of the base box in nav-stack axes.

    Viam base: +Y forward, +X right, so box Y is length and box X is width.
    A longer-side heuristic swaps those on a robot that is wider than it is
    long, and would then crop real returns just in front of the bumper.
    """
    frames = _frame_entries(configs)
    entry = frames.get(base_name)
    if entry is None:
        return None
    geom = getattr(entry, "physical_object", None)
    if geom is None or not geom.ByteSize():
        return None
    if geom.WhichOneof("geometry_type") != "box":
        return None
    dims = geom.box.dims_mm
    lateral = abs(mm_to_m(float(dims.x)))
    forward = abs(mm_to_m(float(dims.y)))
    if lateral < 1e-3 or forward < 1e-3:
        return None
    return forward, lateral


async def fetch_frame_system_config(
    robot, *, timeout_s: float = FRAME_SYSTEM_TIMEOUT_S
) -> List[Any]:
    """``robot.get_frame_system_config()`` on the caller's event loop.

    Must not be driven from a worker thread via ``asyncio.run`` — the module
    parent ``RobotClient`` is bound to the module loop and that pattern can
    deadlock reconfigure (seen after v1.0.40).
    """
    return list(
        await asyncio.wait_for(robot.get_frame_system_config(), timeout=timeout_s)
    )


def resolve_base_footprint(cfg, configs: Sequence[Any], raw: Mapping):
    """``resolve_footprint`` with the Viam base box filling unset sides."""
    from .config import resolve_footprint

    base_name = str(getattr(cfg, "base", "") or "base")
    return resolve_footprint(raw, base_box_forward_lateral(configs, base_name))


def _describe_footprint(fp) -> str:
    if fp.is_box:
        return f"from {fp.source}: L={fp.length_m:.3f} W={fp.width_m:.3f}"
    if fp.radius_m is not None:
        return f"from robot_radius: r={fp.radius_m:.3f}"
    return "unknown (no base box, footprint_* or robot_radius)"


def apply_framesystem_footprint_to_slam_cfg(
    cfg,
    configs: Sequence[Any],
    *,
    raw_attrs: Optional[Mapping] = None,
    logger: Optional[logging.Logger] = None,
) -> List[str]:
    """Footprint crop only (no mounts), for lidars that take mounts from config."""
    log = logger or LOGGER
    notes: List[str] = []
    _apply_footprint_crop(cfg, configs, raw_attrs or {}, notes)
    for line in notes:
        log.info("framesystem: %s", line)
    return notes


def _apply_footprint_crop(
    cfg, configs: Sequence[Any], raw: Mapping, notes: List[str]
) -> None:
    """Stamp the resolved body onto each lidar so self-returns can be dropped."""
    from .config import stamp_lidar_footprint

    if not bool(getattr(cfg, "crop_inside_footprint", True)):
        notes.append("footprint crop: off")
        return
    fp = resolve_base_footprint(cfg, configs, raw)
    cfg.footprint_length_m = fp.length_m
    cfg.footprint_width_m = fp.width_m
    cfg.robot_radius = fp.radius_m
    stamp_lidar_footprint(cfg.lidars, fp)
    notes.append(f"footprint crop {_describe_footprint(fp)}")


def apply_framesystem_to_slam_cfg(
    cfg,
    configs: Sequence[Any],
    *,
    raw_attrs: Optional[Mapping] = None,
    logger: Optional[logging.Logger] = None,
    y_forward_base: Optional[bool] = None,
):
    """Fill lidar mounts from framesystem when JSON omitted ``mount``.

    Mutates existing ``LidarConfig`` objects in place so live sensor facades
    that hold the same instances pick up mounts without a rebuild.

    ``y_forward_base`` converts Viam Y-forward ``base`` poses into ROS X-forward
    mounts (default True — all Viam bases are Y-forward).

    Returns ``(cfg, notes)`` where notes are human-readable resolution lines.
    """
    log = logger or LOGGER
    raw = raw_attrs or {}
    raw_lidars = list(raw.get("lidars") or [])
    raw_by_name = {}
    for entry in raw_lidars:
        if isinstance(entry, Mapping) and entry.get("name"):
            raw_by_name[str(entry["name"])] = entry

    if y_forward_base is None:
        # All Viam bases are Y-forward in the framesystem; nav-stack mounts are
        # ROS X-forward. Always convert unless a caller opts out (tests).
        y_forward_base = True

    base_name = str(getattr(cfg, "base", "") or "base")
    notes: List[str] = []
    if y_forward_base:
        notes.append("base axes: Viam Y-forward → nav-stack X-forward")
    for lidar in cfg.lidars:
        raw_l = raw_by_name.get(lidar.name, {})
        explicit_mount = isinstance(raw_l, Mapping) and (
            "mount" in raw_l
            or any(k in raw_l for k in ("x", "y", "z", "theta", "pitch", "roll"))
        )
        if explicit_mount or bool(lidar.points_in_base_link):
            if explicit_mount:
                notes.append(f"lidar {lidar.name}: mount from config (override)")
            else:
                notes.append(f"lidar {lidar.name}: points_in_base_link — skip mount")
            continue
        mount = pose_of_frame_in_destination(
            configs, lidar.name, base_name, y_forward_base=bool(y_forward_base)
        )
        if mount is None:
            notes.append(
                f"lidar {lidar.name}: no framesystem frame named {lidar.name!r} "
                f"relative to {base_name!r}; keeping defaults "
                f"({lidar.x:.3f},{lidar.y:.3f},{lidar.z:.3f}) θ={lidar.theta:.3f}"
            )
            continue
        from .config import CLOUD_FRAME_CAMERA_OPTICAL

        # Framesystem pose is the component frame → base. RealSense
        # GetPointCloud is still camera-optical (Z forward). The FS camera
        # orientation is typically an optical/camera_link OV (±90° roll, and
        # after Y-forward→ROS convert often ±90° yaw) — not the lens aim in
        # the map. Using that RPY (with or without optical remap) paints the
        # cloud to the robot's side/rear so ahead-right obstacles never enter
        # the reactive corridor (live: center ray → −Y, grazes with
        # forward_clearance still "clear").
        # Keep ``camera_optical``; take translation from FS; ignore FS RPY
        # (identity aim = forward-facing after optical→sensor). Side/rear
        # mounts and mast tilt must set ``mount`` explicitly in JSON.
        optical = lidar.cloud_frame == CLOUD_FRAME_CAMERA_OPTICAL
        lidar.x = mount.x
        lidar.y = mount.y
        lidar.z = mount.z
        if optical:
            lidar.theta = 0.0
            lidar.pitch = 0.0
            lidar.roll = 0.0
            optical_note = (
                "; kept camera_optical (FS orientation ignored — PCD is optical; "
                "aim via JSON mount)"
            )
        else:
            lidar.theta = mount.theta
            lidar.pitch = mount.pitch
            lidar.roll = mount.roll
            optical_note = ""
        notes.append(
            f"lidar {lidar.name}: mount from framesystem "
            f"({lidar.x:.3f},{lidar.y:.3f},{lidar.z:.3f}) "
            f"θ={lidar.theta:.3f} pitch={lidar.pitch:.3f} roll={lidar.roll:.3f}"
            f"{optical_note}"
        )
    _apply_movement_sensor_yaw(
        cfg, configs, raw, notes, y_forward_base=bool(y_forward_base)
    )
    _apply_footprint_crop(cfg, configs, raw, notes)
    for line in notes:
        log.info("framesystem: %s", line)
    return cfg, notes


def _apply_movement_sensor_yaw(
    cfg,
    configs: Sequence[Any],
    raw: Mapping,
    notes: List[str],
    *,
    y_forward_base: bool,
) -> None:
    """Set IMU yaw from the framesystem when JSON omitted ``movement_sensor_yaw_deg``.

    Same Viam Y-forward → nav-stack X-forward conversion as a lidar mount.
    A sensor yawed +90° on a Viam base has its +X pointing forward, so the
    nav-stack yaw is 0 — the 90° is the axis change, not an extra twist.
    Gyro Z is unchanged by that yaw. Linear acceleration X/Y are rotated
    into base_link by the existing ``movement_sensor_yaw_deg`` path.
    """
    _apply_one_sensor_yaw(
        cfg,
        configs,
        raw,
        notes,
        name_attr="movement_sensor",
        yaw_attr="movement_sensor_yaw_deg",
        y_forward_base=y_forward_base,
    )
    _apply_one_sensor_yaw(
        cfg,
        configs,
        raw,
        notes,
        name_attr="heading_sensor",
        yaw_attr="heading_sensor_yaw_deg",
        y_forward_base=y_forward_base,
    )


def _apply_one_sensor_yaw(
    cfg,
    configs: Sequence[Any],
    raw: Mapping,
    notes: List[str],
    *,
    name_attr: str,
    yaw_attr: str,
    y_forward_base: bool,
) -> None:
    name = str(getattr(cfg, name_attr, "") or "")
    if not name:
        return
    label = "movement sensor" if name_attr == "movement_sensor" else "heading sensor"
    current = float(getattr(cfg, yaw_attr, 0.0) or 0.0)
    if yaw_attr in raw:
        notes.append(f"{label} {name}: yaw {current:.1f}° from config (override)")
        return
    base_name = str(getattr(cfg, "base", "") or "base")
    mount = pose_of_frame_in_destination(
        configs, name, base_name, y_forward_base=y_forward_base
    )
    if mount is None:
        notes.append(
            f"{label} {name}: no framesystem frame named {name!r} "
            f"relative to {base_name!r}; yaw stays {current:.1f}°"
        )
        return
    yaw_deg = math.degrees(mount.theta)
    if abs(yaw_deg) < 1e-4:
        yaw_deg = 0.0
    setattr(cfg, yaw_attr, yaw_deg)
    tilt = ""
    if abs(mount.pitch) > math.radians(5.0) or abs(mount.roll) > math.radians(5.0):
        tilt = (
            f"; pitch={math.degrees(mount.pitch):.1f}° "
            f"roll={math.degrees(mount.roll):.1f}° not applied"
        )
    notes.append(
        f"{label} {name}: yaw from framesystem {yaw_deg:.1f}° "
        f"(sensor +X in base_link){tilt}"
    )


def apply_framesystem_to_nav_cfg(
    cfg,
    configs: Sequence[Any],
    *,
    raw_attrs: Optional[Mapping] = None,
    logger: Optional[logging.Logger] = None,
):
    """Resolve the nav footprint: config per side, else base box, else ``robot_radius``."""
    from dataclasses import replace

    from .config import NavConfig, footprint_robot_radius

    log = logger or LOGGER
    raw = raw_attrs or {}
    fp = resolve_base_footprint(cfg, configs, raw)
    default_radius = NavConfig.__dataclass_fields__["robot_radius"].default
    cfg = replace(
        cfg,
        footprint_length_m=fp.length_m,
        footprint_width_m=fp.width_m,
        robot_radius=footprint_robot_radius(fp, default_radius),
    )
    notes = [f"footprint {_describe_footprint(fp)} robot_radius={cfg.robot_radius:.3f}"]
    log.info("framesystem: %s", notes[-1])
    return cfg, notes
