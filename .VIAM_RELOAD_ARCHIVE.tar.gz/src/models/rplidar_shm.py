"""In-process RPLIDAR camera that publishes PCD to POSIX shm.

``viam-labs:nav-stack:rplidar`` talks the Slamtec UART protocol directly (no
``viam:lidar:rplidar`` gRPC hop) and writes each revolution into the same shm
layout as ``viam-shared-memory-test``.
"""

from __future__ import annotations

import asyncio
import re
import threading
import time
from typing import ClassVar, Mapping, Optional, Sequence

import numpy as np
from typing_extensions import Self
from viam.components.camera import Camera
from viam.logging import getLogger
from viam.proto.app.robot import ComponentConfig
from viam.proto.common import ResourceName
from viam.resource.base import ResourceBase
from viam.resource.registry import Registry, ResourceCreatorRegistration
from viam.resource.types import Model, ModelFamily
from viam.utils import struct_to_dict

from ..geom import conversions as conv
from ..lidar.rplidar_protocol import RPLidarError, model_name, scan_to_xyz_m
from ..lidar.rplidar_serial import RPLidarSerial
from ..lidar.serial_ports import list_candidate_serial_ports, normalize_exclude_list
from ..shm import pcshm

LOGGER = getLogger(__name__)


def _shm_name_for(component_name: str, explicit: Optional[str]) -> str:
    if explicit:
        return pcshm.normalize_name(explicit)
    slug = re.sub(r"[^A-Za-z0-9_-]+", "", component_name) or "lidar"
    return pcshm.normalize_name(f"viam-pc-{slug}")


class RPLidarShm(Camera):
    MODEL: ClassVar[Model] = Model(ModelFamily("viam-labs", "nav-stack"), "rplidar")

    def __init__(self, name: str):
        super().__init__(name)
        self._device: Optional[RPLidarSerial] = None
        self._shm: Optional[pcshm.Writer] = None
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._lock = threading.Lock()
        self._device_lock = threading.Lock()
        self._stall_abort = threading.Event()
        self._scan_loop_progress_wall: Optional[float] = None
        self._kick_count = 0
        self._last_baudrate: Optional[int] = None
        self._latest = b""
        self._scans = 0
        self._errors = 0
        self._reconnects = 0
        self._last_error: Optional[str] = None
        self._last_points = 0
        self._last_publish_wall: Optional[float] = None
        self._shm_name: Optional[str] = None
        self._serial_path: Optional[str] = None
        self._min_range_mm = 0.0
        self._warmup_scans = 5
        self._info: dict = {}
        self._serial_autodetect = False
        self._baudrate: Optional[int] = None
        self._timeout_s = 2.0
        self._motor_warmup_s = 1.0
        self._reset_settle_s = 0.5
        self._reconnect_backoff_s = 1.0
        self._max_reconnect_backoff_s = 15.0
        self._max_publish_gap_s = 5.0
        self._stall_thread: Optional[threading.Thread] = None
        self._stall_poll_s = 1.0
        self._serial_exclude: list[str] = []
        self._serial_chip: Optional[str] = None
        self._include_tty_acm = False

    def _join_timeout_s(self) -> float:
        """Long enough for scan loop to exit reconnect backoff and UART reads."""
        return (
            self._max_reconnect_backoff_s + self._timeout_s + self._motor_warmup_s + 5.0
        )

    def _mark_scan_progress(self) -> None:
        self._scan_loop_progress_wall = time.monotonic()

    def _wait_backoff(self, backoff: float) -> bool:
        """Wait up to ``backoff`` seconds; return True when ``_stop`` is set.

        The wait itself is progress. Leaving the progress stamp frozen makes
        the stall watchdog treat a deliberate reconnect delay as a hung read.
        """
        deadline = time.monotonic() + max(0.0, backoff)
        while True:
            if self._stop.is_set():
                return True
            self._mark_scan_progress()
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            if self._stop.wait(min(1.0, remaining)):
                return True

    @classmethod
    def new(
        cls, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]
    ) -> Self:
        cam = cls(config.name)
        cam.reconfigure(config, dependencies)
        return cam

    @classmethod
    def validate_config(
        cls, config: ComponentConfig
    ) -> tuple[Sequence[str], Sequence[str]]:
        attrs = struct_to_dict(config.attributes)
        serial_path = str(attrs.get("serial_path") or "").strip()
        autodetect = bool(attrs.get("serial_autodetect", False))
        if not serial_path and not autodetect:
            raise ValueError(
                "rplidar requires attributes.serial_path or serial_autodetect=true"
            )
        chip = str(attrs.get("serial_chip") or "").strip().lower() or None
        if chip not in (None, "cp210", "ch340"):
            raise ValueError("rplidar serial_chip must be cp210, ch340, or omitted")
        return [], []

    def reconfigure(
        self, config: ComponentConfig, dependencies: Mapping[ResourceName, ResourceBase]
    ) -> None:
        _ = dependencies
        self.close_sync()
        attrs = struct_to_dict(config.attributes)
        serial_path = str(attrs.get("serial_path") or "").strip()
        self._serial_autodetect = bool(attrs.get("serial_autodetect", False))
        baud = attrs.get("baud_rate") or attrs.get("baudrate")
        self._baudrate = int(baud) if baud else None
        self._timeout_s = float(attrs.get("timeout_s", 2.0))
        self._min_range_mm = float(attrs.get("min_range_mm", 0.0))
        self._warmup_scans = int(attrs.get("warmup_scans", 5))
        region = int(attrs.get("shm_region_size", pcshm.DEFAULT_REGION_SIZE))
        explicit = str(attrs.get("shm_name") or "").strip() or None
        self._shm_name = _shm_name_for(self.name, explicit)
        self._motor_warmup_s = float(attrs.get("motor_warmup_s", 1.0))
        self._reset_settle_s = float(attrs.get("reset_settle_s", 0.5))
        self._reconnect_backoff_s = float(attrs.get("reconnect_backoff_s", 1.0))
        self._max_reconnect_backoff_s = float(
            attrs.get("max_reconnect_backoff_s", 15.0)
        )
        self._max_publish_gap_s = float(attrs.get("max_publish_gap_s", 5.0))
        self._serial_path = serial_path or None
        self._serial_exclude = normalize_exclude_list(attrs.get("serial_exclude"))
        chip = str(attrs.get("serial_chip") or "").strip().lower() or None
        if chip not in (None, "cp210", "ch340"):
            raise ValueError("rplidar serial_chip must be cp210, ch340, or omitted")
        self._serial_chip = chip
        self._include_tty_acm = bool(attrs.get("include_tty_acm", False))
        self._stall_abort.clear()
        self._scan_loop_progress_wall = None
        self._kick_count = 0
        self._last_baudrate = None
        self._scans = 0
        self._errors = 0
        self._reconnects = 0
        self._last_error = None
        if self._thread is not None and self._thread.is_alive():
            raise RuntimeError(
                f"rplidar {self.name!r} scan thread still running after close_sync"
            )
        self._stop.clear()
        self._open_device()
        self._shm = pcshm.open_writer(self._shm_name, region)
        self._thread = threading.Thread(
            target=self._scan_loop, name=f"{self.name}-rplidar", daemon=True
        )
        self._thread.start()
        if self._max_publish_gap_s > 0:
            self._stall_thread = threading.Thread(
                target=self._stall_watchdog,
                name=f"{self.name}-rplidar-stall",
                daemon=True,
            )
            self._stall_thread.start()
        model_byte = self._info.get("model")
        LOGGER.info(
            "nav-stack rplidar %r serial=%s baud=%s model=%s (%s) shm=%s",
            self.name,
            self._serial_path,
            self._device.baudrate if self._device else None,
            model_byte,
            model_name(int(model_byte or 0)),
            self._shm_name,
        )

    def _kick_scan_loop(self, reason: str) -> None:
        """Force the lone scan thread to drop UART and reconnect in-process."""
        if self._stop.is_set():
            return
        self._kick_count += 1
        self._last_error = reason
        LOGGER.warning("rplidar %r kick #%d: %s", self.name, self._kick_count, reason)
        self._stall_abort.set()
        device = self._device
        if device is not None and getattr(device, "_hub_soft", False) is True:
            try:
                device.soft_restart()
            except Exception:
                pass
            return
        self._close_device()

    def _open_device(self) -> None:
        with self._device_lock:
            self._open_device_unlocked()

    def _open_device_unlocked(self) -> None:
        if self._serial_path:
            dev = RPLidarSerial(
                self._serial_path,
                baudrate=self._baudrate,
                timeout_s=self._timeout_s,
                motor_warmup_s=self._motor_warmup_s,
                reset_settle_s=self._reset_settle_s,
            )
            dev.open()
        elif self._serial_autodetect:
            # CP210 first (typical RPLIDAR); never probe USB-CAN / ttyACM.
            ports = list_candidate_serial_ports(
                prefer_cp210=True,
                chip=self._serial_chip or "cp210",
                include_tty_acm=self._include_tty_acm,
                exclude=self._serial_exclude,
            )
            dev = RPLidarSerial.open_first_working(
                ports,
                baudrate=self._baudrate,
                timeout_s=self._timeout_s,
                motor_warmup_s=self._motor_warmup_s,
                reset_settle_s=self._reset_settle_s,
                prefer_cp210=True,
                chip=self._serial_chip or "cp210",
                include_tty_acm=self._include_tty_acm,
                exclude=self._serial_exclude,
            )
            self._serial_path = dev.port
            LOGGER.info("nav-stack rplidar autodetected serial=%s", self._serial_path)
        else:
            raise ValueError("rplidar requires serial_path or serial_autodetect")
        self._device = dev
        self._info = dict(dev.info)
        self._last_baudrate = int(dev.baudrate) if dev.baudrate else self._last_baudrate

    def _close_device(self) -> None:
        with self._device_lock:
            device = self._device
            if device is None:
                return
            try:
                device.stop()
            except Exception:
                pass
            try:
                device.close()
            except Exception:
                pass
            self._device = None

    def _publish_scan(self, measurements) -> None:
        xyz = scan_to_xyz_m(measurements, min_range_mm=self._min_range_mm)
        pcd = conv.points_to_pcd(
            np.asarray(xyz, dtype=float) if xyz else np.empty((0, 3))
        )
        if self._shm is not None:
            self._shm.write(pcd)
        with self._lock:
            self._latest = pcd
        self._scans += 1
        self._last_points = len(xyz)
        self._last_error = None
        self._last_publish_wall = time.monotonic()

    def _scan_loop(self) -> None:
        backoff = self._reconnect_backoff_s
        try:
            while not self._stop.is_set():
                self._mark_scan_progress()
                device = self._device
                if device is None:
                    self._stall_abort.clear()
                    if not self._try_reconnect(backoff):
                        if self._wait_backoff(backoff):
                            return
                        backoff = min(backoff * 2.0, self._max_reconnect_backoff_s)
                        continue
                    backoff = self._reconnect_backoff_s
                    device = self._device
                discarded = 0
                # This attempt's clock starts here, after reconnect. The last
                # publish may already be minutes old; that is why we are here.
                self._mark_scan_progress()
                self._stall_abort.clear()
                try:
                    for measurements in device.iter_scans(
                        max_stall_s=self._max_publish_gap_s,
                        abort_check=self._stall_abort.is_set,
                    ):
                        self._mark_scan_progress()
                        if self._stop.is_set():
                            return
                        if discarded < self._warmup_scans:
                            discarded += 1
                            continue
                        try:
                            self._publish_scan(measurements)
                        except Exception as exc:  # noqa: BLE001
                            self._errors += 1
                            self._last_error = repr(exc)
                            LOGGER.warning(
                                "rplidar %r publish failed: %s", self.name, exc
                            )
                except Exception as exc:  # noqa: BLE001
                    self._errors += 1
                    self._last_error = repr(exc)
                    if self._stop.is_set():
                        return
                    LOGGER.error("rplidar %r scan loop exited: %s", self.name, exc)
                    # Closing USB on a hub shared with CAN resets can0. Prefer a
                    # protocol-only restart when hub-soft mode is active.
                    if (
                        device is not None
                        and getattr(device, "_hub_soft", False) is True
                    ):
                        try:
                            device.soft_restart()
                        except Exception:
                            pass
                    else:
                        self._close_device()
                    self._stall_abort.clear()
                    if self._wait_backoff(backoff):
                        return
                    backoff = min(backoff * 2.0, self._max_reconnect_backoff_s)
        finally:
            self._close_device()
            if not self._stop.is_set():
                LOGGER.error("rplidar %r scan loop stopped unexpectedly", self.name)

    def _try_reconnect(self, backoff_s: float) -> bool:
        if self._stop.is_set():
            return False
        self._mark_scan_progress()
        try:
            self._open_device()
        except Exception as exc:  # noqa: BLE001
            self._errors += 1
            self._last_error = repr(exc)
            LOGGER.warning(
                "rplidar %r reconnect failed (backoff %.1fs): %s",
                self.name,
                backoff_s,
                exc,
            )
            return False
        self._reconnects += 1
        self._last_error = None
        LOGGER.info(
            "rplidar %r reconnected on %s (attempt #%d)",
            self.name,
            self._serial_path,
            self._reconnects,
        )
        return True

    def _stall_watchdog(self) -> None:
        """Abort a read that has stopped making progress.

        Never spawn a second scan thread. A reconnect is progress: the last
        publish stays old until the new revolution is written, and aborting
        on that timestamp cancels every retry.
        """
        while not self._stop.is_set():
            self._stall_watchdog_tick()
            if self._stop.wait(self._stall_poll_s):
                return

    def _stall_watchdog_tick(self) -> None:
        gap = self._max_publish_gap_s
        if gap <= 0:
            return
        last = self._last_publish_wall
        if last is None:
            return
        now = time.monotonic()
        age = now - last
        if age <= gap:
            return
        progress = self._scan_loop_progress_wall
        progress_age = (now - progress) if progress is not None else age
        if progress_age < gap:
            return
        kick_after = max(gap * 2.0, 10.0)
        if age >= kick_after:
            self._kick_scan_loop(f"publish stalled {age:.1f}s")
            return
        if self._stall_abort.is_set():
            return
        LOGGER.warning(
            "rplidar %r publish stalled %.1fs (> %.1fs); aborting scan loop",
            self.name,
            age,
            gap,
        )
        self._last_error = f"publish stalled {age:.1f}s"
        self._stall_abort.set()

    async def get_images(self, *, extra=None, timeout=None, **kwargs):
        raise NotImplementedError(
            "rplidar does not support get_images; use get_point_cloud"
        )

    async def get_point_cloud(
        self, *, extra=None, timeout: Optional[float] = None, **kwargs
    ) -> tuple[bytes, str]:
        deadline = time.monotonic() + (float(timeout) if timeout else 2.0)
        while time.monotonic() < deadline:
            with self._lock:
                pcd = self._latest
            if pcd:
                return pcd, "pointcloud/pcd"
            await asyncio.sleep(0.05)
        raise RPLidarError("rplidar has no scan yet")

    async def get_properties(self, *, timeout=None, **kwargs) -> Camera.Properties:
        return Camera.Properties(supports_pcd=True, mime_types=["pointcloud/pcd"])

    async def do_command(
        self,
        command: Mapping[str, object],
        *,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> Mapping[str, object]:
        cmd = command.get("command") if isinstance(command, Mapping) else None
        if cmd == "get_laser_scan":
            raise NotImplementedError("rplidar get_laser_scan is not implemented")
        if cmd == "restart":
            self._kick_scan_loop("do_command restart")
            return {"status": "restarting", "kick_count": self._kick_count}
        last_pub_age_s = None
        if self._last_publish_wall is not None:
            last_pub_age_s = round(time.monotonic() - self._last_publish_wall, 3)
        progress_age_s = None
        if self._scan_loop_progress_wall is not None:
            progress_age_s = round(time.monotonic() - self._scan_loop_progress_wall, 3)
        thread = self._thread
        baud = self._device.baudrate if self._device else self._last_baudrate
        return {
            "serial_path": self._serial_path,
            "baudrate": baud,
            "shm_name": self._shm_name,
            "info": dict(self._info),
            "scans": self._scans,
            "errors": self._errors,
            "reconnects": self._reconnects,
            "kick_count": self._kick_count,
            "scan_thread_alive": thread is not None and thread.is_alive(),
            "scan_loop_progress_age_s": progress_age_s,
            "stall_abort_set": self._stall_abort.is_set(),
            "last_points": self._last_points,
            "last_error": self._last_error,
            "last_publish_age_s": last_pub_age_s,
            "latest_bytes": len(self._latest),
        }

    def close_sync(self) -> None:
        self._stop.set()
        self._stall_abort.set()
        self._close_device()
        join_timeout = self._join_timeout_s()
        scan_thread = self._thread
        stall_thread = self._stall_thread
        for thread in (scan_thread, stall_thread):
            if thread is not None and thread.is_alive():
                thread.join(timeout=join_timeout)
        alive = [
            t.name
            for t in (scan_thread, stall_thread)
            if t is not None and t.is_alive()
        ]
        if alive:
            LOGGER.error(
                "rplidar %r background threads still running after close: %s",
                self.name,
                ", ".join(alive),
            )
            return
        self._thread = None
        self._stall_thread = None
        if self._shm is not None:
            self._shm.close()
            self._shm = None

    async def close(self):
        self.close_sync()


Registry.register_resource_creator(
    Camera.API,
    RPLidarShm.MODEL,
    ResourceCreatorRegistration(RPLidarShm.new, RPLidarShm.validate_config),
)
