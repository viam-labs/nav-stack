"""Shared navigation-service core for the nav-stack models.

Both navigation models — ``viam-labs:nav-stack:navigation`` (borrows the SLAM
model's in-process runtime) and ``viam-labs:nav-stack:navigation-external``
(builds its own runtime around an arbitrary ``rdk:service:slam``) — implement
the Navigation service (locations, routes, zones, navigate / plan / go).
``DoCommand`` remains for diagnostics and for callers that have not moved
over. That logic lives here in ``NavServiceBase``; the concrete models differ
only in how they obtain a ``SlamRuntime`` (``_resolve_runtime``) and how they
stand it up (``reconfigure``).
"""

from __future__ import annotations

import asyncio
import math
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import List, Mapping, Optional, Sequence

from google.protobuf.timestamp_pb2 import Timestamp
from grpclib.const import Status
from grpclib.exceptions import GRPCError
from viam.components.base import Base
from viam.logging import getLogger
from viam.proto.common import (
    GeoGeometry,
    Geometry,
    GeoPoint,
    Pose,
    PoseInFrame,
    Transform,
    Vector3,
    WorldState,
)
from viam.proto.service.motion import (
    ComponentState,
    Constraints,
    GetPlanResponse,
    MotionConfiguration,
    Plan,
    PlanState,
    PlanStatus,
    PlanStatusWithID,
    PlanStep,
    PlanWithStatus,
)
from viam.services.navigation import Navigation
from viam.utils import ValueTypes

from ..config import NavConfig, body_twist_to_viam_set_velocity
from ..geom import conversions as conv
from ..nav.motion.motion_summary import summarize_nav_motion
from ..nav.motion.simple_motion import (
    ObstacleConfig,
    SimpleMotionCanceled,
    SimpleMotionError,
    config_from_nav,
    drive_to_pose,
)
from ..nav.stores import zones as zones_mod
from ..nav.stores.locations import LocationStore
from ..nav.stores.maps import MapHandle
from ..nav.stores.routes import Route, RouteStore
from ..nav.stores.zones import ZoneStore
from .do_command_util import build_alias_map, dispatch_do_command, require
from .nav_api import NavigationApi

LOGGER = getLogger(__name__)

_TERMINAL_PLAN_STATES = frozenset(
    {
        PlanState.PLAN_STATE_SUCCEEDED,
        PlanState.PLAN_STATE_FAILED,
        PlanState.PLAN_STATE_STOPPED,
    }
)


def _world_is_mapping(world) -> bool:
    """True only while the in-process SLAM service is building the map."""
    fn = getattr(world, "slam_mode", None)
    if not callable(fn):
        return False
    try:
        return str(fn() or "") == "mapping"
    except Exception:  # noqa: BLE001
        return False


def _nav_status_to_plan_state(status: Mapping) -> PlanState:
    """Map bridge ``nav_status()`` into a Motion ``PlanState``."""
    if status.get("active"):
        return PlanState.PLAN_STATE_IN_PROGRESS
    state = str(status.get("state") or "").lower()
    if state == "succeeded":
        return PlanState.PLAN_STATE_SUCCEEDED
    if state in ("canceled", "cancelled"):
        return PlanState.PLAN_STATE_STOPPED
    if state in ("failed", "aborted", "rejected"):
        return PlanState.PLAN_STATE_FAILED
    return PlanState.PLAN_STATE_UNSPECIFIED


def _utcnow_timestamp() -> Timestamp:
    ts = Timestamp()
    ts.FromDatetime(datetime.now(timezone.utc))
    return ts


def _pose2d_to_viam_pose_msg(pose: conv.Pose2D) -> Pose:
    x_mm, y_mm, z_mm, o_x, o_y, o_z, theta_deg = conv.pose2d_to_viam_slam_pose(pose)
    return Pose(x=x_mm, y=y_mm, z=z_mm, o_x=o_x, o_y=o_y, o_z=o_z, theta=theta_deg)


@dataclass
class _PlanExecution:
    execution_id: str
    plan_id: str
    component_name: str
    destination: Pose
    state: PlanState = PlanState.PLAN_STATE_IN_PROGRESS
    reason: Optional[str] = None
    status_history: List[PlanStatus] = field(default_factory=list)


@dataclass
class _SuspendedNav:
    """Goal remembered by ``suspend`` so ``resume`` can re-issue navigate.

    Optional ``route_*`` fields resume a multi-waypoint route from this leg.
    """

    x: float
    y: float
    theta: float
    name: Optional[str] = None
    motion: str = "builtin"  # "builtin" | "simple"
    reason: Optional[str] = None
    route: Optional[str] = None
    route_index: Optional[int] = None
    route_waypoints: Optional[List[dict]] = None
    route_loop: bool = False

    def to_dict(self) -> dict:
        out = {
            "x": float(self.x),
            "y": float(self.y),
            "theta": float(self.theta),
            "motion": self.motion,
        }
        if self.name:
            out["name"] = self.name
        if self.reason:
            out["reason"] = self.reason
        if self.route:
            out["route"] = self.route
            out["route_index"] = int(self.route_index or 0)
            out["route_total"] = len(self.route_waypoints or [])
            out["loop"] = bool(self.route_loop)
        return out


def nav_limits_for_status(cfg: NavConfig) -> dict:
    return {
        "max_linear_mps": float(cfg.max_linear_velocity),
        "max_angular_rad_s": float(cfg.max_vel_theta),
    }


_NAV_DO_ALIASES = build_alias_map(
    {
        "delete_location": ("remove_location",),
        "delete_route": ("remove_route",),
        "get_last_plan": ("get_preview_plan",),
        "get_status": ("describe_motion", "what_am_i_doing"),
        "plan_to_location": ("compute_path_to_location",),
        "plan_to_point": ("compute_path_to_point",),
        "remove_waypoint": ("delete_waypoint",),
        "resume": ("resume_nav",),
        "suspend": ("pause_nav", "suspend_nav"),
    }
)


class NavServiceBase(NavigationApi, Navigation):
    """Runtime-agnostic navigation orchestration shared by the navigation models.

    Subclasses must implement :meth:`_resolve_runtime` (return the active
    ``SlamRuntime`` or ``None``) and :meth:`reconfigure`.
    """

    def __init__(self, name: str):
        super().__init__(name)
        self._cfg: Optional[NavConfig] = None
        self._base: Optional[Base] = None
        self._simple_nav_task: Optional[asyncio.Task] = None
        self._simple_nav_cancel: Optional[asyncio.Event] = None
        self._simple_nav_status: dict = {"state": "idle", "motion": "simple"}
        # Optional label (e.g. location name) merged into status["goal"].
        self._active_goal_name: Optional[str] = None
        self._plan_execution: Optional[_PlanExecution] = None
        self._plan_status_history: List[PlanStatusWithID] = []
        self._logged_motion_ignored: bool = False
        self._last_preview_plan: Optional[dict] = None
        # Multi-waypoint route runner (navigate_route).
        self._route_task: Optional[asyncio.Task] = None
        self._route_cancel: Optional[asyncio.Event] = None
        self._route_status: dict = {"state": "idle", "motion": "route"}
        # Set by ``suspend``; cleared by ``resume``, ``cancel``, ``stop_plan``,
        # or any new navigate / MoveOnMap / simple go.
        self._suspended: Optional[_SuspendedNav] = None
        # Builtin get_costmap cache (nav-stack-ui polls while Costmap is on).
        self._builtin_costmap_cache: Optional[dict] = None
        self._builtin_costmap_cache_at: float = 0.0
        # (map generation, zone revision) the cache was built from. While the
        # robot sits still the map generation only moves on heartbeat inserts,
        # so UI polls reuse the costmap instead of re-inflating the full grid.
        self._builtin_costmap_cache_key: Optional[tuple] = None
        # Idle local costmap (built on demand when UI asks for Local while not
        # navigating — the follower only refreshes local while a plan is active).
        self._idle_local_costmap = None
        self._idle_local_costmap_cache: Optional[dict] = None
        self._idle_local_costmap_cache_at: float = 0.0
        self._idle_global_occ = None
        self._idle_global_costs = None
        self._idle_global_costs_at: float = 0.0

    # -- runtime resolution (subclass-specific) ------------------------------
    def _resolve_runtime(self):
        """Return the active ``SlamRuntime`` or ``None``.

        Built-in model looks it up in the in-process registry by the SLAM
        service name; the external model returns its locally-built runtime.
        """
        raise NotImplementedError

    def _require_cfg(self) -> NavConfig:
        if self._cfg is None:
            raise RuntimeError("navigation service not configured")
        return self._cfg

    def _require_runtime(self):
        # Surface "not configured" before touching the runtime source.
        self._require_cfg()
        runtime = self._resolve_runtime()
        if runtime is None:
            raise RuntimeError("SLAM runtime unavailable")
        return runtime

    # -- Motion API ----------------------------------------------------------
    async def move(
        self,
        component_name: str,
        destination: PoseInFrame,
        world_state: Optional[WorldState] = None,
        constraints: Optional[Constraints] = None,
        *,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> bool:
        raise GRPCError(Status.UNIMPLEMENTED, "Move is not supported; use MoveOnMap")

    async def move_on_globe(
        self,
        component_name: str,
        destination: GeoPoint,
        movement_sensor_name: str,
        obstacles: Optional[Sequence[GeoGeometry]] = None,
        heading: Optional[float] = None,
        configuration: Optional[MotionConfiguration] = None,
        *,
        bounding_regions: Optional[Sequence[GeoGeometry]] = None,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> str:
        raise GRPCError(
            Status.UNIMPLEMENTED,
            "MoveOnGlobe is not supported; use MoveOnMap for map-frame navigation",
        )

    async def move_on_map(
        self,
        component_name: str,
        destination: Pose,
        slam_service_name: str,
        configuration: Optional[MotionConfiguration] = None,
        obstacles: Optional[Sequence[Geometry]] = None,
        *,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> str:
        cfg = self._require_cfg()
        if component_name and component_name != cfg.base:
            LOGGER.warning(
                f"MoveOnMap component_name={component_name!r} does not match "
                f"configured base={cfg.base!r}; navigating configured base anyway"
            )
        if slam_service_name and slam_service_name != cfg.slam_service:
            LOGGER.warning(
                f"MoveOnMap slam_service_name={slam_service_name!r} does not match "
                f"configured slam_service={cfg.slam_service!r}; continuing anyway"
            )
        if (obstacles or configuration) and not self._logged_motion_ignored:
            LOGGER.info(
                "MoveOnMap obstacles/configuration are ignored in v1 "
                "(costmaps still use live lidar)"
            )
            self._logged_motion_ignored = True

        pose2d = conv.viam_pose_to_pose2d(
            destination.x, destination.y, destination.theta
        )
        runtime = self._require_runtime()
        mgr = runtime.manager

        # Preview-only: plan a path, do not drive.
        extra = extra or {}
        if bool(extra.get("preview") or extra.get("plan_only")):
            preview = await asyncio.to_thread(
                mgr.compute_path, pose2d.x, pose2d.y, pose2d.theta
            )
            self._last_preview_plan = preview
            if not preview.get("feasible"):
                raise GRPCError(
                    Status.FAILED_PRECONDITION,
                    preview.get("error_msg")
                    or f"no feasible path (error_code={preview.get('error_code')})",
                )
            # Return a synthetic execution id so callers can correlate with DoCommand
            # get_last_plan; motion is not started.
            return f"preview-{uuid.uuid4()}"

        # A new MoveOnMap supersedes any in-flight plan.
        if (
            self._plan_execution is not None
            and self._plan_execution.state not in _TERMINAL_PLAN_STATES
        ):
            self._record_plan_state(
                self._plan_execution, PlanState.PLAN_STATE_STOPPED, reason="superseded"
            )

        self._suspended = None
        execution_id = str(uuid.uuid4())
        plan_id = str(uuid.uuid4())
        base_name = component_name or cfg.base
        execution = _PlanExecution(
            execution_id=execution_id,
            plan_id=plan_id,
            component_name=base_name,
            destination=Pose(
                x=destination.x,
                y=destination.y,
                z=destination.z,
                o_x=destination.o_x,
                o_y=destination.o_y,
                o_z=destination.o_z,
                theta=destination.theta,
            ),
            state=PlanState.PLAN_STATE_IN_PROGRESS,
        )
        execution.status_history.append(
            PlanStatus(
                state=PlanState.PLAN_STATE_IN_PROGRESS,
                timestamp=_utcnow_timestamp(),
            )
        )
        self._plan_execution = execution
        self._active_goal_name = None
        self._upsert_plan_status_history(execution)

        await self._cancel_route()
        await self._cancel_simple_nav()
        await asyncio.to_thread(mgr.navigate, pose2d.x, pose2d.y, pose2d.theta)
        self._sync_plan_state_from_nav()
        return execution_id

    async def stop_plan(
        self,
        component_name: str,
        *,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> None:
        runtime = self._require_runtime()
        self._active_goal_name = None
        self._suspended = None
        await self._cancel_route()
        await self._cancel_simple_nav()
        await asyncio.to_thread(runtime.manager.cancel)
        if self._plan_execution is not None:
            self._record_plan_state(
                self._plan_execution, PlanState.PLAN_STATE_STOPPED, reason="stop_plan"
            )

    async def get_plan(
        self,
        component_name: str,
        last_plan_only: bool = False,
        execution_id: Optional[str] = None,
        *,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> GetPlanResponse:
        self._sync_plan_state_from_nav()
        execution = self._plan_execution
        if execution is None:
            raise GRPCError(Status.NOT_FOUND, "no motion plan has been started")
        if execution_id and execution.execution_id != execution_id:
            raise GRPCError(
                Status.NOT_FOUND,
                f"no plan found for execution_id={execution_id!r}",
            )
        # last_plan_only: we only keep the current plan (no replan history yet).
        _ = last_plan_only
        _ = component_name
        return self._plan_to_response(execution)

    async def list_plan_statuses(
        self,
        only_active_plans: bool = False,
        *,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> Sequence[PlanStatusWithID]:
        self._sync_plan_state_from_nav()
        statuses = list(self._plan_status_history)
        if only_active_plans:
            statuses = [
                s
                for s in statuses
                if s.status.state == PlanState.PLAN_STATE_IN_PROGRESS
            ]
        return statuses

    async def get_pose(
        self,
        component_name: str,
        destination_frame: str,
        supplemental_transforms: Optional[Sequence[Transform]] = None,
        *,
        extra: Optional[Mapping[str, ValueTypes]] = None,
        timeout: Optional[float] = None,
    ) -> PoseInFrame:
        _ = supplemental_transforms
        cfg = self._require_cfg()
        if component_name and component_name != cfg.base:
            LOGGER.warning(
                f"get_pose component_name={component_name!r} does not match "
                f"configured base={cfg.base!r}"
            )
        frame = destination_frame or "map"
        if frame not in ("map", ""):
            raise GRPCError(
                Status.INVALID_ARGUMENT,
                f"only destination_frame='map' is supported (got {destination_frame!r})",
            )
        pose2d = await asyncio.to_thread(
            self._require_runtime().manager.get_pose_in_map
        )
        if pose2d is None:
            raise GRPCError(Status.FAILED_PRECONDITION, "current map pose unavailable")
        return PoseInFrame(reference_frame="map", pose=_pose2d_to_viam_pose_msg(pose2d))

    def _record_plan_state(
        self,
        execution: _PlanExecution,
        state: PlanState,
        *,
        reason: Optional[str] = None,
    ) -> None:
        if execution.state == state and (reason is None or execution.reason == reason):
            self._upsert_plan_status_history(execution)
            return
        execution.state = state
        execution.reason = reason
        status = PlanStatus(state=state, timestamp=_utcnow_timestamp())
        if reason:
            status.reason = reason
        execution.status_history.append(status)
        self._upsert_plan_status_history(execution)

    def _upsert_plan_status_history(self, execution: _PlanExecution) -> None:
        entry = PlanStatusWithID(
            plan_id=execution.plan_id,
            execution_id=execution.execution_id,
            component_name=execution.component_name,
            status=PlanStatus(
                state=execution.state,
                timestamp=_utcnow_timestamp(),
                reason=execution.reason or "",
            ),
        )
        updated: List[PlanStatusWithID] = []
        found = False
        for existing in self._plan_status_history:
            if existing.execution_id == execution.execution_id:
                updated.append(entry)
                found = True
            else:
                updated.append(existing)
        if not found:
            updated.append(entry)
        # Keep a bounded history of recent executions.
        self._plan_status_history = updated[-20:]

    def _sync_plan_state_from_nav(self) -> None:
        execution = self._plan_execution
        if execution is None:
            return
        if execution.state == PlanState.PLAN_STATE_STOPPED:
            # Explicit stop_plan / superseded — do not overwrite from live nav.
            self._upsert_plan_status_history(execution)
            return
        try:
            status = self._require_runtime().manager.nav_status()
        except Exception:  # noqa: BLE001 - plan queries should still return last known
            return
        mapped = _nav_status_to_plan_state(status)
        if mapped == PlanState.PLAN_STATE_UNSPECIFIED:
            if execution.state not in _TERMINAL_PLAN_STATES:
                mapped = PlanState.PLAN_STATE_IN_PROGRESS
            else:
                self._upsert_plan_status_history(execution)
                return
        reason = None
        if mapped == PlanState.PLAN_STATE_FAILED:
            reason = str(status.get("state") or "failed")
        self._record_plan_state(execution, mapped, reason=reason)

    def _plan_to_response(self, execution: _PlanExecution) -> GetPlanResponse:
        component_key = str(Base.get_resource_name(execution.component_name))
        plan = Plan(
            id=execution.plan_id,
            execution_id=execution.execution_id,
            component_name=execution.component_name,
            steps=[
                PlanStep(
                    step={
                        component_key: ComponentState(pose=execution.destination),
                    }
                )
            ],
        )
        current = PlanStatus(
            state=execution.state,
            timestamp=_utcnow_timestamp(),
            reason=execution.reason or "",
        )
        return GetPlanResponse(
            current_plan_with_status=PlanWithStatus(
                plan=plan,
                status=current,
                status_history=list(execution.status_history),
            )
        )

    # -- store helpers -------------------------------------------------------
    def _active_handle(self) -> MapHandle:
        runtime = self._require_runtime()
        handle = runtime.map_store.active_handle()
        if handle is None:
            raise RuntimeError("no active map; create/select one via the SLAM service")
        return handle

    def _locations(self) -> LocationStore:
        return LocationStore(self._active_handle().locations_path)

    def _routes(self) -> RouteStore:
        return RouteStore(self._active_handle().routes_path)

    def _zones(self) -> ZoneStore:
        return ZoneStore(self._active_handle().zones_path)

    def _route_to_dict(self, route: Route, *, resolve: bool = True) -> dict:
        """Serialize a route; optionally attach pose fields from locations."""
        out: dict = {"name": route.name, "waypoints": []}
        locs = self._locations() if resolve else None
        for loc_name in route.waypoints:
            wp: dict = {"location": loc_name}
            if locs is not None:
                try:
                    loc = locs.get(loc_name)
                    wp["x"] = loc.x
                    wp["y"] = loc.y
                    wp["theta"] = loc.theta
                except KeyError:
                    wp["missing"] = True
            out["waypoints"].append(wp)
        return out

    def _require_location_names(self, names: Sequence[str]) -> None:
        store = self._locations()
        for n in names:
            store.get(str(n))

    def _refresh_zone_masks(self) -> None:
        runtime = self._require_runtime()
        mgr = runtime.manager
        zone_list = self._zones().list()
        # Builtin host: store geometries and (re)rasterize against the live map.
        set_zones = getattr(mgr, "set_zones", None)
        if callable(set_zones):
            set_zones(zone_list)
            return
        # Legacy path: pre-rasterize and publish OccupancyGrid-style masks.
        grid = None
        get_map = getattr(mgr, "get_map", None)
        if callable(get_map):
            grid = get_map()
        if not grid:
            node = getattr(mgr, "node", None)
            if node is not None and hasattr(node, "get_map"):
                grid = node.get_map()
        if not grid:
            LOGGER.warning(
                "no map yet; zone masks will publish once a map is available"
            )
            return
        h, w = grid["grid"].shape
        res = grid["resolution"]
        ox, oy = grid["origin_x"], grid["origin_y"]
        keepout = zones_mod.rasterize_zones(
            zone_list, zones_mod.KEEPOUT, w, h, res, ox, oy
        )
        speed = zones_mod.rasterize_zones(
            zone_list, zones_mod.SPEED_LIMIT, w, h, res, ox, oy
        )
        publish = getattr(mgr, "publish_zone_masks", None)
        if callable(publish):
            publish(keepout, speed, res, ox, oy)

    # -- DoCommand -----------------------------------------------------------
    def _do_command_handlers(self):
        return {
            "add_location": self._cmd_add_location,
            "get_location": self._cmd_get_location,
            "list_locations": self._cmd_list_locations,
            "update_location": self._cmd_update_location,
            "delete_location": self._cmd_delete_location,
            "delete_all_locations": self._cmd_delete_all_locations,
            "add_route": self._cmd_add_route,
            "get_route": self._cmd_get_route,
            "list_routes": self._cmd_list_routes,
            "update_route": self._cmd_update_route,
            "delete_route": self._cmd_delete_route,
            "delete_all_routes": self._cmd_delete_all_routes,
            "list_waypoints": self._cmd_list_waypoints,
            "set_waypoints": self._cmd_set_waypoints,
            "clear_waypoints": self._cmd_clear_waypoints,
            "add_waypoint": self._cmd_add_waypoint,
            "update_waypoint": self._cmd_update_waypoint,
            "remove_waypoint": self._cmd_remove_waypoint,
            "move_waypoint": self._cmd_move_waypoint,
            "add_zone": self._cmd_add_zone,
            "get_zone": self._cmd_get_zone,
            "list_zones": self._cmd_list_zones,
            "update_zone": self._cmd_update_zone,
            "delete_zone": self._cmd_delete_zone,
            "delete_all_zones": self._cmd_delete_all_zones,
            "navigate_to_location": self._cmd_navigate_to_location,
            "navigate_to_point": self._cmd_navigate_to_point,
            "navigate_route": self._cmd_navigate_route,
            "plan_to_point": self._cmd_plan_to_point,
            "plan_to_location": self._cmd_plan_to_location,
            "get_last_plan": self._cmd_get_last_plan,
            "execute_plan": self._cmd_execute_plan,
            "go_to_location": self._cmd_go_to_location,
            "go_to_point": self._cmd_go_to_point,
            "suspend": self._cmd_suspend,
            "resume": self._cmd_resume,
            "cancel": self._cmd_cancel,
            "test_drive": self._cmd_test_drive,
            "get_trace": self._cmd_get_trace,
            "get_status": self._cmd_get_status,
            "get_costmap": self._cmd_get_costmap,
        }

    async def do_command(
        self,
        command: Mapping[str, ValueTypes],
        *,
        timeout: Optional[float] = None,
        **kwargs,
    ) -> Mapping[str, ValueTypes]:
        self._require_runtime()
        return await dispatch_do_command(
            self._do_command_handlers(),
            command,
            aliases=_NAV_DO_ALIASES,
        )

    def _cmd_add_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        loc = self._add_location(command, runtime)
        return {"location": loc.to_dict()}

    def _cmd_get_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        name = require(command, "name", str)
        return {"location": self._locations().get(name).to_dict()}

    def _cmd_list_locations(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return {"locations": [loc.to_dict() for loc in self._locations().list()]}

    def _cmd_update_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        old_name = str(command["name"])
        loc = self._locations().update(
            old_name,
            x=command.get("x"),
            y=command.get("y"),
            theta=command.get("theta"),
            new_name=command.get("new_name"),
        )
        new_name = command.get("new_name")
        if new_name is not None and str(new_name) != old_name:
            self._routes().rename_location_refs(old_name, str(new_name))
        return {"location": loc.to_dict()}

    def _cmd_delete_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        name = str(command["name"])
        self._locations().delete(name)
        self._routes().remove_location_refs(name)
        return {"status": "deleted"}

    def _cmd_delete_all_locations(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        self._locations().delete_all()
        # Empty locations → clear every route's waypoints (routes remain).
        routes = self._routes()
        for route in routes.list():
            routes.clear_waypoints(route.name)
        return {"status": "deleted"}

    def _cmd_add_route(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        name = str(command["name"])
        raw_wps = command.get("waypoints") or []
        if not isinstance(raw_wps, (list, tuple)):
            raise ValueError("waypoints must be a list of location names")
        waypoints = [
            str(w.get("location", w) if isinstance(w, Mapping) else w) for w in raw_wps
        ]
        self._require_location_names(waypoints)
        route = self._routes().add(name, waypoints)
        return {"route": self._route_to_dict(route)}

    def _cmd_get_route(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route = self._routes().get(str(command["name"]))
        return {"route": self._route_to_dict(route)}

    def _cmd_list_routes(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return {"routes": [self._route_to_dict(r) for r in self._routes().list()]}

    def _cmd_update_route(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route = self._routes().update(
            str(command["name"]),
            new_name=command.get("new_name"),
        )
        return {"route": self._route_to_dict(route)}

    def _cmd_delete_route(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        self._routes().delete(str(command["name"]))
        return {"status": "deleted"}

    def _cmd_delete_all_routes(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        self._routes().delete_all()
        return {"status": "deleted"}

    def _cmd_list_waypoints(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route = self._routes().get(str(command["route"]))
        return {
            "route": route.name,
            "waypoints": self._route_to_dict(route)["waypoints"],
        }

    def _cmd_set_waypoints(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route_name = str(command["route"])
        raw_wps = command.get("waypoints") or []
        if not isinstance(raw_wps, (list, tuple)):
            raise ValueError("waypoints must be a list of location names")
        waypoints = [
            str(w.get("location", w) if isinstance(w, Mapping) else w) for w in raw_wps
        ]
        self._require_location_names(waypoints)
        route = self._routes().set_waypoints(route_name, waypoints)
        return {"route": self._route_to_dict(route)}

    def _cmd_clear_waypoints(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route = self._routes().clear_waypoints(str(command["route"]))
        return {"route": self._route_to_dict(route)}

    def _cmd_add_waypoint(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route_name = str(command["route"])
        location = str(command["location"])
        self._require_location_names([location])
        index = command.get("index")
        route = self._routes().add_waypoint(
            route_name,
            location,
            index=int(index) if index is not None else None,
        )
        return {"route": self._route_to_dict(route)}

    def _cmd_update_waypoint(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route_name = str(command["route"])
        location = str(command["location"])
        self._require_location_names([location])
        route = self._routes().update_waypoint(
            route_name, int(command["index"]), location
        )
        return {"route": self._route_to_dict(route)}

    def _cmd_remove_waypoint(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route_name = str(command["route"])
        index = command.get("index")
        location = command.get("location")
        route = self._routes().remove_waypoint(
            route_name,
            index=int(index) if index is not None else None,
            location=str(location) if location is not None else None,
        )
        return {"route": self._route_to_dict(route)}

    def _cmd_move_waypoint(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        route = self._routes().move_waypoint(
            str(command["route"]),
            int(command["from_index"]),
            int(command["to_index"]),
        )
        return {"route": self._route_to_dict(route)}

    def _cmd_add_zone(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        zone = self._zones().add(
            str(command["name"]),
            str(command["type"]),
            dict(command["geometry"]),
            speed_pct=command.get("speed_pct"),
        )
        self._refresh_zone_masks()
        return {"zone": zone.to_dict()}

    def _cmd_get_zone(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return {"zone": self._zones().get(str(command["name"])).to_dict()}

    def _cmd_list_zones(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        zlist = self._zones().list(command.get("type"))
        return {"zones": [z.to_dict() for z in zlist]}

    def _cmd_update_zone(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        zone = self._zones().update(
            str(command["name"]),
            type=command.get("type"),
            geometry=dict(command["geometry"]) if "geometry" in command else None,
            speed_pct=command.get("speed_pct"),
            new_name=command.get("new_name"),
        )
        self._refresh_zone_masks()
        return {"zone": zone.to_dict()}

    def _cmd_delete_zone(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        self._zones().delete(str(command["name"]))
        self._refresh_zone_masks()
        return {"status": "deleted"}

    def _cmd_delete_all_zones(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        self._zones().delete_all(command.get("type"))
        self._refresh_zone_masks()
        return {"status": "deleted"}

        # navigate/cancel/status may block (planning / drive). Keep them off the
        # module event loop so Base.SetVelocity and sensor reads stay responsive.

    async def _cmd_navigate_to_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        loc = self._locations().get(require(command, "name", str))
        self._suspended = None
        self._active_goal_name = loc.name
        await self._cancel_route()
        await self._cancel_simple_nav()
        await asyncio.to_thread(mgr.navigate, loc.x, loc.y, loc.theta)
        return {"status": "navigating", "target": loc.to_dict()}

    async def _cmd_navigate_to_point(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        x = require(command, "x", float)
        y = require(command, "y", float)
        theta = require(command, "theta", float, default=0.0)
        self._suspended = None
        self._active_goal_name = None
        await self._cancel_route()
        await self._cancel_simple_nav()
        await asyncio.to_thread(mgr.navigate, x, y, theta)
        return {"status": "navigating", "target": {"x": x, "y": y, "theta": theta}}

    async def _cmd_navigate_route(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return await self._start_navigate_route(command)

    async def _cmd_plan_to_point(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        return await self._plan_preview(command, mgr)

    async def _cmd_plan_to_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        loc = self._locations().get(str(command["name"]))
        payload = dict(command)
        payload["x"] = loc.x
        payload["y"] = loc.y
        payload["theta"] = loc.theta
        preview = await self._plan_preview(payload, mgr)
        preview["location"] = loc.to_dict()
        self._last_preview_plan = preview
        return preview

    def _cmd_get_last_plan(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        preview = self._last_preview_plan or mgr.last_preview_plan()
        if not preview:
            raise ValueError("no preview plan; call plan_to_point first")
        return {"plan": preview}

    async def _cmd_execute_plan(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        preview = self._last_preview_plan or mgr.last_preview_plan()
        if not preview:
            raise ValueError("no preview plan; call plan_to_point first")
        if not preview.get("feasible"):
            raise ValueError(
                preview.get("error_msg")
                or f"last preview was not feasible (error_code={preview.get('error_code')})"
            )
        goal = preview.get("goal") or {}
        x = float(goal["x"])
        y = float(goal["y"])
        theta = float(goal.get("theta", 0.0))
        name = (
            preview.get("location", {}).get("name")
            if isinstance(preview.get("location"), dict)
            else None
        )
        self._suspended = None
        self._active_goal_name = name
        await self._cancel_route()
        await self._cancel_simple_nav()
        await asyncio.to_thread(mgr.navigate, x, y, theta)
        return {
            "status": "navigating",
            "target": {
                "x": x,
                "y": y,
                "theta": theta,
                **({"name": name} if name else {}),
            },
            "from_preview": True,
            "length_m": preview.get("length_m"),
        }

    async def _cmd_go_to_location(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        loc = self._locations().get(str(command["name"]))
        self._suspended = None
        self._active_goal_name = loc.name
        await self._cancel_route()
        return await self._start_simple_go(loc.x, loc.y, loc.theta, command)

    async def _cmd_go_to_point(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        x = require(command, "x", float)
        y = require(command, "y", float)
        theta = require(command, "theta", float, default=0.0)
        self._suspended = None
        self._active_goal_name = None
        await self._cancel_route()
        return await self._start_simple_go(x, y, theta, command)

    async def _cmd_suspend(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return await self._suspend_nav(command)

    async def _cmd_resume(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return await self._resume_nav(command)

    async def _cmd_cancel(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        mgr = runtime.manager
        self._active_goal_name = None
        self._suspended = None
        await self._cancel_route()
        await self._cancel_simple_nav()
        await asyncio.to_thread(mgr.cancel)
        if self._plan_execution is not None:
            self._record_plan_state(
                self._plan_execution,
                PlanState.PLAN_STATE_STOPPED,
                reason="cancel",
            )
        return {"status": "canceled"}

    async def _cmd_test_drive(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        return await self._test_drive(command)

    def _cmd_get_trace(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        from ..nav.control.supervisor import recent_trace

        seconds = float(command.get("seconds", 30.0))
        return {"ticks": recent_trace(seconds)}

    async def _cmd_get_status(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        cmd = str(command.get("command"))
        runtime = self._require_runtime()
        mgr = runtime.manager

        def _status():
            status = mgr.nav_status()
            simple = dict(self._simple_nav_status)
            status["simple_nav"] = simple
            if simple.get("state") == "active":
                status["active"] = True
                status["motion"] = "simple"
                # Prefer simple-nav target when active (builtin goal may be stale).
                target = simple.get("target")
                if isinstance(target, dict):
                    status["goal"] = dict(target)
            goal = status.get("goal")
            if isinstance(goal, dict) and self._active_goal_name:
                goal = dict(goal)
                goal["name"] = self._active_goal_name
                status["goal"] = goal
            status["localization_check"] = dict(runtime.localization_check)
            state = runtime.localization_check.get("state")
            if isinstance(state, dict):
                status["localization_state"] = dict(state)
            pose = status.get("pose")
            if not isinstance(pose, dict) or "x" not in pose:
                live = self._live_map_pose_dict(mgr)
                if live is not None:
                    status["pose"] = live
            suspended = self._suspended
            status["suspended"] = suspended is not None
            status["suspended_goal"] = (
                suspended.to_dict() if suspended is not None else None
            )
            route = dict(self._route_status)
            status["route"] = route
            if route.get("state") == "active":
                status["active"] = True
                status["motion"] = "route"
            return status

        status = await asyncio.to_thread(_status)
        if cmd == "get_status":
            try:
                cfg = self._require_cfg()
                fl = cfg.footprint_length_m
                fw = cfg.footprint_width_m
                if fl and fw:
                    status["footprint_length_m"] = float(fl)
                    status["footprint_width_m"] = float(fw)
                else:
                    diam = 2.0 * float(cfg.robot_radius)
                    status["footprint_length_m"] = diam
                    status["footprint_width_m"] = diam
                status["robot_radius_m"] = float(cfg.hard_clearance_radius_m())
                status["limits"] = nav_limits_for_status(cfg)
            except Exception:  # noqa: BLE001
                pass
            return status
        cfg = self._require_cfg()
        return summarize_nav_motion(
            status,
            max_vel_x=float(cfg.max_linear_velocity),
            max_vel_theta=float(cfg.max_vel_theta),
        )

    async def _cmd_get_costmap(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        runtime = self._require_runtime()
        # Inflated costmap for operator UIs (nav-stack-ui Costmap toggle).
        # ``layer``: ``auto`` (local while navigating, else global), ``local``
        # (rolling window around the robot — refreshed on demand even when
        # idle), or ``global``.
        from ..runtime import get_nav_view

        view = get_nav_view(self.name)
        if view is None:
            return {"available": False, "reason": "viz_unavailable"}

        cfg = self._require_cfg()
        layer_req = str(command.get("layer", "auto")).lower()
        if layer_req not in ("local", "global", "auto"):
            layer_req = "auto"

        def _fetch():
            import time as _time

            if hasattr(view, "enable_viz"):
                view.enable_viz(8)
            snap = (
                view.viz_snapshot()
                if hasattr(view, "viz_snapshot")
                else view.snapshot()
            )

            nav_active = False
            try:
                nav_active = bool(runtime.manager.nav_status().get("active"))
            except Exception:  # noqa: BLE001
                pass
            use_local = layer_req == "local" or (layer_req == "auto" and nav_active)
            layer_used = "global"
            cm = None

            if use_local:
                # Follower only refreshes snap["local_costmap"] while a plan
                # is active. Prefer that live map when navigating; when idle,
                # never reuse a stale snap — rebuild the rolling window.
                local_cm = snap.get("local_costmap") if nav_active else None
                if local_cm is not None and local_cm.get("grid") is not None:
                    cm = local_cm
                    layer_used = "local"
                elif layer_req == "local":
                    idle = self._build_idle_local_costmap(runtime, view, cfg)
                    if idle is not None:
                        cm = idle
                        layer_used = "local"

            if cm is None:
                cm = snap.get("costmap")
            if layer_used == "global":
                now = _time.monotonic()
                cached = self._builtin_costmap_cache
                if cached is not None and now - self._builtin_costmap_cache_at < 0.2:
                    return cached, layer_used
                # Always refresh from the live SLAM/world map — never prefer
                # snap["map"], which is only updated when something else
                # called world.get_map() (often stale throughout mapping).
                mp = None
                world = getattr(runtime.manager, "_world", None)
                if world is None:
                    world = getattr(runtime.manager, "_builtin_world", None)
                if world is not None and hasattr(world, "get_map"):
                    try:
                        mp = world.get_map()
                    except Exception:  # noqa: BLE001
                        mp = None
                if mp is None or mp.get("grid") is None:
                    if hasattr(runtime.manager, "get_map"):
                        try:
                            mp = runtime.manager.get_map()
                        except Exception:  # noqa: BLE001
                            mp = None
                if mp is None or mp.get("grid") is None:
                    if hasattr(view, "get_map"):
                        mp = view.get_map()
                if mp is None or mp.get("grid") is None:
                    mp = snap.get("map")
                if mp is not None and mp.get("grid") is not None:
                    generation = mp.get("generation")
                    zone_rev = 0
                    rev_fn = (
                        getattr(world, "zone_mask_revision", None) if world else None
                    )
                    if not callable(rev_fn):
                        rev_fn = getattr(runtime.manager, "zone_mask_revision", None)
                    if callable(rev_fn):
                        try:
                            zone_rev = int(rev_fn())
                        except Exception:  # noqa: BLE001
                            zone_rev = 0
                    mapping = _world_is_mapping(world)
                    key = (generation, zone_rev, mapping)
                    if (
                        cached is not None
                        and generation is not None
                        and key == self._builtin_costmap_cache_key
                    ):
                        # Same map + zones: the inflated costmap is unchanged.
                        self._builtin_costmap_cache_at = now
                        return cached, layer_used

                    from ..nav.planning.costmap import (
                        build_costmap,
                        costmap_viz_dict,
                        occupancy_from_map_dict,
                    )

                    occ = occupancy_from_map_dict(mp)
                    masks = None
                    zone_for = getattr(world, "zone_masks_for", None) if world else None
                    if not callable(zone_for):
                        zone_for = getattr(runtime.manager, "zone_masks_for", None)
                    if callable(zone_for):
                        try:
                            masks = zone_for(mp)
                        except Exception:  # noqa: BLE001
                            masks = None
                    if masks is not None and masks.keepout.shape == occ.grid.shape:
                        from ..nav.types import OccupancyGrid

                        occ = OccupancyGrid(
                            grid=zones_mod.apply_keepout_to_grid(
                                occ.grid, masks.keepout
                            ),
                            resolution=occ.resolution,
                            origin_x=occ.origin_x,
                            origin_y=occ.origin_y,
                        )
                    costs = build_costmap(
                        occ,
                        # Same radii the planner uses, so the rendered ring
                        # matches the costmap paths are actually planned on.
                        inflation_radius_m=cfg.effective_inflation_radius_m(),
                        robot_radius_m=cfg.hard_clearance_radius_m(),
                        body_radius_m=cfg.inscribed_radius_m(),
                        cost_scaling_factor=float(cfg.builtin.cost_scaling_factor),
                        mapping=mapping,
                    )
                    cm = costmap_viz_dict(occ, costs)
                    self._builtin_costmap_cache = cm
                    self._builtin_costmap_cache_at = now
                    self._builtin_costmap_cache_key = key
                    # Keep nav-camera / viz store in sync with the live map.
                    try:
                        if hasattr(view, "set_map"):
                            view.set_map(mp)
                        if hasattr(view, "set_costmap"):
                            view.set_costmap(cm)
                        elif hasattr(view, "_viz_lock"):
                            with view._viz_lock:  # noqa: SLF001
                                view._viz_global_costmap = {  # noqa: SLF001
                                    "grid": cm["grid"],
                                    "resolution": cm["resolution"],
                                    "origin_x": cm["origin_x"],
                                    "origin_y": cm["origin_y"],
                                }
                    except Exception:  # noqa: BLE001
                        pass
            if cm is None:
                cm = snap.get("map")
            return cm, layer_used

        cm, layer_used = await asyncio.to_thread(_fetch)
        if not cm or cm.get("grid") is None:
            return {"available": False, "reason": "no_costmap"}

        import base64

        import numpy as np

        grid = np.asarray(cm["grid"])
        # Default stride=2 (~10 cm cells) keeps RPC payloads modest for UI poll.
        stride = max(1, int(command.get("stride", 2)))
        if stride > 1:
            grid = grid[::stride, ::stride]
        height, width = int(grid.shape[0]), int(grid.shape[1])
        resolution = float(cm["resolution"]) * stride
        # 255 = unknown (-1); 0 free; 1..100 cost.
        u8 = np.where(grid < 0, 255, np.clip(grid, 0, 100)).astype(np.uint8)
        return {
            "available": True,
            "layer": layer_used,
            "origin_x": float(cm["origin_x"]),
            "origin_y": float(cm["origin_y"]),
            "resolution": resolution,
            "width": width,
            "height": height,
            "encoding": "uint8_row_major",
            "unknown": 255,
            "data_b64": base64.b64encode(u8.tobytes()).decode("ascii"),
            "nav_backend": cfg.nav_backend,
        }

    def _build_idle_local_costmap(self, runtime, view, cfg: NavConfig):
        """Rolling local costmap while idle (UI Local layer / get_costmap).

        Builtin nav only refreshes local inside an active follower; without this
        the Local toggle falls back to global whenever no plan is running.
        """
        import time as _time

        now = _time.monotonic()
        cached = self._idle_local_costmap_cache
        if cached is not None and now - self._idle_local_costmap_cache_at < 0.2:
            return cached

        if not bool(getattr(cfg.builtin, "local_costmap_enabled", True)):
            return None

        world = getattr(runtime.manager, "_world", None)
        if world is None:
            world = getattr(runtime.manager, "_builtin_world", None)
        if world is None:
            return None

        pose = None
        if hasattr(world, "get_pose"):
            try:
                pose = world.get_pose()
            except Exception:  # noqa: BLE001
                pose = None
        if pose is None:
            getter = getattr(runtime.manager, "get_pose_in_map", None)
            if callable(getter):
                try:
                    pose = getter()
                except Exception:  # noqa: BLE001
                    pose = None
        if pose is None:
            return None

        scan = None
        if hasattr(world, "get_scan"):
            try:
                age = float(getattr(cfg, "simple_scan_max_age", 2.0) or 2.0)
                scan = world.get_scan(age)
            except Exception:  # noqa: BLE001
                scan = None

        from ..nav.planning.costmap import (
            build_costmap,
            local_view_viz_dict,
            occupancy_from_map_dict,
        )
        from ..nav.planning.local_costmap import LocalCostmap, LocalCostmapConfig

        bcfg = cfg.builtin
        if self._idle_local_costmap is None:
            self._idle_local_costmap = LocalCostmap(
                LocalCostmapConfig(
                    width_m=float(bcfg.local_costmap_width_m),
                    height_m=float(bcfg.local_costmap_height_m),
                    resolution=float(bcfg.local_costmap_resolution),
                    inflation_radius_m=float(cfg.effective_local_inflation_radius_m()),
                    robot_radius_m=float(cfg.hard_clearance_radius_m()),
                    body_radius_m=float(cfg.inscribed_radius_m()),
                    cost_scaling_factor=float(bcfg.cost_scaling_factor),
                    scan_inflation_radius_m=float(
                        cfg.effective_local_inflation_radius_m()
                    ),
                )
            )

        global_occ = self._idle_global_occ
        global_costs = self._idle_global_costs
        if (
            global_occ is None
            or global_costs is None
            or now - self._idle_global_costs_at >= 2.0
        ):
            global_occ = None
            global_costs = None
            mp = None
            if hasattr(world, "get_map"):
                try:
                    mp = world.get_map()
                except Exception:  # noqa: BLE001
                    mp = None
            if mp is not None and mp.get("grid") is not None:
                try:
                    global_occ = occupancy_from_map_dict(mp)
                    global_costs = build_costmap(
                        global_occ,
                        inflation_radius_m=cfg.effective_inflation_radius_m(),
                        robot_radius_m=cfg.hard_clearance_radius_m(),
                        body_radius_m=cfg.inscribed_radius_m(),
                        cost_scaling_factor=float(bcfg.cost_scaling_factor),
                        mapping=_world_is_mapping(world),
                    )
                    self._idle_global_occ = global_occ
                    self._idle_global_costs = global_costs
                    self._idle_global_costs_at = now
                except Exception:  # noqa: BLE001
                    global_occ = None
                    global_costs = None

        try:
            local_view = self._idle_local_costmap.update(
                pose,
                scan,
                global_occ=global_occ,
                global_costs=global_costs,
                mapping=_world_is_mapping(world),
            )
            cm = local_view_viz_dict(local_view)
        except Exception:  # noqa: BLE001
            return None

        self._idle_local_costmap_cache = cm
        self._idle_local_costmap_cache_at = now
        try:
            if hasattr(view, "set_viz_local_costmap"):
                view.set_viz_local_costmap(cm)
            elif hasattr(world, "set_viz_local_costmap"):
                world.set_viz_local_costmap(cm)
        except Exception:  # noqa: BLE001
            pass
        return cm

    def _add_location(self, command, runtime):
        store = self._locations()
        if "pose" in command or "x" in command:
            pose = command.get("pose", command)
            return store.add(
                str(command["name"]),
                float(pose["x"]),
                float(pose["y"]),
                float(pose.get("theta", 0.0)),
            )
        # Default to the robot's current pose in the map.
        mgr = runtime.manager
        cur = None
        getter = getattr(mgr, "get_pose_in_map", None)
        if callable(getter):
            cur = getter()
        if cur is None:
            node = getattr(mgr, "node", None)
            cur = node.get_pose_in_map() if node else None
        if cur is None:
            raise RuntimeError("current pose unavailable; provide an explicit pose")
        return store.add(str(command["name"]), cur.x, cur.y, cur.theta)

    # -- suspend / resume (cancel + remembered goal) -------------------------
    def _snapshot_active_goal(self) -> Optional[_SuspendedNav]:
        """Capture the in-flight builtin, simple-nav, or route target, if any."""
        name = self._active_goal_name
        route_st = self._route_status
        route_active = route_st.get("state") == "active"
        route_name = route_st.get("name") if route_active else None
        route_index = int(route_st.get("index", 0)) if route_active else None
        route_waypoints = (
            list(route_st.get("waypoints") or []) if route_active else None
        )
        route_loop = bool(route_st.get("loop")) if route_active else False

        simple = self._simple_nav_status
        if simple.get("state") == "active":
            target = simple.get("target")
            if isinstance(target, Mapping):
                return _SuspendedNav(
                    x=float(target["x"]),
                    y=float(target["y"]),
                    theta=float(target.get("theta", 0.0)),
                    name=name,
                    motion="simple",
                    route=route_name,
                    route_index=route_index,
                    route_waypoints=route_waypoints,
                    route_loop=route_loop,
                )

        status: Mapping = {}
        try:
            status = self._require_runtime().manager.nav_status()
        except Exception:  # noqa: BLE001 - fall through to plan execution
            status = {}
        nav_active = bool(status.get("active")) or str(
            status.get("state") or ""
        ).lower() in ("active",)
        goal = status.get("goal") if isinstance(status.get("goal"), Mapping) else None
        if (nav_active or route_active) and goal is not None:
            return _SuspendedNav(
                x=float(goal["x"]),
                y=float(goal["y"]),
                theta=float(goal.get("theta", 0.0)),
                name=name,
                motion="builtin",
                route=route_name,
                route_index=route_index,
                route_waypoints=route_waypoints,
                route_loop=route_loop,
            )
        if route_active and route_waypoints and route_index is not None:
            if 0 <= route_index < len(route_waypoints):
                wp = route_waypoints[route_index]
                return _SuspendedNav(
                    x=float(wp["x"]),
                    y=float(wp["y"]),
                    theta=float(wp.get("theta", 0.0)),
                    name=str(wp.get("location") or name or ""),
                    motion="builtin",
                    route=route_name,
                    route_index=route_index,
                    route_waypoints=route_waypoints,
                    route_loop=route_loop,
                )

        execution = self._plan_execution
        if execution is not None and execution.state not in _TERMINAL_PLAN_STATES:
            pose2d = conv.viam_pose_to_pose2d(
                execution.destination.x,
                execution.destination.y,
                execution.destination.theta,
            )
            return _SuspendedNav(
                x=pose2d.x,
                y=pose2d.y,
                theta=pose2d.theta,
                name=name,
                motion="builtin",
                route=route_name,
                route_index=route_index,
                route_waypoints=route_waypoints,
                route_loop=route_loop,
            )
        return None

    async def _suspend_nav(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        """Cancel motion but remember the goal for a later ``resume``."""
        reason = command.get("reason")
        reason_s = str(reason) if reason is not None else None
        snapshot = self._snapshot_active_goal()
        if snapshot is None and self._suspended is not None:
            # Already suspended; refresh optional reason and return current.
            if reason_s:
                self._suspended.reason = reason_s
            return {
                "status": "suspended",
                "already_suspended": True,
                "goal": self._suspended.to_dict(),
            }
        if snapshot is None:
            raise ValueError(
                "nothing to suspend (no active builtin or simple-nav goal)"
            )

        snapshot.reason = reason_s
        runtime = self._require_runtime()
        # Keep the label on the suspended snapshot; clear live goal name.
        self._active_goal_name = None
        await self._cancel_route(mark_canceled=False)
        await self._cancel_simple_nav()
        await asyncio.to_thread(runtime.manager.cancel)
        if self._plan_execution is not None:
            self._record_plan_state(
                self._plan_execution,
                PlanState.PLAN_STATE_STOPPED,
                reason="suspended",
            )
        self._suspended = snapshot
        return {"status": "suspended", "goal": snapshot.to_dict()}

    async def _resume_nav(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        """Re-issue the goal saved by ``suspend`` (replans from current pose)."""
        _ = command
        suspended = self._suspended
        if suspended is None:
            raise ValueError("nothing to resume (call suspend first)")

        self._suspended = None

        # Resume a multi-waypoint route from the suspended leg.
        if suspended.route and suspended.route_waypoints is not None:
            start = int(suspended.route_index or 0)
            return await self._start_navigate_route(
                {
                    "name": suspended.route,
                    "waypoints": suspended.route_waypoints,
                    "start_index": start,
                    "loop": bool(suspended.route_loop),
                    "wait": False,
                }
            )

        self._active_goal_name = suspended.name
        target = {
            "x": suspended.x,
            "y": suspended.y,
            "theta": suspended.theta,
            **({"name": suspended.name} if suspended.name else {}),
        }

        if suspended.motion == "simple":
            result = await self._start_simple_go(
                suspended.x,
                suspended.y,
                suspended.theta,
                {"wait": False},
            )
            out = dict(result)
            out["resumed"] = True
            out["target"] = target
            return out

        cfg = self._require_cfg()
        runtime = self._require_runtime()
        dest = _pose2d_to_viam_pose_msg(
            conv.Pose2D(suspended.x, suspended.y, suspended.theta)
        )
        execution_id = str(uuid.uuid4())
        plan_id = str(uuid.uuid4())
        execution = _PlanExecution(
            execution_id=execution_id,
            plan_id=plan_id,
            component_name=cfg.base,
            destination=dest,
            state=PlanState.PLAN_STATE_IN_PROGRESS,
        )
        execution.status_history.append(
            PlanStatus(
                state=PlanState.PLAN_STATE_IN_PROGRESS,
                timestamp=_utcnow_timestamp(),
            )
        )
        self._plan_execution = execution
        self._upsert_plan_status_history(execution)
        await self._cancel_simple_nav()
        await asyncio.to_thread(
            runtime.manager.navigate, suspended.x, suspended.y, suspended.theta
        )
        self._sync_plan_state_from_nav()
        return {
            "status": "navigating",
            "resumed": True,
            "target": target,
            "execution_id": execution_id,
        }

    # -- route navigation (ordered location waypoints) -----------------------
    def _resolve_route_waypoints(
        self,
        *,
        name: Optional[str] = None,
        waypoints: Optional[Sequence] = None,
    ) -> tuple[str, List[dict]]:
        """Build resolved waypoint list ``[{location,x,y,theta}, ...]``."""
        route_name = str(name) if name else ""
        resolved: List[dict] = []
        if waypoints is not None:
            raw = list(waypoints)
            if not route_name:
                route_name = "inline"
            for item in raw:
                if isinstance(item, Mapping):
                    if "x" in item and "y" in item:
                        resolved.append(
                            {
                                "location": str(
                                    item.get("location") or item.get("name") or ""
                                ),
                                "x": float(item["x"]),
                                "y": float(item["y"]),
                                "theta": float(item.get("theta", 0.0)),
                            }
                        )
                        continue
                    loc_name = str(item.get("location") or item.get("name") or "")
                else:
                    loc_name = str(item)
                loc = self._locations().get(loc_name)
                resolved.append(
                    {
                        "location": loc.name,
                        "x": loc.x,
                        "y": loc.y,
                        "theta": loc.theta,
                    }
                )
        else:
            if not route_name:
                raise ValueError("navigate_route requires name or waypoints")
            route = self._routes().get(route_name)
            if not route.waypoints:
                raise ValueError(f"route {route_name!r} has no waypoints")
            for loc_name in route.waypoints:
                loc = self._locations().get(loc_name)
                resolved.append(
                    {
                        "location": loc.name,
                        "x": loc.x,
                        "y": loc.y,
                        "theta": loc.theta,
                    }
                )
        if not resolved:
            raise ValueError("navigate_route requires at least one waypoint")
        return route_name, resolved

    def _nearest_route_index(
        self, waypoints: Sequence[Mapping], pose: conv.Pose2D
    ) -> int:
        """Return the index of the waypoint closest to ``pose`` in XY."""
        best_i = 0
        best_d2 = float("inf")
        px, py = float(pose.x), float(pose.y)
        for i, wp in enumerate(waypoints):
            dx = float(wp["x"]) - px
            dy = float(wp["y"]) - py
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best_i = i
        return best_i

    def _live_map_pose_dict(self, mgr) -> Optional[dict]:
        """Current map pose as meters/radians, or None when SLAM has no pose."""
        getter = getattr(mgr, "get_pose_in_map", None)
        pose = getter() if callable(getter) else None
        if pose is None:
            node = getattr(mgr, "node", None)
            if node is not None and hasattr(node, "get_pose_in_map"):
                pose = node.get_pose_in_map()
        if pose is None:
            return None
        try:
            return {
                "x": float(pose.x),
                "y": float(pose.y),
                "theta": float(pose.theta),
            }
        except (TypeError, ValueError):
            return None

    def _current_map_pose(self) -> conv.Pose2D:
        runtime = self._require_runtime()
        live = self._live_map_pose_dict(runtime.manager)
        if live is None:
            raise RuntimeError("current map pose unavailable")
        return conv.Pose2D(live["x"], live["y"], live["theta"])

    async def _start_navigate_route(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        """Follow a route's waypoints sequentially with the builtin navigator."""
        wait = bool(command.get("wait", False))
        loop = bool(command.get("loop", False))
        start_nearest = bool(
            command.get("start_nearest", command.get("nearest", False))
        )
        start_index = max(0, int(command.get("start_index", 0)))
        inline = command.get("waypoints")
        route_name, waypoints = self._resolve_route_waypoints(
            name=command.get("name"),
            waypoints=inline if isinstance(inline, (list, tuple)) else None,
        )
        if start_nearest:
            pose = await asyncio.to_thread(self._current_map_pose)
            start_index = self._nearest_route_index(waypoints, pose)
        elif start_index >= len(waypoints):
            raise ValueError(
                f"start_index {start_index} out of range (0..{len(waypoints) - 1})"
            )

        self._suspended = None
        await self._cancel_route()
        await self._cancel_simple_nav()

        cancel = asyncio.Event()
        self._route_cancel = cancel
        self._route_status = {
            "state": "active",
            "motion": "route",
            "name": route_name,
            "index": start_index,
            "total": len(waypoints),
            "location": waypoints[start_index].get("location"),
            "waypoints": waypoints,
            "loop": loop,
            "lap": 0,
            "error_msg": "",
        }

        async def _run() -> None:
            await self._run_route(route_name, waypoints, start_index, cancel, loop=loop)

        if wait:
            await _run()
            return dict(self._route_status)

        self._route_task = asyncio.create_task(_run(), name=f"nav-route:{route_name}")
        return {
            "status": "navigating",
            "motion": "route",
            "route": route_name,
            "index": start_index,
            "total": len(waypoints),
            "location": waypoints[start_index].get("location"),
            "target": dict(waypoints[start_index]),
            "loop": loop,
            "start_nearest": start_nearest,
        }

    async def _cancel_route(self, *, mark_canceled: bool = True) -> None:
        was_active = self._route_status.get("state") == "active"
        task = self._route_task
        had_running = task is not None and not task.done()
        if self._route_cancel is not None:
            self._route_cancel.set()
        if had_running:
            task.cancel()
            try:
                await task
            except asyncio.CancelledError:
                pass
        self._route_task = None
        self._route_cancel = None
        if was_active and mark_canceled:
            self._route_status = {
                **self._route_status,
                "state": "canceled",
                "motion": "route",
                "error_msg": "canceled",
            }
        elif was_active:
            self._route_status = {
                **self._route_status,
                "state": "idle",
                "motion": "route",
                "error_msg": "",
            }

    async def _run_route(
        self,
        route_name: str,
        waypoints: List[dict],
        start_index: int,
        cancel: asyncio.Event,
        *,
        loop: bool = False,
    ) -> None:
        runtime = self._require_runtime()
        mgr = runtime.manager
        terminal = {"succeeded", "failed", "canceled", "cancelled"}
        lap = 0
        idx = start_index
        try:
            while True:
                if cancel.is_set():
                    self._route_status = {
                        **self._route_status,
                        "state": "canceled",
                        "index": idx,
                        "lap": lap,
                        "loop": loop,
                        "error_msg": "canceled",
                    }
                    return
                wp = waypoints[idx]
                loc_name = str(wp.get("location") or "")
                self._active_goal_name = loc_name or None
                self._route_status = {
                    "state": "active",
                    "motion": "route",
                    "name": route_name,
                    "index": idx,
                    "total": len(waypoints),
                    "location": loc_name,
                    "waypoints": waypoints,
                    "loop": loop,
                    "lap": lap,
                    "error_msg": "",
                }
                await asyncio.to_thread(
                    mgr.navigate, float(wp["x"]), float(wp["y"]), float(wp["theta"])
                )
                # Wait for this leg to start (or finish immediately if already there).
                # Only treat a terminal status as "this leg" when the goal matches
                # this waypoint — otherwise a stale prior-leg success could skip ahead.
                started = False
                for _ in range(50):
                    if cancel.is_set():
                        await asyncio.to_thread(mgr.cancel)
                        self._route_status = {
                            **self._route_status,
                            "state": "canceled",
                            "error_msg": "canceled",
                        }
                        return
                    status = await asyncio.to_thread(mgr.nav_status)
                    state = str(status.get("state") or "").lower()
                    active = bool(status.get("active"))
                    if active or state == "active":
                        started = True
                        break
                    if (
                        (not active)
                        and state in terminal
                        and (
                            self._route_goal_matches(status, wp)
                            or self._route_pose_near_wp(status, wp)
                        )
                    ):
                        started = True
                        break
                    await asyncio.sleep(0.1)
                if not started:
                    self._route_status = {
                        **self._route_status,
                        "state": "failed",
                        "error_msg": (
                            f"waypoint {idx} ({loc_name!r}) did not start navigating"
                        ),
                    }
                    return
                # Wait until this leg leaves "active".
                while True:
                    if cancel.is_set():
                        await asyncio.to_thread(mgr.cancel)
                        self._route_status = {
                            **self._route_status,
                            "state": "canceled",
                            "error_msg": "canceled",
                        }
                        return
                    status = await asyncio.to_thread(mgr.nav_status)
                    state = str(status.get("state") or "").lower()
                    active = bool(status.get("active"))
                    if active or state == "active":
                        await asyncio.sleep(0.2)
                        continue
                    if state not in terminal:
                        await asyncio.sleep(0.2)
                        continue
                    if state == "succeeded" and not (
                        self._route_goal_matches(status, wp)
                        or self._route_pose_near_wp(status, wp)
                    ):
                        # Stale success from a previous goal — keep waiting.
                        await asyncio.sleep(0.2)
                        continue
                    if state in ("canceled", "cancelled"):
                        self._route_status = {
                            **self._route_status,
                            "state": "canceled",
                            "error_msg": status.get("error_msg") or "canceled",
                        }
                        return
                    if state == "failed":
                        self._route_status = {
                            **self._route_status,
                            "state": "failed",
                            "error_msg": status.get("error_msg")
                            or f"waypoint {idx} ({loc_name!r}) failed",
                        }
                        return
                    # succeeded — advance
                    break

                # Between legs the robot is still and nav is idle — verify the
                # map pose before departing. Periodic relocalize skips while a
                # goal is active, so a multi-stop route could otherwise ride a
                # drifted pose all the way to the next waypoint.
                will_continue = (idx + 1 < len(waypoints)) or loop
                if will_continue:
                    verify = await self._verify_pose_between_route_legs()
                    self._route_status = {
                        **self._route_status,
                        "pose_verify": dict(verify)
                        if isinstance(verify, Mapping)
                        else {"status": "unknown"},
                    }

                idx += 1
                if idx < len(waypoints):
                    continue
                if not loop:
                    self._active_goal_name = None
                    self._route_status = {
                        "state": "succeeded",
                        "motion": "route",
                        "name": route_name,
                        "index": len(waypoints) - 1,
                        "total": len(waypoints),
                        "location": waypoints[-1].get("location"),
                        "waypoints": waypoints,
                        "loop": False,
                        "lap": lap,
                        "error_msg": "",
                    }
                    return
                # Wrap for another lap.
                lap += 1
                idx = 0
        except asyncio.CancelledError:
            try:
                await asyncio.to_thread(mgr.cancel)
            except Exception:  # noqa: BLE001
                pass
            self._route_status = {
                **self._route_status,
                "state": "canceled",
                "error_msg": "canceled",
            }
            raise
        except Exception as exc:  # noqa: BLE001
            self._route_status = {
                **self._route_status,
                "state": "failed",
                "error_msg": str(exc),
            }
        finally:
            if self._route_cancel is cancel:
                self._route_cancel = None
            if self._route_task is asyncio.current_task():
                self._route_task = None

    async def _verify_pose_between_route_legs(self) -> Mapping:
        """Run one SLAM localization check while stopped between route waypoints.

        Uses ``check_localization`` with ``full_map_escalation=still_bad``:
        cheap local match first; full-map only when the published pose still
        looks wrong after that (avoids a multi-10s pause on every mediocre leg).
        """
        cfg = getattr(self, "_cfg", None)
        if cfg is None:
            return {"status": "skipped", "reason": "no_cfg"}
        builtin = getattr(cfg, "builtin", None)
        if builtin is not None and not bool(
            getattr(builtin, "route_verify_pose", True)
        ):
            return {"status": "skipped", "reason": "disabled"}
        slam_name = str(getattr(cfg, "slam_service", "") or "")
        if not slam_name:
            return {"status": "skipped", "reason": "no_slam_service"}
        try:
            from ..runtime import get_slam_service
        except Exception:  # noqa: BLE001
            return {"status": "skipped", "reason": "no_runtime"}
        svc = get_slam_service(slam_name)
        if svc is None or not hasattr(svc, "do_command"):
            return {"status": "skipped", "reason": "slam_unavailable"}
        check_cmd = {
            "command": "check_localization",
            "full_map_escalation": "still_bad",
        }
        try:
            result = await svc.do_command(check_cmd)
        except Exception as exc:  # noqa: BLE001
            return {
                "status": "error",
                "reason": str(exc).strip() or type(exc).__name__,
            }
        if not isinstance(result, Mapping):
            return {"status": "error", "reason": "bad_result"}
        status = str(result.get("status") or "")
        # Large jumps need a second agreeing match before apply.
        if status == "awaiting_confirm":
            await asyncio.sleep(0.4)
            try:
                result2 = await svc.do_command(check_cmd)
            except Exception:  # noqa: BLE001
                return dict(result)
            if isinstance(result2, Mapping):
                return dict(result2)
        return dict(result)

    @staticmethod
    def _route_goal_matches(status: Mapping, wp: Mapping, *, tol: float = 0.05) -> bool:
        """True when nav status goal matches this waypoint (coords and/or name)."""
        goal = status.get("goal") if isinstance(status.get("goal"), Mapping) else None
        if goal is None:
            return False
        loc = str(wp.get("location") or "")
        goal_name = str(goal.get("name") or "")
        if loc and goal_name and loc == goal_name:
            return True
        try:
            return (
                abs(float(goal["x"]) - float(wp["x"])) < tol
                and abs(float(goal["y"]) - float(wp["y"])) < tol
            )
        except (KeyError, TypeError, ValueError):
            return False

    @staticmethod
    def _route_pose_near_wp(status: Mapping, wp: Mapping, *, tol: float = 0.35) -> bool:
        pose = status.get("pose") if isinstance(status.get("pose"), Mapping) else None
        if pose is None:
            return False
        try:
            dx = float(pose["x"]) - float(wp["x"])
            dy = float(pose["y"]) - float(wp["y"])
            return dx * dx + dy * dy <= tol * tol
        except (KeyError, TypeError, ValueError):
            return False

    # -- simple closed-loop navigation (map frame) ---------------------------
    async def _start_simple_go(
        self,
        x: float,
        y: float,
        theta: float,
        command: Mapping[str, ValueTypes],
    ) -> Mapping[str, ValueTypes]:
        wait = command.get("wait", True)
        velocity = command.get("velocity_mps")
        velocity_mps = float(velocity) if velocity is not None else None
        target = {"x": x, "y": y, "theta": theta}
        # Callers own cancellation of any previous simple-nav run: _simple_go_to
        # must never call _cancel_simple_nav itself, or a background run would
        # cancel its own task handle and drop it (making it uncancelable later).
        await self._cancel_simple_nav()
        if wait:
            await self._simple_go_to(x, y, theta, velocity_mps=velocity_mps)
            return {
                "status": self._simple_nav_status.get("state", "idle"),
                "motion": "simple",
                "target": target,
            }
        self._simple_nav_task = asyncio.create_task(
            self._simple_go_to(x, y, theta, velocity_mps=velocity_mps)
        )
        return {"status": "navigating", "motion": "simple", "target": target}

    async def _cancel_simple_nav(self) -> None:
        was_active = self._simple_nav_status.get("state") == "active"
        task = self._simple_nav_task
        had_running_task = task is not None and not task.done()
        if self._simple_nav_cancel is not None:
            self._simple_nav_cancel.set()
        if had_running_task:
            task.cancel()
            try:
                await task
            except (asyncio.CancelledError, SimpleMotionCanceled):
                pass
        self._simple_nav_task = None
        self._simple_nav_cancel = None
        # Only zero the base when simple nav was actually running. Always
        # stopping here races builtin SetVelocity and can wipe angular mid-turn.
        if was_active or had_running_task:
            await self._stop_base()
        if was_active:
            self._simple_nav_status = {"state": "canceled", "motion": "simple"}

    async def _stop_base(self) -> None:
        base = self._base
        if base is None:
            return
        try:
            node = self._require_runtime().manager.node
        except Exception:  # noqa: BLE001 - stop must still zero the base
            node = None
        if node is not None:
            node.record_cmd_vel(0.0, 0.0, 0.0, source="simple_stop")
        await base.set_velocity(
            linear=Vector3(x=0, y=0, z=0),
            angular=Vector3(x=0, y=0, z=0),
        )

    async def _test_drive(
        self, command: Mapping[str, ValueTypes]
    ) -> Mapping[str, ValueTypes]:
        """Send one body-frame cmd through the drive path, then stop."""
        runtime = self._require_runtime()
        node = getattr(runtime.manager, "node", None)
        io = node._io if node is not None else None

        vx = float(
            command.get(
                "vx", command.get("body_vx_mps", command.get("ros_vx_mps", 0.0))
            )
        )
        vy = float(command.get("vy", command.get("body_vy_mps", 0.0)))
        vtheta = float(command.get("vtheta", command.get("body_vtheta_rad_s", 0.0)))
        if (
            "angular_z_deg_s" in command
            and "vtheta" not in command
            and "body_vtheta_rad_s" not in command
        ):
            vtheta = math.radians(float(command["angular_z_deg_s"]))
        duration_s = max(0.1, min(float(command.get("duration_s", 1.5)), 5.0))

        lx, ly, ang_deg_s = body_twist_to_viam_set_velocity(
            vx, vy, vtheta, runtime.slam_cfg.base_velocity_convention
        )
        if io is not None:
            await io.drive_base(vx, vy, vtheta)
            await asyncio.sleep(duration_s)
            await io.stop_base()
        else:
            # Drive the Viam base directly.
            base = self._base
            if base is None:
                raise RuntimeError("base unavailable")
            await base.set_velocity(
                linear=Vector3(x=lx, y=ly, z=0.0),
                angular=Vector3(x=0.0, y=0.0, z=ang_deg_s),
            )
            await asyncio.sleep(duration_s)
            await base.set_velocity(
                linear=Vector3(x=0.0, y=0.0, z=0.0),
                angular=Vector3(x=0.0, y=0.0, z=0.0),
            )
        return {
            "status": "ok",
            "sent": {
                "body_vx_mps": vx,
                "body_vy_mps": vy,
                "body_vtheta_rad_s": vtheta,
                "viam_linear_x_mm_s": lx,
                "viam_linear_y_mm_s": ly,
                "viam_angular_z_deg_s": ang_deg_s,
            },
            "duration_s": duration_s,
        }

    async def _plan_preview(self, command: Mapping, mgr) -> dict:
        """Run path planning and cache the result for execute_plan."""
        from ..geom import conversions as conv

        x = float(command["x"])
        y = float(command["y"])
        theta = float(command.get("theta", 0.0))
        planner_id = str(command.get("planner_id", "GridBased"))
        timeout_s = float(command.get("timeout_s", 20.0))
        max_points = int(command.get("max_points", 400))
        start = None
        if "start" in command and isinstance(command["start"], Mapping):
            s = command["start"]
            start = conv.Pose2D(
                float(s["x"]), float(s["y"]), float(s.get("theta", 0.0))
            )
        preview = await asyncio.to_thread(
            mgr.compute_path,
            x,
            y,
            theta,
            planner_id=planner_id,
            start=start,
            timeout_s=timeout_s,
            max_points=max_points,
        )
        self._last_preview_plan = preview
        return {
            "status": "planned" if preview.get("feasible") else "infeasible",
            **preview,
        }

    async def _simple_go_to(
        self,
        x: float,
        y: float,
        theta: float,
        *,
        velocity_mps: Optional[float] = None,
    ) -> None:
        cfg = self._require_cfg()
        runtime = self._require_runtime()
        base = self._base
        if base is None:
            raise RuntimeError("navigation base dependency missing")

        # Stop any in-flight builtin goal; the caller has already canceled any
        # previous simple-nav run (see _start_simple_go).
        await asyncio.to_thread(runtime.manager.cancel)

        from ..geom import conversions as conv

        goal = conv.Pose2D(x, y, theta)
        motion_cfg = config_from_nav(
            max_vel_x=cfg.max_linear_velocity,
            max_vel_theta=cfg.max_vel_theta,
            yaw_tolerance_rad=cfg.builtin.yaw_goal_tolerance,
            min_linear_mps=cfg.min_cmd_vel_x,
            min_angular_rad_s=cfg.min_cmd_vel_theta,
        )
        cancel_event = asyncio.Event()
        self._simple_nav_cancel = cancel_event
        self._simple_nav_status = {
            "state": "active",
            "motion": "simple",
            "target": {"x": x, "y": y, "theta": theta},
        }

        convention = runtime.slam_cfg.base_velocity_convention

        async def _set_velocity(vx: float, vy: float, vtheta: float) -> None:
            node = getattr(runtime.manager, "node", None)
            if node is not None:
                node.record_cmd_vel(vx, vy, vtheta, source="simple")
            lx, ly, ang_deg_s = body_twist_to_viam_set_velocity(
                vx, vy, vtheta, convention
            )
            await base.set_velocity(
                linear=Vector3(x=lx, y=ly, z=0),
                angular=Vector3(x=0, y=0, z=ang_deg_s),
            )

        def _on_progress(progress: dict) -> None:
            prev = self._simple_nav_status.get("obstacle")
            self._simple_nav_status.update(progress)
            new_state = progress.get("obstacle")
            if new_state != prev and new_state in ("avoid", "slow", "hold", "no_scan"):
                clearance = progress.get("forward_clearance_m")
                if new_state == "no_scan":
                    LOGGER.warning(
                        "simple nav: no fresh lidar scan; suppressing forward motion"
                    )
                else:
                    LOGGER.info(
                        f"simple nav: obstacle {new_state} "
                        f"(forward clearance {clearance} m)"
                    )

        obstacle_cfg = ObstacleConfig(
            enabled=cfg.simple_avoid_obstacles,
            stop_distance_m=cfg.simple_stop_distance,
            slow_distance_m=cfg.simple_slow_distance,
            footprint_half_width_m=cfg.hard_clearance_radius_m() + 0.12,
            max_age_s=cfg.simple_scan_max_age,
        )

        def _get_scan():
            return runtime.manager.get_base_scan(obstacle_cfg.max_age_s)

        try:
            await drive_to_pose(
                goal=goal,
                get_pose=runtime.manager.get_pose_in_map,
                set_velocity=_set_velocity,
                stop=self._stop_base,
                cfg=motion_cfg,
                linear_mps=velocity_mps,
                cancel_event=cancel_event,
                on_progress=_on_progress,
                get_scan=_get_scan,
                obstacle=obstacle_cfg,
            )
            self._simple_nav_status = {
                "state": "succeeded",
                "motion": "simple",
                "target": {"x": x, "y": y, "theta": theta},
            }
        except SimpleMotionCanceled:
            self._simple_nav_status = {
                "state": "canceled",
                "motion": "simple",
                "target": {"x": x, "y": y, "theta": theta},
            }
            raise
        except SimpleMotionError as exc:
            self._simple_nav_status = {
                "state": "failed",
                "motion": "simple",
                "error": str(exc),
                "target": {"x": x, "y": y, "theta": theta},
            }
            raise RuntimeError(str(exc)) from exc
        finally:
            # Only clear state that still belongs to this run: a newer goal may
            # already have installed its own cancel event / task handle.
            if self._simple_nav_cancel is cancel_event:
                self._simple_nav_cancel = None
            if self._simple_nav_task is asyncio.current_task():
                self._simple_nav_task = None
