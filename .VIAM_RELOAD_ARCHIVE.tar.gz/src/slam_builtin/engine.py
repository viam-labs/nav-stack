"""Background occupancy SLAM loop: predict → match → update."""

from __future__ import annotations

import functools
import math
import shutil
import threading
import time
from collections import deque
from pathlib import Path
from time import perf_counter
from typing import Optional

import numpy as np

from ..config import (
    BASE_VELOCITY_Y_FORWARD,
    IMU_ODOM_ACCEL_ONLY,
    MODE_LOCALIZING,
    MODE_MAPPING,
    SlamConfig,
)
from ..geom import conversions as conv
from ..nav.localize.global_localize import OccupancyMap
from ..nav.localize.pose_jump_gate import PoseJumpGate
from ..nav.stores.maps import MapStore
from . import graph_store, loop_closure, map_health, persistence, repair, scan_match
from . import occupancy as occ
from . import pose_graph as pg
from .io_sensors import BuiltinSensors
from .lidar_odom import LidarOdometry
from .types import LogOddsGrid

# A scan is drawn only when it lands on walls already in the map.
_MAP_INSERT_MIN_SCORE = 0.5
# With lidars at more than one height the best-agreeing height decides (see
# ``scan_match.height_votes``). The bar is higher than for one merged scan:
# the best of several scores is easier to reach at a wrong pose. On a robot
# with lidars at 0.21 m and 1.2 m this refused poses 15 cm or 5 degrees off
# about as often as the merged scan did, and passed the right pose 94% of
# the time against 89%.
_HEIGHT_VOTE_MIN_SCORE = 0.65
# A vote this high needs no second look before painting. On that robot's
# keyframes only poses within about 5 cm reached it; 10 cm off, the median
# vote was 0.64.
_HEIGHT_VOTE_CONFIDENT = 0.85
# A polish is refused when the fit is this much better at the edge of its
# search than inside it. From a pose 18 cm off, the edge scored 0.22 higher;
# along a corridor, where position barely changes the fit, 0.02.
_POLISH_EDGE_GAIN = 0.05
# In-place turns slower than the hard smear skip still write a rotated wing
# if they are painted live. Hold them and draw after the robot stops.
_SPIN_HOLD_YAW_RATE = math.radians(15.0)
_SPIN_HOLD_LINEAR = 0.20
_SPIN_HOLD_MAX = 80


def rewind_spin_poses(odom_poses: list, end: conv.Pose2D) -> list:
    """Place each odom pose so the last one is ``end``.

    Yaw changes and body-frame steps between the odom poses are kept. The
    end heading is the one that matched the map, so a slip during the spin
    does not rotate the scans.
    """
    if not odom_poses:
        return []
    out: list = [None] * len(odom_poses)
    out[-1] = conv.Pose2D(end.x, end.y, end.theta)
    for i in range(len(odom_poses) - 2, -1, -1):
        a = odom_poses[i]
        b = odom_poses[i + 1]
        dth = conv.normalize_angle(b.theta - a.theta)
        c, s = math.cos(a.theta), math.sin(a.theta)
        dx, dy = b.x - a.x, b.y - a.y
        body_x = c * dx + s * dy
        body_y = -s * dx + c * dy
        th = conv.normalize_angle(out[i + 1].theta - dth)
        c2, s2 = math.cos(th), math.sin(th)
        out[i] = conv.Pose2D(
            out[i + 1].x - (c2 * body_x - s2 * body_y),
            out[i + 1].y - (s2 * body_x + c2 * body_y),
            th,
        )
    return out


class BuiltinSlamEngine:
    """In-process 2D occupancy mapping + localization."""

    def __init__(
        self,
        cfg: SlamConfig,
        sensors: BuiltinSensors,
        map_store: MapStore,
        *,
        logger=None,
        rate_hz: float = 10.0,
        match_period_s: float = 0.3,
    ):
        self._cfg = cfg
        self._sensors = sensors
        self._map_store = map_store
        self._logger = logger
        self._period = 1.0 / max(rate_hz, 1.0)
        # Scan matching + map inserts are CPU-heavy; running them at the full
        # predict rate starved the module event loop (nav "Viam IO timed out").
        self._match_period_s = max(0.0, float(match_period_s))

        self._lock = threading.RLock()
        self._grid: LogOddsGrid = occ.empty_grid(resolution=cfg.map.resolution)
        # Height slices painted while mapping. The published ``_grid`` is their
        # union, so a lidar beam cannot clear a camera hit at another height.
        self._height_bands: dict = {}
        # Scans captured during an in-place spin, painted once it stops.
        self._spin_hold: list = []
        self._pose = conv.Pose2D(0.0, 0.0, 0.0)
        self._last_odom_pose: Optional[conv.Pose2D] = None
        self._last_odom_pose_at: Optional[float] = None
        self._last_odom_time: Optional[float] = None
        self._last_odom_heading: Optional[float] = None
        self._mode = cfg.mode
        self._generation = 0
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._last_match_score = float("nan")
        self._last_prior_score = float("nan")
        self._last_match_rival_score = float("nan")
        self._last_scan_age_s = float("nan")
        self._last_scan_obj: Optional[conv.LaserScan2D] = None
        self._last_tick_pose: Optional[conv.Pose2D] = None
        self._last_tick_at: Optional[float] = None
        # Odometry-only motion chain (never corrected) and its recent samples.
        # Relative motion between two times is frame-independent, so a scan
        # can be matched at the pose it was taken from even across corrections.
        self._odom_chain = conv.Pose2D(0.0, 0.0, 0.0)
        self._odom_hist: deque = deque(maxlen=64)
        self._last_scan_latency_s = float("nan")
        self._last_yaw_rate = 0.0
        self._last_lin_rate = 0.0
        self._insert_skips_unmatched = 0
        self._insert_skips_turning = 0
        # Operator-facing paint status (see diagnostics ``paint``).
        self._paint_state = "idle"
        self._paint_last_fit: Optional[str] = None
        self._paint_last_at = 0.0
        # What the last fit check scored, and against which pass mark.
        self._paint_fit_detail: Optional[dict] = None
        # Which scan the last pose match was made with (see ``_match_pose``).
        self._match_detail: Optional[dict] = None
        # Last time we ran a full-circle heading search to unstick paint.
        self._last_heading_recover_at = 0.0
        self._heading_recovers = 0
        # Times a refused scan was painted after a few-centimetre polish.
        self._pose_polishes = 0
        self._ticks = 0
        self._updates = 0
        # Match outcomes: applied = pose corrected; held = ran match but kept
        # odom (prior already good / apply refused on purpose); failed = real miss.
        self._match_accepts = 0  # == applied (legacy name)
        self._match_held = 0
        self._match_failed = 0
        # Corrections applied while a goal was active.
        self._drive_applies = 0
        self._yaw_only_applies = 0
        # Heading bookkeeping: sensor steps the body cannot have turned, and
        # the signed yaw the scan has pulled the pose by since the last seed.
        self._heading_snaps = 0
        self._yaw_corr_sum = 0.0
        self._yaw_corr_count = 0
        self._yaw_corr_since: Optional[float] = None
        self._last_match_at = 0.0
        # Mapping inserts only after movement (or timeout).
        self._last_insert_pose: Optional[conv.Pose2D] = None
        self._last_insert_at = 0.0
        # Anti-oscillation: require two agreeing frames before applying a jump.
        self._pending_match: Optional[conv.Pose2D] = None
        self._pending_count = 0
        # Cached ROS-style grid for scan matching (invalidated on map edits).
        self._occ_cache: Optional[OccupancyMap] = None
        self._occ_cache_epoch = -1
        self._match_epoch = 0
        self._occ_cache_known = 0.0
        # Dilated wall mask for ``_occ_cache``; built once per epoch instead
        # of once per scan_match call (each was a full-grid dilation).
        self._occ_cache_lookup: Optional[np.ndarray] = None
        # Localizing mode: do not odom-track from (0,0) until a full-map seed
        # succeeds. Without this the robot "assumes start" until the async
        # startup global_localize task eventually fires.
        self._seed_localize_pending = cfg.mode == MODE_LOCALIZING
        self._last_seed_attempt_at = 0.0
        self._seed_min_score = 0.40
        self._map_dir: Optional[Path] = None
        self._pose_restored_from_disk = False
        self._last_pose_save_at = 0.0
        self._graph = pg.PoseGraph(
            max_nodes=int(cfg.builtin_mapping_keyframe_max),
            node_spacing_m=float(cfg.builtin_loop_node_spacing_m),
            node_spacing_deg=float(cfg.builtin_loop_node_spacing_deg),
            scans_per_node=int(cfg.builtin_loop_scans_per_node),
        )
        # Map loaded when mapping resumed on it; renders start from it.
        self._graph_base: Optional[LogOddsGrid] = None
        # Grid as this mapping session found it (health scores against it).
        self._session_baseline: Optional[LogOddsGrid] = None
        # Keyframes reloaded from the saved map: nodes [0, frozen) are fixed
        # reference geometry for live loop closure / revisit.
        self._graph_frozen = 0
        # Manual erase/paint edits, replayed onto every re-rendered grid.
        self._grid_edits: list = []
        # Edits already written to keyframes.npz by a non-mapping save.
        self._grid_edits_saved = 0
        # One optimize + re-render at a time (worker, revisit, DoCommand).
        self._graph_job = threading.Lock()
        # Background map repair (save_map / repair_map DoCommand).
        self._repair_lock = threading.Lock()
        self._repair_thread: Optional[threading.Thread] = None
        self._repair_map_dir: Optional[Path] = None
        self._repair_cancel = threading.Event()
        self._repair_status: dict = {"state": "idle"}
        # Live-pose correction of the last applied repair (undo_repair).
        self._last_repair_tail: Optional[conv.Pose2D] = None
        self._graph_revision = 0
        # Bumped whenever the pose jumps frame (correction / set_pose) so an
        # in-flight match computed in the old frame is not applied.
        self._pose_epoch = 0
        # Person discs from the vision paint gate. Endpoints inside them are
        # dropped only while the camera frame is this fresh.
        self._paint_discs: list = []
        self._paint_discs_at = 0.0
        self._loop_params = loop_closure.LoopClosureParams(
            min_travel_gap_m=float(cfg.builtin_loop_min_travel_m),
            search_radius_m=float(cfg.builtin_loop_search_radius_m),
            window_m=float(cfg.builtin_loop_search_window_m),
            window_deg=float(cfg.builtin_loop_search_window_deg),
            max_yaw_long_gap_deg=float(cfg.builtin_loop_max_yaw_long_gap_deg),
            min_score=float(cfg.builtin_loop_min_score),
        )
        self._loop_pending_max_s = float(cfg.builtin_loop_pending_max_s)
        self._loop_pending_max_tries = max(2, int(cfg.builtin_loop_pending_max_tries))
        self._loop_event = threading.Event()
        self._loop_thread: Optional[threading.Thread] = None
        self._loop_last_attempt_at = 0.0
        # (revision, node, corr, edge, started_at, tries) or None.
        self._loop_pending: Optional[tuple] = None
        self._loop_full_logged = False
        self._loop_stats: dict = {
            "attempts": 0,
            "closures": 0,
            "optimizations": 0,
            "rejected_inconsistent": 0,
            "pending_expired": 0,
            "reasons": {},
            "last": None,
            "last_optimize_ms": None,
            "last_render_ms": None,
            # Mapping-revisit corrections (apply_map_pose_correction).
            "revisit": {
                "attempts": 0,
                "corrections": 0,
                "rejected": 0,
                "reasons": {},
                "last": None,
            },
        }
        # Live occupancy health (ghost walls / angle tear). Refreshed while
        # mapping so loop + revisit can react before the floor is doubled.
        self._map_health: dict = {"status": "cold"}
        self._map_health_at = 0.0
        self._map_health_generation = -1
        self._map_health_boosts = 0
        self._map_health_last_status = "cold"
        # Map a mapping session resumed on: scored once, then excluded from
        # live health so inherited ghosts don't read as new tearing.
        self._map_health_base_src: Optional[LogOddsGrid] = None
        self._map_health_base_cells: Optional[np.ndarray] = None
        self._map_health_base: Optional[dict] = None
        # Fresh mapping has no loaded-map baseline; snapshot the grid whenever
        # health is ok so re-driving known walls is not scored as tearing.
        self._map_health_ok_cells: Optional[np.ndarray] = None
        self._map_health_ok_origin: tuple[float, float] = (0.0, 0.0)
        # After clear_region the operator intends to remap the hole: keep full
        # paint even if residual map_health still scores the baseline torn.
        self._operator_trusted_paint = False
        # Mid-session hotspot auto-heal (map_health_auto_heal / _auto_clear).
        self._hotspot_track: Optional[dict] = None
        self._hotspot_last_clear_at = 0.0
        self._hotspot_heal_busy = False
        self._hotspot_heal: dict = {
            "clears": 0,
            "last": None,
            "tracked": None,
            "skips": {},
        }
        self._keyframe_hook = None
        # Optional: SlamService wires this into LocalizationStateTracker so a
        # tick that trusts the published pose clears / avoids ``lost``.
        self._match_outcome_hook = None
        self._anchor_motion_hook = None
        self._pose_listeners: list = []
        self._last_odom_twist = (0.0, 0.0, 0.0)
        # Forward speed (m/s) guessed from IMU accel when wheel velocity is absent.
        self._imu_forward_m_s = 0.0
        self._imu_ax_bias = None
        self._imu_yaw_bias = None
        # Lidar odometry (wheel-less carts): body velocity (forward, left) m/s
        # learned from successive scan matches.
        self._lo = LidarOdometry()
        self._lo_vel = (0.0, 0.0)
        self._lo_last_at: Optional[float] = None
        self._lo_reset_pending = False
        self._lo_map_updates: Optional[int] = None
        self._lo_fails = 0
        self._lo_accepts = 0
        self._lo_rejects = 0
        self._lo_resets = 0
        self._lo_inserts_held = 0
        self._lo_last_inlier = float("nan")
        self._lo_last_rms = float("nan")
        self._lo_prev_theta: Optional[float] = None
        self._lo_turn_rate = 0.0
        self._lo_match_ms = float("nan")
        # Signed yaw totals (rad) for comparing the gyro with the lidar on a spin.
        self._yaw_check_gyro = 0.0
        self._yaw_check_lidar = 0.0
        self._last_loop_rebuild_at = 0.0
        self._pose_jump_gate = PoseJumpGate(
            confirm_count=int(cfg.localize_jump_confirm_count),
            agree_m=float(cfg.localize_jump_agree_m),
            agree_deg=float(cfg.localize_jump_agree_deg),
            large_m=float(cfg.localize_jump_large_m),
            large_deg=float(cfg.localize_jump_large_deg),
        )

    def _log(self, msg: str) -> None:
        if self._logger is not None:
            try:
                self._logger(msg)
            except Exception:  # noqa: BLE001
                pass

    # -- lifecycle -----------------------------------------------------------
    def start(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(
            target=self._loop,
            name="builtin-slam",
            daemon=True,
        )
        self._thread.start()
        self._loop_thread = threading.Thread(
            target=self._loop_closure_worker,
            name="builtin-slam-loop",
            daemon=True,
        )
        self._loop_thread.start()
        self._log(f"builtin SLAM engine started ({self._mode})")

    def stop(self) -> None:
        self._persist_pose(force=True)
        self._running = False
        self._repair_cancel.set()
        self._loop_event.set()
        for thr in (self._thread, self._loop_thread):
            if thr is not None and thr.is_alive():
                thr.join(timeout=2.0)
        self._thread = None
        self._loop_thread = None

    def configure_mode(self, mode: str, map_dir: Optional[Path] = None) -> None:
        self._finish_or_cancel_repair(map_dir)
        with self._lock:
            self._mode = mode
            self._pose_restored_from_disk = False
            self._operator_trusted_paint = False
            self._hotspot_track = None
            self._hotspot_last_clear_at = 0.0
            self._hotspot_heal = {
                "clears": 0,
                "last": None,
                "tracked": None,
                "skips": {},
            }
            self._map_health_ok_cells = None
            self._map_health_ok_origin = (0.0, 0.0)
            loaded = None
            if map_dir is not None:
                self._map_dir = Path(map_dir)
                loaded = persistence.load_log_odds(map_dir)
                if loaded is not None:
                    self._grid = loaded
                    self._height_bands = {}
                    self._invalidate_occ_cache()
                    self._generation += 1
                    self._log(f"loaded occupancy map from {map_dir}")
                elif mode == MODE_LOCALIZING:
                    raise RuntimeError(
                        f"cannot localize: no map.yaml/map.pgm under {map_dir}"
                    )
                elif mode == MODE_MAPPING:
                    # Fresh mapping session.
                    self._grid = occ.empty_grid(resolution=self._cfg.map.resolution)
                    self._height_bands = {}
                    self._pose = conv.Pose2D(0.0, 0.0, 0.0)
                    self._last_odom_pose = None
                    self._last_odom_heading = None
                    self._invalidate_occ_cache()
                    self._generation += 1
            self._reset_graph_locked()
            if mode == MODE_MAPPING and loaded is not None and map_dir is not None:
                self._resume_keyframes_locked(Path(map_dir))
            self._reset_lidar_odom_locked()
            if mode == MODE_LOCALIZING:
                self._seed_localize_pending = True
                self._last_seed_attempt_at = 0.0
                self._last_odom_pose = None
                self._last_odom_heading = None
                self._last_odom_time = None
                self._pending_match = None
                self._pending_count = 0
                restored = self._try_restore_last_pose_locked()
                if restored is not None:
                    self._pose = restored
                    self._seed_localize_pending = False
                    self._pose_restored_from_disk = True
                    self._log(
                        "restored last pose from disk "
                        f"({restored.x:.2f}, {restored.y:.2f}, "
                        f"{math.degrees(restored.theta):.1f} deg)"
                    )
                else:
                    self._log(
                        "builtin SLAM awaiting full-map seed localize "
                        "(will not assume start pose)"
                    )
            else:
                self._seed_localize_pending = False
                # Mapping with an existing map: resume near last pose if any.
                if map_dir is not None and loaded is not None:
                    restored = self._try_restore_last_pose_locked()
                    if restored is not None:
                        self._pose = restored
                        self._pose_restored_from_disk = True
                        self._last_odom_pose = None
                        self._last_odom_heading = None
                        self._last_odom_time = None
                        self._log(
                            "restored last pose from disk for mapping "
                            f"({restored.x:.2f}, {restored.y:.2f}, "
                            f"{math.degrees(restored.theta):.1f} deg)"
                        )
        # Notify outside the lock if we restored (listeners may call back).
        if self._pose_restored_from_disk:
            self._notify_pose_listeners(self.get_pose())

    def _try_restore_last_pose_locked(self) -> Optional[conv.Pose2D]:
        cfg = self._cfg
        if not bool(getattr(cfg, "persist_pose", True)):
            return None
        map_dir = self._map_dir
        if map_dir is None:
            return None
        max_age = float(getattr(cfg, "persist_pose_max_age_s", 0.0) or 0.0)
        return persistence.load_last_pose(map_dir, max_age_s=max_age)

    def _persist_pose(self, *, force: bool = False) -> None:
        cfg = self._cfg
        if not bool(getattr(cfg, "persist_pose", True)):
            return
        map_dir = self._map_dir
        if map_dir is None:
            return
        # Do not persist an unseeded origin placeholder in localizing mode.
        if self._mode == MODE_LOCALIZING and self._seed_localize_pending:
            return
        interval = float(getattr(cfg, "persist_pose_interval_s", 1.0) or 0.0)
        now = time.monotonic()
        if not force and interval > 0.0 and (now - self._last_pose_save_at) < interval:
            return
        if not force and interval <= 0.0:
            return
        with self._lock:
            pose = self._pose
        try:
            persistence.save_last_pose(map_dir, pose)
            self._last_pose_save_at = now
        except Exception as exc:  # noqa: BLE001
            self._log(f"persist last pose failed: {exc}")

    def pose_restored_from_disk(self) -> bool:
        return bool(self._pose_restored_from_disk)

    def reset_map(self) -> None:
        self._repair_cancel.set()
        with self._lock:
            self._grid = occ.empty_grid(resolution=self._cfg.map.resolution)
            self._height_bands = {}
            self._spin_hold = []
            self._pose = conv.Pose2D(0.0, 0.0, 0.0)
            self._last_odom_pose = None
            self._last_odom_heading = None
            self._last_insert_pose = None
            self._reset_graph_locked()
            self._pose_epoch += 1
            self._invalidate_occ_cache()
            self._generation += 1
            self._pose_restored_from_disk = False
            self._operator_trusted_paint = False
            self._reset_lidar_odom_locked()
            map_dir = self._map_dir
        if map_dir is not None:
            path = persistence.last_pose_path(map_dir)
            try:
                if path.is_file():
                    path.unlink()
            except OSError:
                pass

    def clear_obstacles(self, x_m: float, y_m: float, radius_m: float) -> dict:
        """Erase occupied cells in a disk (map frame meters). Builtin only."""
        with self._lock:
            edit = ("clear", float(x_m), float(y_m), float(radius_m))
            cleared = self._edit_live_grid_locked(edit)
            if cleared:
                self._grid_edits.append(edit)
                self._invalidate_occ_cache()
                self._generation += 1
            return {
                "cleared_cells": int(cleared),
                "x": float(x_m),
                "y": float(y_m),
                "radius_m": float(radius_m),
                "generation": int(self._generation),
                "resolution": float(self._grid.resolution),
            }

    def clear_region(
        self,
        x_min: float,
        y_min: float,
        x_max: float,
        y_max: float,
    ) -> dict:
        """Blank an AABB in occupancy and drop keyframes whose pose lies inside.

        Remap a torn hallway without clearing the whole map: occupancy is
        painted free, in-box pose-graph nodes (and their edges) are removed,
        and a ``clear_box`` edit is recorded so later re-renders keep the hole.
        When keyframes remain, the graph is re-rendered so paint from the
        dropped nodes disappears everywhere (not only inside the box), then
        ``clear_box`` is replayed so kept nodes cannot refill the AABB.
        Session baseline / map-health cache are refreshed so trust can recover.
        """
        xa, xb = sorted((float(x_min), float(x_max)))
        ya, yb = sorted((float(y_min), float(y_max)))
        if xb <= xa or yb <= ya:
            raise ValueError("clear_region needs a non-empty box")
        with self._lock:
            # Re-renders erase scans up to this seq; later ones remap the hole.
            edit = ("clear_box", xa, ya, xb, yb, int(self._graph.last_seq))
            cleared = self._edit_live_grid_locked(edit)
            self._grid_edits.append(edit)

            frozen = int(self._graph_frozen)

            def _in_box(_i: int, node: pg.GraphNode) -> bool:
                return xa <= float(node.pose.x) <= xb and ya <= float(node.pose.y) <= yb

            kept_frozen = sum(
                1
                for i, node in enumerate(self._graph.nodes)
                if i < frozen and not _in_box(i, node)
            )
            removed, edges_removed = self._graph.remove_nodes(_in_box)
            self._graph_frozen = kept_frozen
            if removed:
                self._graph_revision += 1
                self._loop_pending = None

            self._invalidate_occ_cache()
            self._generation += 1
            n_removed = int(len(removed))
            remaining = int(len(self._graph))
            out = {
                "cleared_cells": int(cleared),
                "removed_nodes": n_removed,
                "removed_edges": int(edges_removed),
                "remaining_nodes": remaining,
                "frozen": int(self._graph_frozen),
                "x_min": xa,
                "y_min": ya,
                "x_max": xb,
                "y_max": yb,
                "generation": int(self._generation),
                "resolution": float(self._grid.resolution),
                "rebuilt": False,
            }

        # Re-render outside the lock when nodes were dropped: their scans still
        # paint the live grid (including outside the AABB) until a rebuild.
        # clear_box is replayed so kept nodes cannot refill the hole.
        if n_removed > 0 and remaining > 0:
            try:
                rendered = self._optimize_and_render(None)
                out["rebuilt"] = rendered.get("status") == "rebuilt"
            except Exception as exc:  # noqa: BLE001
                self._log(f"clear_region re-render failed: {exc}")

        with self._lock:
            # Post-clear (and post-render) grid is the new session truth.
            self._session_baseline = occ.copy_grid(self._grid)
            self._map_health_base_src = None
            self._map_health_base_cells = None
            self._map_health_base = None
            self._map_health_at = 0.0
            # Cleared hole is new truth — drop the ok-checkpoint so health
            # re-learns from the remapped walls.
            self._map_health_ok_cells = None
            self._map_health_ok_origin = (0.0, 0.0)
            # Free cells in the hole need full paint to grow walls again;
            # residual ghosts elsewhere must not trap us in extend_only.
            self._operator_trusted_paint = True
            # Manual or auto clear: drop the streak so we do not clear again
            # until a new hotspot persists.
            self._hotspot_track = None
            out["generation"] = int(self._generation)
            out["remaining_nodes"] = int(len(self._graph))
            out["frozen"] = int(self._graph_frozen)
            out["operator_trusted_paint"] = True
            self._log(
                "clear_region: full paint enabled for remap "
                f"(box=[{xa:.1f},{ya:.1f}]–[{xb:.1f},{yb:.1f}], "
                f"removed={n_removed} nodes)"
            )
        return out

    def add_obstacles(self, x_m: float, y_m: float, radius_m: float) -> dict:
        """Paint occupied cells in a disk (map frame meters). Builtin only."""
        with self._lock:
            edit = ("mark", float(x_m), float(y_m), float(radius_m))
            marked = self._edit_live_grid_locked(edit)
            if marked:
                self._grid_edits.append(edit)
                self._invalidate_occ_cache()
                self._generation += 1
            return {
                "marked_cells": int(marked),
                "x": float(x_m),
                "y": float(y_m),
                "radius_m": float(radius_m),
                "generation": int(self._generation),
                "resolution": float(self._grid.resolution),
            }

    def set_keyframe_hook(self, hook) -> None:
        self._keyframe_hook = hook

    def add_pose_listener(self, listener) -> None:
        """``listener(pose: Pose2D)`` after set_pose / apply_map_pose_correction."""
        self._pose_listeners.append(listener)

    def _notify_pose_listeners(self, pose: conv.Pose2D) -> None:
        for listener in list(self._pose_listeners):
            try:
                listener(pose)
            except Exception:  # noqa: BLE001
                pass

    def set_pose(self, pose: conv.Pose2D) -> None:
        with self._lock:
            if self._mode == MODE_MAPPING:
                self._graph.rebase(pg.world_correction(self._pose, pose))
            self._pose = pose
            self._pose_epoch += 1
            self._pending_match = None
            self._pending_count = 0
            self._reset_yaw_ledger()
            # External relocalize / startup global_localize counts as seeded.
            self._seed_localize_pending = False
            self._last_odom_pose = None
            self._last_odom_heading = None
            self._last_odom_time = None
            self._imu_forward_m_s = 0.0
            self._imu_ax_bias = None
            self._imu_yaw_bias = None
            self._reset_lidar_odom_locked()
        self._notify_pose_listeners(pose)
        self._persist_pose(force=True)

    def _reset_lidar_odom_locked(self) -> None:
        """Drop the local scan map and velocity; the loop thread rebuilds it."""
        self._lo_vel = (0.0, 0.0)
        self._lo_last_at = None
        self._lo_fails = 0
        self._lo_reset_pending = True
        self._lo_map_updates = None
        self._lo_prev_theta = None
        self._lo_turn_rate = 0.0

    def _set_corrected_pose_locked(self, pose: conv.Pose2D) -> None:
        self._pose = pose
        self._pose_epoch += 1
        self._pending_match = None
        self._pending_count = 0
        self._reset_yaw_ledger()
        self._seed_localize_pending = False
        self._last_odom_pose = None
        self._last_odom_heading = None
        self._last_odom_time = None
        self._last_insert_pose = pose
        self._last_tick_pose = pose
        # Keyscans sit at the pre-correction poses; keep velocity, rebuild map.
        self._lo_reset_pending = True
        self._lo_last_at = None
        self._lo_map_updates = None

    def _reset_graph_locked(self) -> None:
        self._graph.clear()
        self._graph_frozen = 0
        self._grid_edits = []
        self._grid_edits_saved = 0
        self._loop_pending = None
        self._loop_full_logged = False
        self._graph_revision += 1
        observed = bool(np.any(np.abs(self._grid.log_odds) > 0.05))
        self._graph_base = (
            occ.copy_grid(self._grid)
            if self._mode == MODE_MAPPING and observed
            else None
        )
        self._session_baseline = self._graph_base

    def _resume_keyframes_locked(self, map_dir: Path) -> None:
        """Reload saved keyframes as fixed graph nodes (mapping resume)."""
        if not bool(getattr(self._cfg, "builtin_save_keyframes", True)):
            return
        path = graph_store.keyframes_path(map_dir)
        if not path.is_file():
            return
        saved = graph_store.load_graph(
            map_dir,
            image_sha1=graph_store.file_sha1(Path(map_dir) / "map.pgm"),
            resolution=float(self._grid.resolution),
        )
        if saved is None:
            self._log(
                f"{path.name} does not match map.pgm; resuming on the flat map "
                "(saved geometry cannot be re-solved this session)"
            )
            return
        self._graph.load(
            saved.nodes,
            saved.edges,
            saved.last_seq,
            session_gap_m=self._loop_params.min_travel_gap_m,
        )
        self._graph_frozen = len(saved.nodes)
        # Render base only (map under the oldest keyframes, often None).
        # _session_baseline stays the loaded image: health and trust score
        # the map this session resumed on.
        self._graph_base = saved.base
        # Re-apply clears/marks onto the loaded PGM.
        edits = []
        for edit in saved.edits:
            if edit[0] == "clear_box" and len(edit) == 5:
                # Saved before clears carried a seq, when band paint could
                # refill the hole with the old walls: wipe it, and erase every
                # loaded keyframe there on re-render.
                occ.clear_rect(self._grid, *edit[1:5])
                edit = (*edit, int(saved.last_seq))
            elif edit[0] == "clear_box":
                # Walls in the hole were remapped after the clear. Only its
                # free cells go back to unjudged for scan matching.
                occ.clear_rect(self._grid, *edit[1:5], keep_walls=True)
            else:
                self._apply_grid_edit(self._grid, edit)
            edits.append(edit)
        self._grid_edits = edits
        self._grid_edits_saved = len(self._grid_edits)
        if self._grid_edits:
            self._invalidate_occ_cache()
            self._generation += 1
        self._graph_revision += 1
        self._log(
            f"resumed {len(saved.nodes)} keyframes / {len(saved.edges)} edges "
            f"from {path.name}"
        )

    @staticmethod
    def _apply_grid_edit(grid: LogOddsGrid, edit: tuple) -> int:
        kind = edit[0]
        if kind == "clear":
            return occ.clear_disk(grid, edit[1], edit[2], edit[3])
        if kind == "clear_box":
            return occ.clear_rect(grid, edit[1], edit[2], edit[3], edit[4])
        return occ.mark_disk(grid, edit[1], edit[2], edit[3])

    @staticmethod
    def _seq_scoped(edit: tuple) -> bool:
        return edit[0] == "clear_box" and len(edit) > 5

    @classmethod
    def _render_clears(cls, edits: list) -> list:
        """Box clears for ``render_grid``: drawn after the scans they erase."""
        return [
            (int(e[5]), functools.partial(cls._apply_grid_edit, edit=e))
            for e in edits
            if cls._seq_scoped(e)
        ]

    def _replay_after_render_locked(self, grid: LogOddsGrid, rendered: int) -> None:
        """Edits the render did not place: disks, marks, and any made since."""
        for k, edit in enumerate(self._grid_edits):
            if k >= rendered or not self._seq_scoped(edit):
                self._apply_grid_edit(grid, edit)

    def _edit_live_grid_locked(self, edit: tuple) -> int:
        """Apply ``edit`` to the published grid and to every height band.

        Band painting rebuilds ``_grid`` from the bands, so an edit made to
        ``_grid`` alone came back with the next scan.
        """
        updated = occ.copy_grid(self._grid)
        changed = self._apply_grid_edit(updated, edit)
        if changed:
            self._grid = updated
            bands = {}
            for band, grid in self._height_bands.items():
                copy = occ.copy_grid(grid)
                self._apply_grid_edit(copy, edit)
                bands[band] = copy
            self._height_bands = bands
        return changed

    # Corrections up to this yaw are spread along the loop by the pose graph;
    # bigger ones (yaw flip, far relocalize) shift the trailing path rigidly.
    _GRAPH_CORRECTION_MAX_DEG = 30.0
    # Revisit edge uncertainty at a perfect match; it grows with a weaker
    # score (``_revisit_edge_sigmas``). The old fixed 5 cm / 1 deg made every
    # revisit a near-rigid constraint the optimizer could not argue with.
    _REVISIT_EDGE_SIGMA_M = 0.05
    _REVISIT_EDGE_SIGMA_DEG = 1.0
    _REVISIT_EDGE_SIGMA_M_SPAN = 0.30
    _REVISIT_EDGE_SIGMA_DEG_SPAN = 6.0
    # Revisit callers that do not report a score are treated as this good.
    _REVISIT_DEFAULT_SCORE = 0.7
    # A new loop edge still this far off after optimizing disagrees with the
    # rest of the graph (likely a false match) and is dropped.
    _LOOP_MAX_CHI2 = 25.0
    # Camera frame older than this no longer punches holes in the lidar scan.
    _PAINT_DISC_MAX_AGE_S = 0.2
    _LOOP_REBUILD_MIN_M = 0.08
    _LOOP_REBUILD_MIN_DEG = 1.0
    # Small snaps close after two agreeing detections; multi-meter corridor
    # twins need a longer chain (same idea as repair.required_run).
    _LOOP_AGREE_DEFAULT = 2
    _LOOP_LARGE_SHIFT_M = 1.0
    _LOOP_AGREE_LARGE = 3

    @classmethod
    def _revisit_edge_sigmas(cls, score: Optional[float]) -> tuple[float, float]:
        """``(sigma_m, sigma_rad)`` for a revisit edge from its match score."""
        s = cls._REVISIT_DEFAULT_SCORE if score is None else float(score)
        if not math.isfinite(s):
            s = cls._REVISIT_DEFAULT_SCORE
        weak = 1.0 - max(0.0, min(1.0, s))
        return (
            cls._REVISIT_EDGE_SIGMA_M + cls._REVISIT_EDGE_SIGMA_M_SPAN * weak,
            math.radians(
                cls._REVISIT_EDGE_SIGMA_DEG + cls._REVISIT_EDGE_SIGMA_DEG_SPAN * weak
            ),
        )

    def _note_revisit(self, status: str, detail: dict) -> None:
        stats = self._loop_stats["revisit"]
        stats["attempts"] += 1
        if status in ("rebuilt", "pose_only"):
            stats["corrections"] += 1
        elif status.startswith("rejected"):
            stats["rejected"] += 1
        stats["reasons"][status] = stats["reasons"].get(status, 0) + 1
        stats["last"] = {"at": time.time(), "status": status, **detail}

    def apply_map_pose_correction(
        self,
        matched_pose: conv.Pose2D,
        *,
        score: Optional[float] = None,
        force: bool = False,
    ) -> dict:
        """Correct pose drift during mapping; re-render the grid from the graph.

        ``score`` is the revisit match quality (0..1); a weaker match becomes
        a softer graph edge. The edge then has to agree with the rest of the
        graph after optimizing (``_LOOP_MAX_CHI2``) or it is dropped and the
        pose is left alone. ``force`` is for explicit operator commands (yaw
        flip): the correction is applied rigidly without those checks.
        """
        cfg = self._cfg
        with self._lock:
            current = self._pose
            shift_m = math.hypot(matched_pose.x - current.x, matched_pose.y - current.y)
            shift_deg = abs(
                math.degrees(conv.normalize_angle(matched_pose.theta - current.theta))
            )
            scans_used = self._graph.scan_count()
            should_rebuild = (
                self._mode == MODE_MAPPING
                and cfg.builtin_rebuild_map_on_revisit
                and len(self._graph) > 0
                and (
                    shift_m >= float(cfg.mapping_revisit_min_shift_m)
                    or shift_deg >= float(cfg.mapping_revisit_min_shift_deg)
                )
            )
            if not should_rebuild:
                self._set_corrected_pose_locked(matched_pose)
        out = {
            "applied": True,
            "rebuilt": False,
            "keyframes": scans_used,
            "shift_m": round(shift_m, 3),
            "shift_deg": round(shift_deg, 2),
            "slam_backend": "builtin",
        }
        sigma_m, sigma_rad = self._revisit_edge_sigmas(score)
        detail = {
            "shift_m": round(shift_m, 3),
            "shift_deg": round(shift_deg, 2),
            "score": None if score is None else round(float(score), 3),
            "sigma_m": round(sigma_m, 3),
            "sigma_deg": round(math.degrees(sigma_rad), 2),
        }
        if not should_rebuild:
            self._note_revisit("pose_only", detail)
            self._notify_pose_listeners(matched_pose)
            self._persist_pose(force=True)
            return out

        with self._graph_job:
            with self._lock:
                anchor_before = self._node_poses_locked()
                corr = pg.world_correction(self._pose, matched_pose)
                cur = len(self._graph) - 1
                target = conv.compose_poses(corr, self._graph.nodes[cur].pose)
                anchor = self._graph.nearest_old_node(
                    target,
                    min_travel_gap_m=self._loop_params.min_travel_gap_m,
                    radius_m=3.0,
                )
                if anchor is None:
                    anchor = self._graph.earliest_node_near(target)
                trusted = self._baseline_trusted_locked()
                frozen = self._graph_frozen
                if not trusted and anchor is not None and anchor < frozen:
                    anchor = None
                allowed_shift = cfg.mapping_revisit_allowed_shift_m(
                    float(score) if score is not None else cfg.mapping_revisit_min_score
                )
                plausible = (
                    shift_m <= allowed_shift
                    and shift_deg <= self._GRAPH_CORRECTION_MAX_DEG
                )
                if anchor is not None and anchor < cur:
                    # Same bar as the loop detector: drift since the anchor
                    # cannot exceed a fraction of the path driven since then.
                    gap_m = (
                        self._graph.nodes[cur].travel_m
                        - self._graph.nodes[anchor].travel_m
                    )
                    allowed_m = max(0.3, self._loop_params.drift_fraction * gap_m)
                    detail["gap_m"] = round(gap_m, 2)
                    detail["allowed_m"] = round(allowed_m, 2)
                    plausible = plausible and shift_m <= allowed_m
                new_edges = None
                if force:
                    # Operator command (yaw flip): move the trailing path as one.
                    start = anchor + 1 if anchor is not None else 0
                    self._graph.apply_world_correction_from(max(start, frozen), corr)
                    method, first_free, live = "rigid", None, corr
                elif not plausible:
                    # A revisit this far off is a yaw flip or a wrong wall. The
                    # old rigid tail shift here is what slid a whole stretch of
                    # map sideways on a false match.
                    method, first_free, live = "rejected_implausible", None, None
                elif cur < frozen:
                    # No keyframe of this session yet; only the live pose moves.
                    self._set_corrected_pose_locked(matched_pose)
                    method, first_free, live = "pose_only", None, None
                elif anchor is not None and anchor < cur:
                    edge = pg.GraphEdge(
                        anchor,
                        cur,
                        conv.compose_poses(
                            conv.invert_pose(self._graph.nodes[anchor].pose), target
                        ),
                        pg.info_from_sigmas(sigma_m, sigma_rad),
                        loop=True,
                    )
                    self._graph.add_edge(edge)
                    new_edges = [edge]
                    method, first_free, live = (
                        "pose_graph",
                        self._live_first_free(anchor + 1),
                        None,
                    )
                elif anchor is not None:
                    # The nearest old geometry is the newest node itself: the
                    # drift happened after it. Move the live pose, not the map.
                    self._set_corrected_pose_locked(matched_pose)
                    method, first_free, live = "pose_only", None, None
                elif trusted and self._graph_base is not None:
                    # Mapping resumed on a loaded map: the match is against
                    # geometry no node of this session drew, so the whole
                    # session moves together onto it.
                    self._graph.apply_world_correction_from(frozen, corr)
                    method, first_free, live = "rigid", None, corr
                elif not trusted and (self._graph_base is not None or frozen > 0):
                    method, first_free, live = "rejected_untrusted_base", None, None
                else:
                    method, first_free, live = "rejected_no_anchor", None, None
                anchor_after = self._node_poses_locked()
            self._emit_anchor_motion(anchor_before, anchor_after)
            if method == "pose_only":
                result = {"status": "pose_only"}
            elif method.startswith("rejected"):
                result = {"status": method}
            else:
                result = self._optimize_and_render(
                    first_free, new_edges=new_edges, live_correction=live
                )
        status = str(result.get("status"))
        out.update(result)
        out["method"] = method
        out["anchor"] = anchor
        out["rebuilt"] = status == "rebuilt"
        # A rejected / aborted correction left the pose alone and the caller
        # must not report it as applied.
        out["applied"] = status in ("rebuilt", "pose_only")
        detail.update(method=method, anchor=anchor)
        if "loop_chi2" in result:
            detail["loop_chi2"] = result["loop_chi2"]
        self._note_revisit(status, detail)
        if status == "pose_only":
            self._notify_pose_listeners(matched_pose)
            self._persist_pose(force=True)
        self._log(
            f"builtin SLAM revisit correction ({method}, anchor={anchor}): "
            f"{status} shift={shift_m:.2f} m {shift_deg:.1f} deg "
            f"score={'n/a' if score is None else f'{float(score):.2f}'} "
            f"sigma={sigma_m:.2f} m {math.degrees(sigma_rad):.1f} deg "
            f"chi2={result.get('loop_chi2', 'n/a')}"
        )
        return out

    def note_paint_discs(self, discs, captured_at: float) -> None:
        """Remember dynamic-object discs until the next scan paint."""
        packed = []
        for disc in discs or []:
            if isinstance(disc, tuple):
                x, y, r = disc
            else:
                x, y, r = disc.x, disc.y, disc.radius_m
            if float(r) > 0.0:
                packed.append((float(x), float(y), float(r)))
        with self._lock:
            self._paint_discs = packed
            self._paint_discs_at = float(captured_at)

    def _fresh_paint_discs(self, now: float) -> list:
        with self._lock:
            if not self._paint_discs:
                return []
            if float(now) - float(self._paint_discs_at) > self._PAINT_DISC_MAX_AGE_S:
                return []
            return list(self._paint_discs)

    def _mask_dynamic_scan(self, scan, now: float):
        """Blank lidar returns that land on a fresh person (or other mover)."""
        discs = self._fresh_paint_discs(now)
        if not discs or scan is None:
            return scan
        from dataclasses import replace

        from ..semantic.paint_mask import mask_scan_ranges

        ranges = mask_scan_ranges(
            np.asarray(scan.ranges, dtype=float),
            float(scan.angle_min),
            float(scan.angle_increment),
            discs,
        )
        return replace(scan, ranges=ranges)

    def optimize_pose_graph(self) -> dict:
        """Optimize the whole mapping pose graph and re-render the grid."""
        with self._lock:
            if self._mode != MODE_MAPPING or len(self._graph) < 2:
                return {"status": "skipped", "nodes": len(self._graph)}
        with self._graph_job:
            return self._optimize_and_render(1)

    def _optimize_and_render(
        self,
        first_free: Optional[int],
        *,
        new_edges: Optional[list] = None,
        live_correction: Optional[conv.Pose2D] = None,
    ) -> dict:
        """Optimize (unless ``first_free`` is None), re-render, swap. Holds ``_graph_job``."""
        with self._lock:
            snap = self._graph.snapshot()
            base = self._graph_base
            res = self._grid.resolution
            revision = self._graph_revision
        n = len(snap)
        poses = snap.poses
        info: dict = {"nodes": n, "edges": len(snap.edges)}
        if first_free is not None and n > 1:
            window = max(1, int(self._cfg.builtin_loop_max_window_nodes))
            ff = max(1, int(first_free), n - window)
            started = perf_counter()
            res_opt = pg.optimize(snap.poses, snap.edges, first_free=ff)
            ms = (perf_counter() - started) * 1000.0
            self._loop_stats["optimizations"] += 1
            self._loop_stats["last_optimize_ms"] = round(ms, 1)
            info.update(
                free_nodes=res_opt.free_nodes,
                iterations=res_opt.iterations,
                chi2_before=round(res_opt.chi2_before, 2),
                chi2_after=round(res_opt.chi2_after, 2),
                optimize_ms=round(ms, 1),
            )
            if new_edges:
                worst = max(pg.edge_chi2(res_opt.poses, e) for e in new_edges)
                info["loop_chi2"] = round(worst, 2)
                if worst > self._LOOP_MAX_CHI2:
                    with self._lock:
                        self._graph.edges = [
                            e
                            for e in self._graph.edges
                            if not any(e is x for x in new_edges)
                        ]
                    self._loop_stats["rejected_inconsistent"] += 1
                    info["status"] = "rejected_inconsistent"
                    return info
            poses = res_opt.poses
        with self._lock:
            extra = self._graph.scans_after(snap.last_seq)
            rendered_edits = len(self._grid_edits)
            clears = self._render_clears(self._grid_edits)
        started = perf_counter()
        bands: dict = {}
        grid = pg.render_grid(
            snap,
            resolution=res,
            poses=poses,
            base=base,
            extra=extra,
            clears=clears,
            bands_out=bands,
        )
        render_ms = (perf_counter() - started) * 1000.0
        self._loop_stats["last_render_ms"] = round(render_ms, 1)
        info["render_ms"] = round(render_ms, 1)
        with self._lock:
            if self._graph_revision != revision:
                info["status"] = "aborted"
                return info
            anchor_before = self._node_poses_locked()
            tail = self._graph.apply_poses(snap, poses)
            # Inserts that landed while rendering, after ``extra`` was taken.
            newer = self._graph.scans_after(snap.last_seq)
            if len(newer) != len(extra):
                grid = pg.render_grid(
                    snap,
                    resolution=res,
                    poses=poses,
                    base=base,
                    extra=newer,
                    clears=clears,
                    bands_out=bands,
                )
            self._replay_after_render_locked(grid, rendered_edits)
            for band_grid in bands.values():
                self._replay_after_render_locked(band_grid, rendered_edits)
            self._grid = grid
            # Live paint rebuilds ``_grid`` from these; the old bands would
            # put back the walls this render moved.
            self._height_bands = bands
            self._generation += 1
            self._invalidate_occ_cache()
            self._last_loop_rebuild_at = time.monotonic()
            corr = live_correction if live_correction is not None else tail
            new_pose = conv.compose_poses(corr, self._pose)
            self._set_corrected_pose_locked(new_pose)
            self._graph_revision += 1
            anchor_after = self._node_poses_locked()
        self._emit_anchor_motion(anchor_before, anchor_after)
        info["status"] = "rebuilt"
        info["live_correction"] = {
            "x": round(corr.x, 3),
            "y": round(corr.y, 3),
            "theta_deg": round(math.degrees(corr.theta), 2),
        }
        self._notify_pose_listeners(new_pose)
        self._persist_pose(force=True)
        return info

    # -- automatic loop closure ---------------------------------------------
    def _loop_closure_enabled(self) -> bool:
        return (
            bool(getattr(self._cfg, "builtin_loop_closure", True))
            and self._mode == MODE_MAPPING
            and getattr(self._sensors, "world", None) is None
        )

    def _loop_closure_worker(self) -> None:
        while self._running:
            self._loop_event.wait(timeout=1.0)
            self._loop_event.clear()
            if not self._running:
                break
            try:
                self.refresh_map_health()
                self.run_loop_closure()
            except Exception as exc:  # noqa: BLE001
                self._log(f"builtin SLAM loop closure failed: {exc}")

    # Recompute at most this often; also forced when the grid generation moves.
    _MAP_HEALTH_MIN_S = 5.0
    # When the map is tearing, give the two-agree loop gate more time and run
    # mapping revisit more often so a doorway pass can still close.
    _MAP_HEALTH_PENDING_SCALE = {
        "ok": (1.0, 1.0),
        "cold": (1.0, 1.0),
        "watch": (1.5, 1.5),
        "degrading": (2.5, 2.0),
    }
    _MAP_HEALTH_REVISIT_S = {
        "ok": None,
        "cold": None,
        "watch": 10.0,
        "degrading": 6.0,
    }

    # A resumed map with doubled walls holds two copies of some of them;
    # matching the session against it picks one at random, so loop/revisit
    # ignore it. Tile-angle scatter does not. A floor that is not all
    # parallel still localizes, and freezing paint on that scatter blocked
    # updates where the scan lined up.

    def refresh_map_health(self, *, force: bool = False) -> dict:
        """Update cached occupancy health; no-op when not mapping or too soon."""
        now = time.monotonic()
        with self._lock:
            if self._mode != MODE_MAPPING:
                self._map_health = {"status": "idle"}
                return dict(self._map_health)
            gen = self._generation
            # Rate-limit even when generation bumps: every paint used to
            # re-score and race auto-heal / revisit boosts in a few seconds.
            if (
                not force
                and self._map_health_at > 0.0
                and now - self._map_health_at < self._MAP_HEALTH_MIN_S
                and self._session_baseline is self._map_health_base_src
            ):
                return dict(self._map_health)
            grid = occ.to_occupancy_int16(self._grid)
            res = float(self._grid.resolution)
            ox = float(self._grid.origin_x)
            oy = float(self._grid.origin_y)
            # Lidars at several heights: score each height's grid by itself.
            band_grids = (
                dict(self._height_bands) if len(self._height_bands) >= 2 else {}
            )
            base = self._session_baseline
            base_cells = None
            base_origin = (0.0, 0.0)
            if base is not self._map_health_base_src:
                self._map_health_base_src = base
                self._map_health_base_cells = None
                self._map_health_base = None
                if base is not None and abs(float(base.resolution) - res) < 1e-9:
                    base_cells = occ.to_occupancy_int16(base)
                    base_origin = (float(base.origin_x), float(base.origin_y))
        try:
            if base_cells is not None:
                base_health = map_health.assess_occupancy(
                    base_cells,
                    resolution=res,
                    origin_x=base_origin[0],
                    origin_y=base_origin[1],
                )
                self._map_health_base_cells = base_cells
                # Doubled walls distrust the resume even when the live status
                # was capped at watch. Angle scatter alone does not: a floor
                # that is not all parallel still localizes.
                trusted = float(base_health.ghost_frac) < float(
                    map_health._DEGRADING_GHOST
                )
                self._map_health_base = {
                    **base_health.as_dict(),
                    "trusted": trusted,
                    "origin_x": base_origin[0],
                    "origin_y": base_origin[1],
                }
                self._log(
                    f"map health baseline (loaded map) {base_health.status} "
                    f"ghost={base_health.ghost_frac:.2f} "
                    f"angle_std={base_health.angle_std_deg:.1f}deg; "
                    "scoring only walls this session adds"
                )
                if not trusted and not self._operator_trusted_paint:
                    self._log(
                        "WARNING: mapping resumed on a doubled map "
                        f"(ghost={base_health.ghost_frac:.2f}); loop closure and "
                        "revisit will not snap this session onto it. Scan "
                        "tracking still uses it, so doubled areas can keep "
                        "doubling: clear the torn stretch before rewriting walls"
                    )
            baseline = None
            scope = "map"
            if self._map_health_base_cells is not None and self._map_health_base:
                baseline = map_health.align_grid(
                    self._map_health_base_cells,
                    origin_x=self._map_health_base["origin_x"],
                    origin_y=self._map_health_base["origin_y"],
                    shape=grid.shape,
                    to_origin_x=ox,
                    to_origin_y=oy,
                    resolution=res,
                )
                scope = "session"
            elif self._map_health_ok_cells is not None:
                # Fresh map: score only walls added since the last ok snapshot
                # so re-driving known territory does not look like tearing.
                baseline = map_health.align_grid(
                    self._map_health_ok_cells,
                    origin_x=self._map_health_ok_origin[0],
                    origin_y=self._map_health_ok_origin[1],
                    shape=grid.shape,
                    to_origin_x=ox,
                    to_origin_y=oy,
                    resolution=res,
                )
                scope = "since_ok"
            height_rows = None
            if band_grids:
                cells = {
                    band: map_health.align_grid(
                        occ.to_occupancy_int16(band_grid),
                        origin_x=float(band_grid.origin_x),
                        origin_y=float(band_grid.origin_y),
                        shape=grid.shape,
                        to_origin_x=ox,
                        to_origin_y=oy,
                        resolution=res,
                    )
                    for band, band_grid in band_grids.items()
                    if abs(float(band_grid.resolution) - res) < 1e-9
                }
                health, height_rows = map_health.assess_heights(
                    cells, resolution=res, origin_x=ox, origin_y=oy, baseline=baseline
                )
            else:
                health = map_health.assess_occupancy(
                    grid, resolution=res, origin_x=ox, origin_y=oy, baseline=baseline
                )
        except Exception as exc:  # noqa: BLE001
            self._log(f"map health assess failed: {exc}")
            return dict(self._map_health)
        payload = health.as_dict()
        payload["age_s"] = 0.0
        payload["scope"] = scope
        if height_rows is not None:
            from .height_bands import BAND_M

            payload["rule"] = "per_height"
            payload["heights"] = [
                {
                    "z_min_m": round(row["band"] * BAND_M, 2),
                    "z_max_m": round((row["band"] + 1) * BAND_M, 2),
                    "status": row["raw_status"],
                    "ghost_frac": row["ghost_frac"],
                    "occupied_cells": row["occupied_cells"],
                }
                for row in height_rows
            ]
        if self._map_health_base is not None:
            payload["baseline"] = {
                k: v
                for k, v in self._map_health_base.items()
                if k not in ("origin_x", "origin_y")
            }
            if self._operator_trusted_paint:
                payload["recommendation"] = "remap_cleared_region"
            elif not self._map_health_base["trusted"]:
                payload["recommendation"] = "clear_map"
        elif self._operator_trusted_paint:
            payload["recommendation"] = "remap_cleared_region"
        prev = self._map_health_last_status
        if health.status != prev and health.status in ("watch", "degrading"):
            self._map_health_boosts += 1
            self._log(
                f"map health ({payload['scope']}) "
                f"{prev}->{health.status} ghost={health.ghost_frac:.2f} "
                f"angle_std={health.angle_std_deg:.1f}deg "
                f"hotspots={len(health.hotspots)}"
            )
        self._map_health_last_status = health.status
        # Advance the fresh-map ok checkpoint when the live map looks clean
        # (including early ``cold`` that is actually clean). Do not advance
        # while raw watch/degrading so a real tear stays visible against the
        # last good snapshot — and so re-driving known walls is excluded.
        raw = str(getattr(health, "raw_status", None) or health.status)
        if (
            self._map_health_base_cells is None
            and health.status in ("ok", "cold")
            and raw in ("ok", "cold")
            and int(health.occupied_cells) >= int(map_health._MIN_OCC_CELLS)
        ):
            self._map_health_ok_cells = np.array(grid, copy=True)
            self._map_health_ok_origin = (ox, oy)
        auto_cleared = None
        if not self._hotspot_heal_busy:
            self._hotspot_heal_busy = True
            try:
                auto_cleared = self._maybe_auto_heal_hotspot(payload, now=now)
            finally:
                self._hotspot_heal_busy = False
        payload["hotspot_heal"] = self._hotspot_heal_snapshot()
        if auto_cleared is not None:
            payload["recommendation"] = "remap_cleared_region"
            payload["auto_cleared"] = {
                "cleared_cells": auto_cleared.get("cleared_cells"),
                "removed_nodes": auto_cleared.get("removed_nodes"),
                "x_min": auto_cleared.get("x_min"),
                "y_min": auto_cleared.get("y_min"),
                "x_max": auto_cleared.get("x_max"),
                "y_max": auto_cleared.get("y_max"),
            }
        self._map_health = payload
        self._map_health_at = now
        self._map_health_generation = gen
        return dict(self._map_health)

    def map_health(self) -> dict:
        """Latest map-health snapshot (may be stale by a few seconds)."""
        out = dict(self._map_health)
        if self._map_health_at > 0.0:
            out["age_s"] = round(time.monotonic() - self._map_health_at, 2)
        out["boosts"] = self._map_health_boosts
        return out

    def _hotspot_heal_snapshot(self) -> dict:
        track = self._hotspot_track
        tracked = None
        if isinstance(track, dict):
            tracked = {
                "x": round(float(track["x"]), 1),
                "y": round(float(track["y"]), 1),
                "frac": round(float(track.get("frac") or 0.0), 2),
                "status": str(track.get("status") or ""),
                "streak": int(track.get("streak") or 0),
            }
        heal = self._hotspot_heal
        return {
            "enabled": bool(getattr(self._cfg, "map_health_auto_heal", False)),
            "auto_clear": bool(getattr(self._cfg, "map_health_auto_clear", False)),
            "clears": int(heal.get("clears") or 0),
            "last": heal.get("last"),
            "tracked": tracked,
            "skips": dict(heal.get("skips") or {}),
        }

    def _hotspot_heal_note_skip(self, reason: str) -> None:
        skips = self._hotspot_heal.setdefault("skips", {})
        skips[reason] = int(skips.get(reason) or 0) + 1

    def _maybe_auto_heal_hotspot(self, health: dict, *, now: float) -> Optional[dict]:
        """Track sustained ghost hotspots; auto ``clear_region`` when degrading.

        Returns the ``clear_region`` result when a clear fired, else ``None``.
        Revisit cadence already tightens via ``mapping_revisit_interval_s`` while
        status is watch/degrading; this only adds streak tracking + optional clear.
        """
        cfg = self._cfg
        if not bool(getattr(cfg, "map_health_auto_heal", False)):
            self._hotspot_track = None
            return None
        if self._mode != MODE_MAPPING:
            self._hotspot_track = None
            return None

        status = str(health.get("status") or "cold")
        hotspots = health.get("hotspots") or []
        top: Optional[tuple[float, float, float]] = None
        if isinstance(hotspots, list) and hotspots:
            h0 = hotspots[0]
            if (
                isinstance(h0, dict)
                and h0.get("x") is not None
                and h0.get("y") is not None
            ):
                top = (
                    float(h0["x"]),
                    float(h0["y"]),
                    float(h0.get("frac") or 0.0),
                )

        match_m = max(0.5, float(cfg.map_health_hotspot_match_m))
        persist_n = max(1, int(cfg.map_health_hotspot_persist_n))
        min_streak_s = float(self._MAP_HEALTH_MIN_S)
        track = self._hotspot_track

        if top is None or status not in ("watch", "degrading"):
            self._hotspot_track = None
            return None

        tx, ty, tfrac = top
        if (
            track is not None
            and math.hypot(tx - float(track["x"]), ty - float(track["y"])) <= match_m
        ):
            track["x"] = 0.7 * float(track["x"]) + 0.3 * tx
            track["y"] = 0.7 * float(track["y"]) + 0.3 * ty
            track["frac"] = tfrac
            track["status"] = status
            last_count = float(track.get("last_count_at") or 0.0)
            # Time-space streak samples so generation churn cannot race clear.
            if last_count <= 0.0 or now - last_count >= min_streak_s:
                track["streak"] = int(track.get("streak") or 0) + 1
                track["last_count_at"] = now
            track["last_at"] = now
        else:
            track = {
                "x": tx,
                "y": ty,
                "frac": tfrac,
                "status": status,
                "streak": 1,
                "last_at": now,
                "last_count_at": now,
            }
            self._hotspot_track = track

        if not bool(getattr(cfg, "map_health_auto_clear", False)):
            return None
        if status != "degrading":
            return None
        # Clear only for doubled walls. Wall-angle scatter also reads
        # degrading, but a floor whose walls are not all parallel is not
        # torn (the same call the resumed-map trust makes): on one robot's
        # clean single-line walls it read 25-29 degrees per lidar height.
        if float(health.get("ghost_frac") or 0.0) < float(map_health._DEGRADING_GHOST):
            self._hotspot_heal_note_skip("not_doubled")
            return None
        if int(track["streak"]) < persist_n:
            return None

        min_kf = max(0, int(getattr(cfg, "map_health_auto_clear_min_keyframes", 40)))
        if len(self._graph) < min_kf:
            self._hotspot_heal_note_skip("too_few_keyframes")
            return None

        near_m = max(0.5, float(getattr(cfg, "map_health_auto_clear_near_m", 6.0)))
        pose = self._pose
        if (
            math.hypot(
                float(pose.x) - float(track["x"]), float(pose.y) - float(track["y"])
            )
            > near_m
        ):
            self._hotspot_heal_note_skip("too_far")
            return None

        cooldown = max(0.0, float(cfg.map_health_auto_clear_cooldown_s))
        if (
            self._hotspot_last_clear_at > 0.0
            and now - self._hotspot_last_clear_at < cooldown
        ):
            self._hotspot_heal_note_skip("cooldown")
            return None

        repair = self._repair_status if isinstance(self._repair_status, dict) else {}
        repair_state = str(repair.get("state") or repair.get("status") or "")
        if repair_state in ("running", "started"):
            self._hotspot_heal_note_skip("repair_running")
            return None

        pad = max(0.5, float(cfg.map_health_auto_clear_pad_m))
        cx = float(track["x"])
        cy = float(track["y"])
        xa, ya, xb, yb = cx - pad, cy - pad, cx + pad, cy + pad
        try:
            result = self.clear_region(xa, ya, xb, yb)
        except Exception as exc:  # noqa: BLE001
            self._log(f"map health auto clear failed: {exc}")
            self._hotspot_heal_note_skip("clear_failed")
            return None

        self._hotspot_last_clear_at = now
        self._hotspot_heal["clears"] = int(self._hotspot_heal.get("clears") or 0) + 1
        self._hotspot_heal["last"] = {
            "cleared_cells": result.get("cleared_cells"),
            "removed_nodes": result.get("removed_nodes"),
            "x_min": result.get("x_min"),
            "y_min": result.get("y_min"),
            "x_max": result.get("x_max"),
            "y_max": result.get("y_max"),
            "rebuilt": result.get("rebuilt"),
            "center": {"x": round(cx, 1), "y": round(cy, 1)},
            "streak": persist_n,
            "trigger": "degrading_hotspot",
        }
        self._log(
            "map health auto clear "
            f"center=({cx:.1f},{cy:.1f}) pad={pad:.1f}m "
            f"removed={result.get('removed_nodes')} "
            f"cells={result.get('cleared_cells')}"
        )
        return result

    def _map_health_status(self) -> str:
        return str(self._map_health.get("status") or "cold")

    def _baseline_trusted_locked(self) -> bool:
        """False when the map this session resumed on was scored as torn.

        ``clear_region`` sets ``_operator_trusted_paint`` so the cleared hole
        can be remapped with full paint even if leftover ghosts still make
        the baseline health look ``degrading``.
        """
        if self._operator_trusted_paint:
            return True
        baseline = self._session_baseline
        return not (
            baseline is not None
            and baseline is self._map_health_base_src
            and self._map_health_base is not None
            and not self._map_health_base["trusted"]
        )

    def _mapping_guidance_locked(self) -> dict:
        """Mid-session coach for drive-around map quality (operator UX)."""
        health = self._map_health if isinstance(self._map_health, dict) else {}
        status = str(health.get("status") or "cold")
        trusted = self._baseline_trusted_locked()
        extend_only = not trusted
        operator = bool(self._operator_trusted_paint)
        hotspots = health.get("hotspots") or []
        repair = (
            dict(self._repair_status) if isinstance(self._repair_status, dict) else {}
        )
        reasons: list[str] = []
        actions: list[str] = []

        heal = health.get("hotspot_heal") if isinstance(health, dict) else None
        if not isinstance(heal, dict):
            heal = self._hotspot_heal_snapshot()
        tracked = heal.get("tracked") if isinstance(heal, dict) else None
        auto_heal_on = bool(heal.get("enabled")) if isinstance(heal, dict) else False
        auto_clear_on = (
            bool(heal.get("auto_clear")) if isinstance(heal, dict) else False
        )

        if status in ("watch", "degrading"):
            reasons.append(f"map_health={status}")
            if status == "degrading":
                if auto_heal_on and auto_clear_on:
                    actions.append(
                        "Map is tearing — auto-heal will clear a sustained hotspot; "
                        "revisit doorways meanwhile"
                    )
                else:
                    actions.append(
                        "Map is tearing — clear the doubled stretch before you rely on Save"
                    )
            else:
                actions.append(
                    "Map health is watch — revisit doorways or clear hotspots if walls look doubled"
                )
            if isinstance(tracked, dict) and tracked.get("x") is not None:
                streak = int(tracked.get("streak") or 0)
                actions.append(
                    f"Hotspot tracked at ({float(tracked['x']):.1f}, "
                    f"{float(tracked['y']):.1f}) streak={streak}"
                    + (
                        " — auto clear pending"
                        if auto_clear_on and status == "degrading"
                        else ""
                    )
                )
            elif isinstance(hotspots, list) and hotspots:
                top = hotspots[0] if isinstance(hotspots[0], dict) else None
                if top and top.get("x") is not None and top.get("y") is not None:
                    actions.append(
                        f"Clear region around ({float(top['x']):.1f}, "
                        f"{float(top['y']):.1f}) then re-drive that corridor"
                    )

        if operator:
            reasons.append("remap_after_clear")
            actions.append(
                "Cleared region is ready — drive it to remap (full paint enabled)"
            )
        elif extend_only:
            reasons.append("untrusted_baseline")
            actions.append(
                "Paint is extend-only on an untrusted map — clear_region torn areas "
                "(or clear_map) so walls can be rewritten"
            )

        repair_state = str(repair.get("state") or "")
        repair_status = str(repair.get("status") or "")
        if repair_state in ("running", "started") or repair_status in (
            "running",
            "started",
        ):
            reasons.append("repair_running")
            actions.append(
                "Map repair is running — wait before navigating on this save"
            )
        elif repair_status == "kept":
            reasons.append("repair_kept")
            actions.append(
                "Save-time repair did not apply — clear_region hotspots or keep mapping"
            )

        # Dedupe while preserving order.
        seen: set[str] = set()
        uniq: list[str] = []
        for a in actions:
            if a not in seen:
                seen.add(a)
                uniq.append(a)
        return {
            "suggested_action": uniq[0] if uniq else None,
            "actions": uniq[:4],
            "reasons": reasons,
            "operator_trusted_paint": operator,
            "extend_only": extend_only,
            "health_status": status,
            "hotspot_count": (len(hotspots) if isinstance(hotspots, list) else 0),
            "hotspot_heal": heal if isinstance(heal, dict) else None,
        }

    def _live_first_free(self, first_free: int) -> int:
        """Live corrections never move keyframes reloaded from the saved map."""
        return max(int(first_free), self._graph_frozen)

    def _pending_limits(self) -> tuple[float, int]:
        """Effective (max_s, max_tries) for the two-agree loop gate."""
        scale_s, scale_t = self._MAP_HEALTH_PENDING_SCALE.get(
            self._map_health_status(), (1.0, 1.0)
        )
        return (
            float(self._loop_pending_max_s) * float(scale_s),
            max(2, int(round(self._loop_pending_max_tries * float(scale_t)))),
        )

    def mapping_revisit_interval_s(self, default_s: float) -> float:
        """Shorter revisit cadence while map health is watch/degrading."""
        boost = self._MAP_HEALTH_REVISIT_S.get(self._map_health_status())
        interval = float(default_s)
        if boost is not None:
            interval = min(interval, float(boost))
        # Sustained hotspot under auto-heal: check even sooner so a doorway
        # pass can correct before auto-clear fires.
        track = self._hotspot_track
        if (
            bool(getattr(self._cfg, "map_health_auto_heal", False))
            and isinstance(track, dict)
            and int(track.get("streak") or 0) >= 2
        ):
            interval = min(interval, 5.0)
        return float(interval)

    @staticmethod
    def _loop_edge(
        snap: pg.GraphSnapshot, cur: int, match: loop_closure.LoopMatch
    ) -> pg.GraphEdge:
        return loop_closure.edge_from_match(snap, cur, match)

    @staticmethod
    def _corrections_agree(a: conv.Pose2D, b: conv.Pose2D, at: conv.Pose2D) -> bool:
        pa = conv.compose_poses(a, at)
        pb = conv.compose_poses(b, at)
        return math.hypot(pa.x - pb.x, pa.y - pb.y) <= 0.15 and abs(
            conv.normalize_angle(pa.theta - pb.theta)
        ) <= math.radians(2.0)

    def _loop_agrees_needed(self, shift_m: float) -> int:
        """Agreeing detections required before committing a loop of this size."""
        if float(shift_m) >= self._LOOP_LARGE_SHIFT_M:
            return int(self._LOOP_AGREE_LARGE)
        return int(self._LOOP_AGREE_DEFAULT)

    def run_loop_closure(self) -> dict:
        """One detection pass on the newest keyframe; closes after N agree.

        Small snaps need two agreeing detections; multi-meter shifts need three
        so a twin-corridor hit cannot weld aisles on a short streak.
        """
        if not self._loop_closure_enabled():
            return {"status": "disabled"}
        if not self._graph_job.acquire(blocking=False):
            return {"status": "busy"}
        try:
            with self._lock:
                self._loop_last_attempt_at = time.monotonic()
                if self._graph.full:
                    if not self._loop_full_logged:
                        self._loop_full_logged = True
                        self._log(
                            "builtin SLAM loop closure off for this session: "
                            f"{len(self._graph)} keyframes "
                            "(builtin_mapping_keyframe_max)"
                        )
                    return {"status": "graph_full"}
                snap = self._graph.snapshot()
                trusted = self._baseline_trusted_locked()
                base = self._graph_base if trusted else None
                min_node = 0 if trusted else self._graph_frozen
                res = self._grid.resolution
                revision = self._graph_revision
            if self._graph_frozen and len(snap) <= self._graph_frozen:
                return {"status": "no_nodes"}
            match, reason = loop_closure.detect(
                snap, self._loop_params, resolution=res, base=base, min_node=min_node
            )
            stats = self._loop_stats
            stats["attempts"] += 1
            stats["reasons"][reason] = stats["reasons"].get(reason, 0) + 1
            if reason != "ok" or match is None:
                self._loop_pending = None
                return {"status": reason}
            cur = len(snap) - 1
            prior = snap.pose(cur)
            corr = pg.world_correction(prior, match.pose)
            edge = self._loop_edge(snap, cur, match)
            shift_m = math.hypot(match.pose.x - prior.x, match.pose.y - prior.y)
            need = self._loop_agrees_needed(shift_m)
            now_mono = time.monotonic()
            pending = self._loop_pending
            pending_max_s, pending_max_tries = self._pending_limits()
            # Pending tuple: (revision, cur, corr, edges, t0, tries, need).
            # A pending match that never finds enough agreeing detections used
            # to sit ``pending=true`` forever while the map kept tearing. Expire
            # it so the next cycle starts clean — never apply a single unconfirmed
            # edge. When map health is degrading the window is stretched so a
            # doorway pass still has time to land the remaining agreeing hits.
            if pending is not None:
                age_s = now_mono - pending[4]
                if age_s >= pending_max_s or pending[5] >= pending_max_tries:
                    self._loop_pending = None
                    stats["pending_expired"] += 1
                    stats["reasons"]["pending_expired"] = (
                        stats["reasons"].get("pending_expired", 0) + 1
                    )
                    pending = None
            agree = (
                pending is not None
                and pending[0] == revision
                and pending[1] != cur
                and self._corrections_agree(pending[2], corr, prior)
            )
            if not agree:
                if pending is None:
                    self._loop_pending = (
                        revision,
                        cur,
                        corr,
                        [edge],
                        now_mono,
                        1,
                        need,
                    )
                    return {"status": "pending"}
                tries = pending[5] + 1
                if (
                    tries >= pending_max_tries
                    or (now_mono - pending[4]) >= pending_max_s
                ):
                    self._loop_pending = None
                    stats["pending_expired"] += 1
                    stats["reasons"]["pending_expired"] = (
                        stats["reasons"].get("pending_expired", 0) + 1
                    )
                    # Arm a fresh pending from this match so the next agreeing
                    # detection can still close; do not leave the old one hanging.
                    self._loop_pending = (
                        revision,
                        cur,
                        corr,
                        [edge],
                        now_mono,
                        1,
                        need,
                    )
                    return {"status": "pending_expired"}
                self._loop_pending = (
                    revision,
                    cur,
                    corr,
                    [edge],
                    pending[4],
                    tries,
                    need,
                )
                return {"status": "pending"}
            edges = list(pending[3]) + [edge]
            chain_need = max(int(pending[6]), need)
            if len(edges) < chain_need:
                # Agreeing hits do not burn the expiry try budget — only
                # disagreeing replacements do (above).
                self._loop_pending = (
                    revision,
                    cur,
                    corr,
                    edges,
                    pending[4],
                    pending[5],
                    chain_need,
                )
                return {"status": "pending"}
            self._loop_pending = None
            with self._lock:
                if self._graph_revision != revision:
                    return {"status": "aborted"}
                for e in edges:
                    self._graph.add_edge(e)
            shift_deg = abs(
                math.degrees(conv.normalize_angle(match.pose.theta - prior.theta))
            )
            stats["closures"] += 1
            stats["last"] = {
                "at": time.time(),
                "node": cur,
                "anchor": match.anchor,
                "gap_m": round(match.gap_m, 2),
                "score": round(match.fit, 3),
                "prior_score": round(match.prior_fit, 3),
                "overlap": round(match.overlap, 3),
                "shift_m": round(shift_m, 3),
                "shift_deg": round(shift_deg, 2),
            }
            if (
                shift_m < self._LOOP_REBUILD_MIN_M
                and shift_deg < self._LOOP_REBUILD_MIN_DEG
            ):
                # Matcher-quantization sized: keep the edge for the next
                # optimization but skip a full re-render now.
                return {"status": "constrained", **stats["last"]}
            anchors = [e.i for e in edges if e.i >= 0]
            first_free = self._live_first_free(min(anchors) + 1 if anchors else 1)
            result = self._optimize_and_render(first_free, new_edges=edges)
            stats["last"]["result"] = result.get("status")
            self._log(
                "builtin SLAM loop closure: "
                f"{result.get('status')} node={cur} anchor={match.anchor} "
                f"gap={match.gap_m:.1f} m shift={shift_m:.2f} m {shift_deg:.1f} deg "
                f"score={match.fit:.2f} (prior {match.prior_fit:.2f}) "
                f"opt={result.get('optimize_ms')} ms render={result.get('render_ms')} ms"
            )
            return {**stats["last"], **result}
        finally:
            self._graph_job.release()

    def save_map(self, map_dir: Path, *, repair: bool = True) -> dict:
        """Write map.pgm/yaml (+ keyframes.npz) and, when mapping, check repair."""
        map_dir = Path(map_dir)
        keep_keyframes = bool(getattr(self._cfg, "builtin_save_keyframes", True))
        with self._lock:
            old_sha = graph_store.file_sha1(map_dir / "map.pgm")
            sha = persistence.save_occupancy(map_dir, self._grid)
            self._map_dir = map_dir
            pose = self._pose
            seed_pending = self._seed_localize_pending
            mode = self._mode
            res = float(self._grid.resolution)
            # Write the live graph whenever it has nodes (mapping, or
            # localizing after resume / clear_region node drops). Flat
            # localizing with an empty graph still falls through to the
            # append-edits path below.
            payload = (
                self._graph_payload_locked()
                if keep_keyframes and len(self._graph) > 0
                else None
            )
            new_edits = list(self._grid_edits[self._grid_edits_saved :])
        out: dict = {"keyframes": "none"}
        if keep_keyframes:
            try:
                out["keyframes"] = self._write_keyframes(
                    map_dir, sha, old_sha, res, payload, new_edits, mode
                )
            except Exception as exc:  # noqa: BLE001
                out["keyframes"] = "failed"
                self._log(f"save keyframes failed: {exc}")
        if bool(getattr(self._cfg, "persist_pose", True)) and not (
            mode == MODE_LOCALIZING and seed_pending
        ):
            try:
                persistence.save_last_pose(map_dir, pose)
                self._last_pose_save_at = time.monotonic()
            except Exception as exc:  # noqa: BLE001
                self._log(f"persist last pose failed: {exc}")
        if (
            repair
            and mode == MODE_MAPPING
            and bool(getattr(self._cfg, "builtin_repair_on_save", True))
        ):
            out["repair"] = self.start_repair(map_dir, apply="auto", reason="save")
        return out

    def _graph_payload_locked(self) -> dict:
        snap = self._graph.snapshot()
        nodes = [
            pg.GraphNode(
                pose=snap.pose(i),
                travel_m=float(snap.travel[i]),
                scans=list(snap.scans[i]),
                inserts=int(self._graph.nodes[i].inserts),
            )
            for i in range(len(snap))
        ]
        return {
            "nodes": nodes,
            "edges": list(snap.edges),
            "last_seq": int(snap.last_seq),
            "base": self._graph_base,
            "edits": list(self._grid_edits),
        }

    def _write_keyframes(
        self,
        map_dir: Path,
        sha: str,
        old_sha: Optional[str],
        res: float,
        payload: Optional[dict],
        new_edits: list,
        mode: str,
    ) -> str:
        if payload is not None:
            graph_store.save_graph(map_dir, image_sha1=sha, resolution=res, **payload)
            self._grid_edits_saved = len(payload["edits"])
            return "saved"
        if mode == MODE_MAPPING:
            return "none"
        # Not mapping: keep saved keyframes valid for the re-saved image and
        # carry over obstacle edits made since the map was loaded.
        saved = graph_store.load_graph(map_dir, image_sha1=old_sha, resolution=res)
        if saved is None:
            return "none"
        graph_store.save_graph(
            map_dir,
            image_sha1=sha,
            resolution=res,
            nodes=saved.nodes,
            edges=saved.edges,
            last_seq=saved.last_seq,
            base=saved.base,
            edits=saved.edits + new_edits,
        )
        self._grid_edits_saved += len(new_edits)
        return "updated"

    # -- map repair ------------------------------------------------------------
    _REPAIR_MIN_NODES = 12
    _REPAIR_BACKUP_DIR = "pre_repair"
    _REPAIR_FILES = ("map.pgm", "map.yaml", graph_store.KEYFRAMES_FILENAME)

    def start_repair(
        self, map_dir: Optional[Path], *, apply="auto", reason: str = "manual"
    ) -> dict:
        """Run ``run_repair`` on a background thread; see ``repair_status``."""
        with self._repair_lock:
            running = self._repair_thread
            if running is not None and running.is_alive():
                return {"status": "running"}
            with self._lock:
                skip = self._repair_skip_reason_locked()
            if skip is not None:
                return {"status": "skipped", "reason": skip}
            self._repair_status = {
                "state": "running",
                "reason": reason,
                "apply": apply,
                "started_at": time.time(),
            }
            thread = threading.Thread(
                target=self._repair_job,
                args=(map_dir, apply, reason),
                name="slam-map-repair",
                daemon=True,
            )
            self._repair_thread = thread
            self._repair_map_dir = Path(map_dir) if map_dir is not None else None
            thread.start()
        return {"status": "started"}

    def repair_status(self) -> dict:
        return dict(self._repair_status)

    def _finish_or_cancel_repair(self, map_dir: Optional[Path]) -> None:
        """Before a mode switch: let a running repair of the map being loaded land.

        Reloading that map mid-repair would drop the repair and load the torn
        files. Any other switch (another map, a fresh session) cancels it.
        """
        thread = self._repair_thread
        if thread is None or not thread.is_alive():
            return
        if thread is threading.current_thread():
            return
        target = self._repair_map_dir
        wait_s = float(getattr(self._cfg, "builtin_repair_switch_wait_s", 120.0))
        same_map = (
            map_dir is not None
            and target is not None
            and Path(map_dir).resolve() == target.resolve()
        )
        if same_map and wait_s > 0.0:
            self._log(
                f"waiting up to {wait_s:.0f} s for map repair to finish "
                f"before reloading {target.name}"
            )
            thread.join(wait_s)
            if not thread.is_alive():
                # The repair moved the live pose with the map; reload from it.
                self._persist_pose(force=True)
                return
            self._log("map repair still running; cancelling it for the switch")
        self._repair_cancel.set()

    def _repair_job(self, map_dir: Optional[Path], apply, reason: str) -> None:
        try:
            result = self.run_repair(apply=apply, map_dir=map_dir, reason=reason)
        except Exception as exc:  # noqa: BLE001
            result = {"status": "failed", "error": str(exc)}
            self._log(f"map repair ({reason}) failed: {exc}")
        result.update(state="done", reason=reason, finished_at=time.time())
        self._repair_status = result

    def _repair_skip_reason_locked(self) -> Optional[str]:
        if self._mode != MODE_MAPPING:
            return "not_mapping"
        if len(self._graph) < self._REPAIR_MIN_NODES:
            return "too_few_keyframes"
        return None

    def run_repair(
        self,
        *,
        apply="auto",
        map_dir: Optional[Path] = None,
        reason: str = "manual",
    ) -> dict:
        """Re-detect loops over the whole graph; apply when ``apply`` allows.

        ``apply``: ``"auto"`` only when ``repair.verdict`` is confident,
        ``True`` / ``"force"`` when nothing gets worse, ``False`` plans only.
        With ``map_dir`` an applied repair backs up the saved files and
        re-saves. Blocks; on a large map this takes minutes.
        """
        self._repair_cancel.clear()
        with self._lock:
            skip = self._repair_skip_reason_locked()
        if skip is not None:
            return {"status": "skipped", "reason": skip}
        cfg = self._cfg
        params = repair.RepairParams(
            loop=repair.relaxed_loop_params(self._loop_params),
            max_chi2=self._LOOP_MAX_CHI2,
            window_nodes=max(1, int(cfg.builtin_loop_max_window_nodes)),
            max_s=float(getattr(cfg, "builtin_repair_max_s", 600.0)),
        )
        with self._graph_job:
            with self._lock:
                snap = self._graph.snapshot()
                trusted = self._baseline_trusted_locked()
                base = self._graph_base
                res = float(self._grid.resolution)
                revision = self._graph_revision
                edits = list(self._grid_edits)
            plan = repair.plan_repair(
                snap,
                resolution=res,
                params=params,
                base=base if trusted else None,
                should_stop=self._repair_cancel.is_set,
            )
            out: dict = {"status": "no_corrections", **plan.summary()}
            if not plan.clusters:
                self._log(
                    f"map repair ({reason}): nothing to correct "
                    f"({plan.matched}/{plan.examined} keyframes matched, "
                    f"{plan.rejected} rejected)"
                )
                return out
            before = self._assess_render(snap, snap.poses, base, edits, res)
            after = self._assess_render(snap, plan.poses, base, edits, res)
            confident, not_confident = repair.verdict(before, after, plan, params)
            out.update(
                before=before.as_dict(),
                after=after.as_dict(),
                confident=confident,
                not_confident=not_confident,
            )
            if apply == "auto":
                do_apply = confident
            elif apply is True or apply == "force":
                do_apply = repair.acceptable(before, after, plan)
            else:
                do_apply = False
            if not do_apply:
                out["status"] = "planned" if apply in (False, "never") else "kept"
                self._log(
                    f"map repair ({reason}): not applied "
                    f"({', '.join(not_confident) or 'dry run'}); "
                    f"ghost {before.ghost_frac:.2f}->{after.ghost_frac:.2f} "
                    f"angle_std {before.angle_std_deg:.1f}->"
                    f"{after.angle_std_deg:.1f}deg"
                )
                return out
            backup = self._backup_map_files(map_dir) if map_dir is not None else False
            with self._lock:
                if self._graph_revision != revision or self._mode != MODE_MAPPING:
                    out["status"] = "aborted"
                    return out
                anchor_before = self._node_poses_locked()
                for e in plan.edges:
                    self._graph.add_edge(e)
                tail = self._graph.apply_poses(snap, plan.poses)
                anchor_after = self._node_poses_locked()
            self._emit_anchor_motion(anchor_before, anchor_after)
            rendered = self._optimize_and_render(None, live_correction=tail)
            if rendered.get("status") != "rebuilt":
                out["status"] = "aborted"
                return out
            self._last_repair_tail = tail
        out.update(status="applied", backup=backup, render_ms=rendered.get("render_ms"))
        self._log(
            f"map repair ({reason}): applied {len(plan.clusters)} corrections "
            f"(max {plan.max_shift_m:.2f} m / {plan.max_shift_deg:.1f} deg); "
            f"ghost {before.ghost_frac:.2f}->{after.ghost_frac:.2f} "
            f"angle_std {before.angle_std_deg:.1f}->{after.angle_std_deg:.1f}deg"
            + ("; previous files in pre_repair/ (undo_repair)" if backup else "")
        )
        if map_dir is not None:
            self.save_map(map_dir, repair=False)
            out["saved"] = True
        return out

    def _assess_render(
        self,
        snap: pg.GraphSnapshot,
        poses: np.ndarray,
        base: Optional[LogOddsGrid],
        edits: list,
        res: float,
    ) -> map_health.MapHealth:
        grid = pg.render_grid(
            snap,
            resolution=res,
            poses=poses,
            base=base,
            clears=self._render_clears(edits),
        )
        for edit in edits:
            if not self._seq_scoped(edit):
                self._apply_grid_edit(grid, edit)
        return map_health.assess_occupancy(
            occ.to_occupancy_int16(grid),
            resolution=res,
            origin_x=float(grid.origin_x),
            origin_y=float(grid.origin_y),
        )

    def _backup_map_files(self, map_dir: Path) -> bool:
        src = Path(map_dir)
        files = [src / f for f in self._REPAIR_FILES if (src / f).is_file()]
        if not files:
            return False
        dst = src / self._REPAIR_BACKUP_DIR
        tmp = src / (self._REPAIR_BACKUP_DIR + ".tmp")
        shutil.rmtree(tmp, ignore_errors=True)
        tmp.mkdir(parents=True)
        for f in files:
            shutil.copy2(f, tmp / f.name)
        shutil.rmtree(dst, ignore_errors=True)
        tmp.rename(dst)
        return True

    def undo_repair(self, map_dir: Path) -> dict:
        """Restore the files saved before the last applied repair and reload them.

        Mapping done since that repair and not saved is dropped with it.
        """
        src = Path(map_dir)
        backup = src / self._REPAIR_BACKUP_DIR
        if not backup.is_dir():
            return {"status": "no_backup"}
        with self._graph_job:
            for name in self._REPAIR_FILES:
                saved = backup / name
                if saved.is_file():
                    shutil.copy2(saved, src / name)
                else:
                    (src / name).unlink(missing_ok=True)
            shutil.rmtree(backup, ignore_errors=True)
            with self._lock:
                mode = self._mode
                pose = self._pose
            tail, self._last_repair_tail = self._last_repair_tail, None
        self.configure_mode(mode, src)
        if tail is not None:
            self.set_pose(conv.compose_poses(conv.invert_pose(tail), pose))
        self._log(f"map repair undone; restored files from {backup.name}/")
        return {"status": "restored", "mode": mode}

    def _invalidate_occ_cache(self) -> None:
        self._match_epoch += 1
        self._occ_cache = None
        self._occ_cache_lookup = None
        self._occ_cache_epoch = -1

    def _occupancy_for_match(self) -> OccupancyMap:
        """Scan-match grid. The int16 convert runs outside the pose lock."""
        with self._lock:
            if (
                self._occ_cache is not None
                and self._occ_cache_epoch == self._match_epoch
            ):
                return self._occ_cache
            grid = self._grid
            epoch = self._match_epoch
            has_clears = any(e[0] == "clear_box" for e in self._grid_edits)
        int16 = occ.to_occupancy_int16(grid)
        if has_clears:
            # A cleared hole is free to the planner but says nothing about
            # where the walls are. Judged as free, every return from a wall
            # inside it counted against the scan and painting never resumed.
            int16[grid.log_odds == np.float32(occ.CLEARED_LOG_ODDS)] = -1
        occ_map = scan_match.occupancy_map_from_int16(
            int16,
            resolution=grid.resolution,
            origin_x=grid.origin_x,
            origin_y=grid.origin_y,
        )
        lookup = scan_match.occupied_lookup(occ_map)
        known = float(np.mean(int16 >= 0))
        with self._lock:
            if self._grid is grid and self._match_epoch == epoch:
                self._occ_cache = occ_map
                self._occ_cache_lookup = lookup
                self._occ_cache_epoch = epoch
                self._occ_cache_known = known
            elif self._occ_cache is None:
                self._occ_cache_known = known
        return occ_map

    def _occupied_lookup_for(self, occ_map: OccupancyMap) -> Optional[np.ndarray]:
        """Cached wall mask for ``occ_map`` when it is the current cache entry."""
        with self._lock:
            if occ_map is self._occ_cache:
                return self._occ_cache_lookup
        return None

    # -- queries -------------------------------------------------------------
    def get_pose(self) -> conv.Pose2D:
        with self._lock:
            return self._pose

    def vision_anchor(self) -> tuple:
        """Latest pose-graph node, for hanging a camera keyframe from it.

        Returns ``(node_index, node_pose, {index: pose})``. When the graph is
        empty, ``node_index`` is ``-1`` and the pose table is empty — callers
        should fall back to the live pose.
        """
        with self._lock:
            poses = {
                i: conv.Pose2D(float(n.pose.x), float(n.pose.y), float(n.pose.theta))
                for i, n in enumerate(self._graph.nodes)
            }
            if not poses:
                return -1, self._pose, {}
            idx = len(self._graph.nodes) - 1
            return idx, poses[idx], poses

    def get_pose_at(self, t: float) -> Optional[conv.Pose2D]:
        """Map pose at monotonic time ``t``, in the current map frame.

        The current pose with the odometry motion since ``t`` undone. ``None``
        when ``t`` is outside the recent history.
        """
        with self._lock:
            motion = self._motion_since(t)
            if motion is None:
                return None
            return conv.compose_poses(self._pose, conv.invert_pose(motion))

    # Older captures are not compensated: the odometry history is short and a
    # frame this late is already refused by the scan age limits.
    _MAX_SCAN_LATENCY_S = 1.0

    def _motion_since(self, t: float) -> Optional[conv.Pose2D]:
        """Body-frame odometry motion from time ``t`` to the newest sample."""
        hist = self._odom_hist
        if not hist or not math.isfinite(t):
            return None
        t_new, c_new = hist[-1]
        if t >= t_new:
            return conv.Pose2D(0.0, 0.0, 0.0)
        if t_new - t > self._MAX_SCAN_LATENCY_S or t < hist[0][0]:
            return None
        c_at = hist[0][1]
        for (t0, c0), (t1, c1) in zip(hist, list(hist)[1:]):
            if t0 <= t <= t1:
                step = conv.compose_poses(conv.invert_pose(c0), c1)
                a = (t - t0) / (t1 - t0) if t1 > t0 else 1.0
                c_at = conv.compose_poses(
                    c0, conv.Pose2D(a * step.x, a * step.y, a * step.theta)
                )
                break
        return conv.compose_poses(conv.invert_pose(c_at), c_new)

    def _record_odom_step(
        self, before: conv.Pose2D, after: conv.Pose2D, now: float
    ) -> None:
        step = conv.compose_poses(conv.invert_pose(before), after)
        self._odom_chain = conv.compose_poses(self._odom_chain, step)
        self._odom_hist.append((now, self._odom_chain))

    def _scan_capture_motion(self) -> Optional[conv.Pose2D]:
        """Motion since the current scan was captured (``None``: unknown)."""
        fn = getattr(self._sensors, "scan_captured_at", None)
        if not callable(fn):
            return None
        try:
            captured_at = float(fn())
        except Exception:  # noqa: BLE001
            return None
        if not math.isfinite(captured_at):
            return None
        motion = self._motion_since(captured_at)
        if motion is not None and self._odom_hist:
            self._last_scan_latency_s = max(0.0, self._odom_hist[-1][0] - captured_at)
        return motion

    def get_odom_twist(self) -> tuple[float, float, float]:
        with self._lock:
            return self._last_odom_twist

    def get_map(self) -> dict:
        with self._lock:
            grid = self._grid
            generation = self._generation
        # Convert off the lock. Published grids are replaced, not mutated, so
        # this snapshot stays stable while pose reads proceed.
        return {
            "grid": occ.to_occupancy_int16(grid),
            "resolution": grid.resolution,
            "origin_x": grid.origin_x,
            "origin_y": grid.origin_y,
            "generation": generation,
        }

    def diagnostics(self) -> dict:
        odom_status_fn = getattr(self._sensors, "odom_status", None)
        odom_status = None
        if callable(odom_status_fn):
            try:
                odom_status = odom_status_fn()
            except Exception:  # noqa: BLE001
                odom_status = None
        with self._lock:
            return {
                "odom": odom_status,
                "slam_backend": "builtin",
                "mode": self._mode,
                "running": self._running,
                "ticks": self._ticks,
                "map_updates": self._updates,
                "match_accepts": self._match_accepts,
                "match_applied": self._match_accepts,
                "match_held": self._match_held,
                "match_failed": self._match_failed,
                # Legacy total of non-applied outcomes (held + failed). Prefer
                # match_held / match_failed — "rejects climbing" is not dying.
                "match_rejects": self._match_held + self._match_failed,
                "drive_applies": self._drive_applies,
                "yaw_only_applies": self._yaw_only_applies,
                "heading": self._heading_diagnostics(),
                "pose": {
                    "x": self._pose.x,
                    "y": self._pose.y,
                    "theta": self._pose.theta,
                },
                "grid": {
                    "width": self._grid.width,
                    "height": self._grid.height,
                    "resolution": self._grid.resolution,
                    "origin_x": self._grid.origin_x,
                    "origin_y": self._grid.origin_y,
                },
                "last_match_score": self._last_match_score,
                "last_prior_score": self._last_prior_score,
                # Which scan the last pose match used: the merged scan, or
                # the best-fitting lidar height and what each height scored.
                "match": (
                    None if self._match_detail is None else dict(self._match_detail)
                ),
                "last_scan_age_s": self._last_scan_age_s,
                "last_scan_latency_s": self._last_scan_latency_s,
                "yaw_rate_deg_s": round(math.degrees(self._last_yaw_rate), 2),
                "insert_skips_turning": self._insert_skips_turning,
                "insert_skips_unmatched": self._insert_skips_unmatched,
                "heading_recovers": self._heading_recovers,
                "pose_polishes": self._pose_polishes,
                "paint": {
                    "state": self._paint_state,
                    "last_fit": self._paint_last_fit,
                    "age_s": (
                        None
                        if self._paint_last_at <= 0.0
                        else round(time.monotonic() - self._paint_last_at, 2)
                    ),
                    "last_score": self._last_match_score,
                    "prior_score": self._last_prior_score,
                    # The check that decides ``last_fit`` (the two scores
                    # above are the pose matcher's, not this).
                    "fit": (
                        None
                        if self._paint_fit_detail is None
                        else dict(self._paint_fit_detail)
                    ),
                    "skips_turning": self._insert_skips_turning,
                    "skips_unmatched": self._insert_skips_unmatched,
                    "map_updates": self._updates,
                    "baseline_trusted": self._baseline_trusted_locked(),
                    "extend_only": not self._baseline_trusted_locked(),
                    "operator_trusted": bool(self._operator_trusted_paint),
                },
                "map_health": self.map_health(),
                "mapping_guidance": self._mapping_guidance_locked(),
                "hotspot_heal": self._hotspot_heal_snapshot(),
                "repair": self.repair_status(),
                "generation": self._generation,
                "seed_localize_pending": self._seed_localize_pending,
                "pose_restored_from_disk": self._pose_restored_from_disk,
                "keyframes": self._graph.scan_count(),
                "last_loop_rebuild_at": self._last_loop_rebuild_at,
                "loop_closure": {
                    "enabled": self._loop_closure_enabled(),
                    "nodes": len(self._graph),
                    "saved_nodes": self._graph_frozen,
                    "edges": len(self._graph.edges),
                    "loop_edges": self._graph.loop_edge_count(),
                    "graph_full": self._graph.full,
                    "pending": self._loop_pending is not None,
                    "pending_age_s": (
                        None
                        if self._loop_pending is None
                        else round(time.monotonic() - self._loop_pending[4], 2)
                    ),
                    "pending_tries": (
                        None
                        if self._loop_pending is None
                        else int(self._loop_pending[5])
                    ),
                    "attempts": self._loop_stats["attempts"],
                    "closures": self._loop_stats["closures"],
                    "optimizations": self._loop_stats["optimizations"],
                    "rejected_inconsistent": self._loop_stats["rejected_inconsistent"],
                    "pending_expired": self._loop_stats["pending_expired"],
                    "reasons": dict(self._loop_stats["reasons"]),
                    "last": self._loop_stats["last"],
                    "last_optimize_ms": self._loop_stats["last_optimize_ms"],
                    "last_render_ms": self._loop_stats["last_render_ms"],
                    "revisit": {
                        **{
                            k: v
                            for k, v in self._loop_stats["revisit"].items()
                            if k != "reasons"
                        },
                        "reasons": dict(self._loop_stats["revisit"]["reasons"]),
                    },
                },
                "lidar_odometry": {
                    "enabled": self._lidar_odom_enabled(),
                    "accepts": self._lo_accepts,
                    "rejects": self._lo_rejects,
                    "resets": self._lo_resets,
                    "inserts_held": self._lo_inserts_held,
                    "last_inlier_ratio": self._lo_last_inlier,
                    "last_rms_m": self._lo_last_rms,
                    "forward_m_s": round(self._lo_vel[0], 3),
                    "left_m_s": round(self._lo_vel[1], 3),
                    "turn_rate_deg_s": round(math.degrees(self._lo_turn_rate), 1),
                    "last_match_ms": round(self._lo_match_ms, 1),
                    # After a spin these should agree; a large ratio means the
                    # IMU's turn-rate units are off.
                    "yaw_check": {
                        "gyro_deg": round(math.degrees(self._yaw_check_gyro), 1),
                        "lidar_deg": round(math.degrees(self._yaw_check_lidar), 1),
                    },
                },
            }

    # -- loop ----------------------------------------------------------------
    def _loop(self) -> None:
        while self._running:
            t0 = time.monotonic()
            try:
                self._tick()
            except Exception as exc:  # noqa: BLE001
                self._log(f"builtin SLAM tick failed: {exc}")
            else:
                self._persist_pose(force=False)
            elapsed = time.monotonic() - t0
            time.sleep(max(0.0, self._period - elapsed))

    def _tick(self) -> None:
        # Matching/mapping against a stale scan biases the pose toward where
        # the robot was when the scan was taken; keep the age tight even if
        # the nav-facing scan_max_age_s is generous.
        scan_age = min(float(self._cfg.scan_max_age_s or 2.0), 0.75)
        get_scan = self._sensors.get_scan
        try:
            scan = get_scan(max_age_s=scan_age, fresh=True)
        except TypeError:  # test doubles without the ``fresh`` kwarg
            scan = get_scan(max_age_s=scan_age)
        odom = self._sensors.get_odom()
        now = time.monotonic()
        age_fn = getattr(self._sensors, "scan_age_s", None)
        if callable(age_fn):
            try:
                self._last_scan_age_s = float(age_fn())
            except Exception:  # noqa: BLE001
                pass
        # A scan object we already matched/inserted must not be re-used at a
        # newer pose: during a turn that paints the same wall at every heading.
        new_scan = scan is not None and scan is not self._last_scan_obj
        if scan is not None:
            self._last_scan_obj = scan

        # Builtin sim: body pose in SimWorld is ground truth (raycast + kinematics).
        # Track it directly so localize/set_pose cannot yank the body or desync
        # scans from the estimate. Real-robot path below is unchanged.
        world = getattr(self._sensors, "world", None)
        if world is not None:
            self._tick_sim_world(world, scan, odom, now, new_scan=new_scan)
            return

        with self._lock:
            seed_pending = self._mode == MODE_LOCALIZING and self._seed_localize_pending

        if seed_pending:
            # Hold absolute pose at whatever set_pose/origin is until a full-map
            # seed lands — do not odom-integrate from an assumed start point.
            if scan is None:
                return
            if now - self._last_seed_attempt_at < 2.0:
                return
            self._last_seed_attempt_at = now
            self._try_seed_global_localize(scan)
            return

        with self._lock:
            self._ticks += 1
            prev_pose, prev_at = self._last_tick_pose, self._last_tick_at
            before = self._pose
            predicted = self._predict(odom, now)
            self._pose = predicted
            self._record_odom_step(before, predicted, now)
            self._last_tick_pose, self._last_tick_at = predicted, now
            yaw_rate = 0.0
            lin_rate = 0.0
            if prev_pose is not None and prev_at is not None and now > prev_at:
                dt = now - prev_at
                yaw_rate = (
                    abs(conv.normalize_angle(predicted.theta - prev_pose.theta)) / dt
                )
                lin_rate = (
                    math.hypot(predicted.x - prev_pose.x, predicted.y - prev_pose.y)
                    / dt
                )
            self._last_yaw_rate = yaw_rate
            self._last_lin_rate = lin_rate
            if scan is None or not new_scan:
                return
            use_lo = self._lidar_odom_active(odom)
            if self._lo_reset_pending:
                self._lo_reset_pending = False
                self._lo.reset()
            match_due = now - self._last_match_at >= self._match_period_s
            epoch = self._pose_epoch
            # The scan was taken before this tick. Matching it at ``predicted``
            # left the pose behind by speed × latency (and the heading by the
            # turn rate × latency), so the body sat beside its drawn pose.
            capture_motion = self._scan_capture_motion()
            scan_pose = (
                conv.compose_poses(predicted, conv.invert_pose(capture_motion))
                if capture_motion is not None
                else predicted
            )

        occ_map = None
        run_match = False
        if match_due:
            occ_map = self._occupancy_for_match()
            run_match = self._occ_cache_known > 0.02

        lo_ok = False
        if use_lo:
            gyro_rate = abs(float(odom.vtheta)) if odom is not None else 0.0
            lo_ok = self._lidar_odom_step(scan, now, gyro_rate=gyro_rate)
            if lo_ok and self._mode == MODE_MAPPING:
                # The map is being built from these poses; the grid matcher
                # only re-checks them against themselves.
                run_match = False

        # Heavy work happens OUTSIDE the lock: matching while holding it
        # blocked every get_pose/get_map (nav planning + pose reads stalled).
        if run_match:
            matched, score, prior_score, rival_score, match_scan = self._match_pose(
                occ_map, scan, scan_pose
            )
            if matched is not None and capture_motion is not None:
                matched = conv.compose_poses(matched, capture_motion)
            # While driving, also ask the heading alone. Yaw is what a
            # skid-steer loses in every turn, and a corridor that cannot
            # place the body along the hall still fixes its heading.
            yaw_fix = None
            if self._navigation_active():
                yaw_fix = self._yaw_only_fix(occ_map, match_scan, scan_pose)
            with self._lock:
                self._last_match_at = now
                self._last_match_score = score
                self._last_prior_score = prior_score
                self._last_match_rival_score = rival_score
                if self._pose_epoch != epoch:
                    # Pose moved frame (loop closure) mid-match.
                    return
                applied = self._apply_match(self._pose, matched, odom, yaw_fix=yaw_fix)
                self._note_match_outcome(
                    applied=applied,
                    matched=matched,
                    score=score,
                    prior_score=prior_score,
                )

        if self._mode == MODE_MAPPING:
            with self._lock:
                if self._pose_epoch != epoch:
                    return
            if use_lo and not lo_ok and self._last_insert_pose is not None:
                # No scan match: the pose is a guess. Painting there doubles walls.
                self._lo_inserts_held += 1
                self._note_paint("held_lidar_odom", now)
            elif self._spinning(yaw_rate, lin_rate):
                # A turn smears a scan and the wheel heading is the part that
                # slips. Hold the frames and draw them once a still scan lines
                # up with the map.
                self._remember_spin_scan(scan, now, capture_motion)
                self._insert_skips_turning += 1
                self._note_paint("held_turning", now)
            elif self._spin_hold:
                self._flush_spin_hold(scan, now, capture_motion)
            elif not self._scan_fits_map(scan, scan_pose):
                # Pose often only slipped in yaw (skid / delayed match). A
                # full-circle heading search can put the scan back on the
                # walls so mapping keeps growing instead of freezing.
                if self._try_recover_heading_for_paint(
                    scan, scan_pose, capture_motion, now
                ):
                    self._maybe_insert_scan(scan, now, capture_motion=capture_motion)
                else:
                    self._insert_skips_unmatched += 1
                    self._note_paint("held_unmatched", now, fit="miss")
            else:
                self._maybe_insert_scan(scan, now, capture_motion=capture_motion)

    # -- lidar odometry --------------------------------------------------------
    # Lidar velocity is trusted this long after the last match; after that the
    # IMU-only prediction takes over again.
    _LO_FRESH_S = 1.5
    # Velocity decays toward 0 once matches stop arriving.
    _LO_DECAY_AFTER_S = 0.3
    _LO_DECAY_TAU_S = 0.5
    _LO_GAIN = 0.5
    _LO_MAX_FORWARD_M_S = 1.2
    _LO_MAX_LATERAL_M_S = 0.3
    # Consecutive misses before the local map restarts from the current pose.
    _LO_MAX_FAILS = 10
    # Occupied cells (one hit is 0.85) also anchor matching; refreshed after
    # this many map inserts.
    _LO_MAP_OCC_LOG_ODDS = 1.5
    _LO_MAP_REFRESH_INSERTS = 10
    # One ~100 ms Livox frame taken while turning is smeared by rate * 0.1 s;
    # above this the scan still tracks the pose but is not drawn.
    _LO_MAX_INSERT_YAW_RATE = math.radians(15.0)

    def _lidar_odom_enabled(self) -> bool:
        return bool(getattr(self._cfg, "lidar_odometry", False))

    def _lidar_odom_active(self, odom: Optional[conv.OdomReading]) -> bool:
        """Only for samples without wheel speed or an odom pose (not the Tracer)."""
        if not self._lidar_odom_enabled():
            return False
        if odom is None:
            return True
        return (
            odom.pose is None
            and abs(float(odom.vx)) <= 1e-3
            and abs(float(odom.vy)) <= 1e-3
        )

    def _lidar_odom_fresh(self, now: float) -> bool:
        return (
            self._lo_last_at is not None and now - self._lo_last_at <= self._LO_FRESH_S
        )

    def _occupied_map_points_locked(self) -> np.ndarray:
        grid = self._grid
        rows, cols = np.nonzero(grid.log_odds > self._LO_MAP_OCC_LOG_ODDS)
        res = grid.resolution
        return np.stack(
            [grid.origin_x + (cols + 0.5) * res, grid.origin_y + (rows + 0.5) * res],
            axis=1,
        )

    def _lidar_odom_step(
        self, scan: conv.LaserScan2D, now: float, *, gyro_rate: float = 0.0
    ) -> bool:
        """ICP this scan against recent scans and the map. True when the pose came from it."""
        cloud = scan.cloud_xy
        scan_xy = cloud if cloud is not None and cloud.shape[0] else scan.to_points()
        with self._lock:
            guess = self._pose
            epoch = self._pose_epoch
            map_pts = None
            if (
                self._lo_map_updates is None
                or self._updates - self._lo_map_updates >= self._LO_MAP_REFRESH_INSERTS
            ):
                map_pts = self._occupied_map_points_locked()
                self._lo_map_updates = self._updates
        if map_pts is not None:
            self._lo.set_map_points(map_pts)
        if not self._lo.has_reference():
            self._lo.add_keyscan(scan_xy, guess, force=True)
            with self._lock:
                self._lo_last_at = now
                self._lo_prev_theta = guess.theta
            return self._last_insert_pose is None
        started = perf_counter()
        result = self._lo.match(scan_xy, guess)
        self._lo_match_ms = (perf_counter() - started) * 1000.0
        with self._lock:
            if self._pose_epoch != epoch:
                return False
            if result is None:
                self._lo_rejects += 1
                self._lo_fails += 1
                if self._lo_fails >= self._LO_MAX_FAILS:
                    self._lo_fails = 0
                    self._lo_resets += 1
                    self._lo_vel = (0.0, 0.0)
                    self._lo_prev_theta = self._pose.theta
                    self._lo_turn_rate = 0.0
                    self._lo.reset()
                    self._lo.add_keyscan(scan_xy, self._pose, force=True)
                    self._log(
                        "builtin SLAM: lidar odometry lost track; restarting local map"
                    )
                return False
            current = self._pose
            pose = result.pose
            if self._lo_last_at is not None:
                dt = now - self._lo_last_at
                if 0.0 < dt <= 1.0:
                    rx, ry = pose.x - current.x, pose.y - current.y
                    c, s = math.cos(current.theta), math.sin(current.theta)
                    fwd = self._lo_vel[0] + self._LO_GAIN * (c * rx + s * ry) / dt
                    left = self._lo_vel[1] + self._LO_GAIN * (-s * rx + c * ry) / dt
                    fwd = max(
                        -self._LO_MAX_FORWARD_M_S, min(self._LO_MAX_FORWARD_M_S, fwd)
                    )
                    left = max(
                        -self._LO_MAX_LATERAL_M_S, min(self._LO_MAX_LATERAL_M_S, left)
                    )
                    self._lo_vel = (fwd, left)
            if self._lo_prev_theta is not None:
                turned = conv.normalize_angle(pose.theta - self._lo_prev_theta)
                self._yaw_check_lidar += turned
                if self._lo_last_at is not None and now > self._lo_last_at:
                    self._lo_turn_rate = abs(turned) / (now - self._lo_last_at)
            self._lo_prev_theta = pose.theta
            self._pose = pose
            self._lo_last_at = now
            self._lo_fails = 0
            self._lo_accepts += 1
            self._lo_last_inlier = round(result.inlier_ratio, 3)
            self._lo_last_rms = round(result.rms_m, 4)
            self._imu_forward_m_s = 0.0
        if max(gyro_rate, self._lo_turn_rate) <= self._LO_MAX_INSERT_YAW_RATE:
            # A frame skewed by a turn would tilt every match that uses it.
            self._lo.add_keyscan(scan_xy, pose)
        return True

    def _lidar_odom_twist(self, now: float, dt: float) -> tuple[float, float]:
        """Body (forward, left) velocity for prediction, decayed when matches stop."""
        fwd, left = self._lo_vel
        if (
            self._lo_last_at is not None
            and now - self._lo_last_at > self._LO_DECAY_AFTER_S
        ):
            k = math.exp(-dt / self._LO_DECAY_TAU_S)
            fwd, left = fwd * k, left * k
            self._lo_vel = (fwd, left)
        return fwd, left

    def _tick_sim_world(
        self,
        world,
        scan,
        odom: Optional[conv.OdomReading],
        now: float,
        *,
        new_scan: bool,
    ) -> None:
        """SLAM pose follows SimWorld; match scores are diagnostic only."""
        pose = world.get_pose()
        with self._lock:
            prev_pose, prev_at = self._last_tick_pose, self._last_tick_at
            self._pose = pose
            # World pose is authoritative — never wait on seed global_localize.
            self._seed_localize_pending = False
            self._pending_match = None
            self._pending_count = 0
            self._ticks += 1
            self._last_tick_pose, self._last_tick_at = pose, now
            if odom is not None and odom.pose is not None:
                self._last_odom_pose = conv.Pose2D(
                    odom.pose.x, odom.pose.y, odom.pose.theta
                )
                self._last_odom_heading = odom.heading_rad
                self._last_odom_time = now
            yaw_rate = 0.0
            if prev_pose is not None and prev_at is not None and now > prev_at:
                yaw_rate = abs(conv.normalize_angle(pose.theta - prev_pose.theta)) / (
                    now - prev_at
                )
            self._last_yaw_rate = yaw_rate
            if scan is None or not new_scan:
                return
            match_due = now - self._last_match_at >= self._match_period_s

        occ_map = None
        run_match = False
        if match_due:
            occ_map = self._occupancy_for_match()
            run_match = self._occ_cache_known > 0.02

        if run_match:
            matched, score, prior_score, rival_score = scan_match.refine_pose(
                occ_map,
                scan,
                pose,
                occupied_lookup=self._occupied_lookup_for(occ_map),
            )
            with self._lock:
                self._last_match_at = now
                self._last_match_score = score
                self._last_prior_score = prior_score
                self._last_match_rival_score = rival_score
                # Do not apply match to pose (would fight SimWorld). Count how
                # often the map agrees with ground truth for status.
                agreed = False
                if matched is not None:
                    dist = math.hypot(matched.x - pose.x, matched.y - pose.y)
                    dyaw = abs(conv.normalize_angle(matched.theta - pose.theta))
                    agreed = (
                        dist <= self._SMALL_CORRECTION_M
                        and dyaw <= self._SMALL_CORRECTION_RAD
                    )
                self._note_match_outcome(
                    applied=agreed,
                    matched=matched,
                    score=score,
                    prior_score=prior_score,
                )

        if self._mode == MODE_MAPPING:
            if yaw_rate > self._MAX_INSERT_YAW_RATE:
                self._insert_skips_turning += 1
            else:
                self._maybe_insert_scan(scan, now)

    # Above this yaw rate a revolution is skewed >~5 deg; keep matching but
    # do not bake the skewed scan into the map.
    _MAX_INSERT_YAW_RATE = math.radians(45.0)

    def _try_seed_global_localize(self, scan) -> bool:
        """Full-map match once scans are available; apply if score is trusted."""
        from ..nav.localize.global_localize import global_localize_scan

        try:
            occ_map = self._occupancy_for_match()
        except Exception:  # noqa: BLE001
            return False
        known = self._occ_cache_known
        if known < 0.02:
            return False
        try:
            result = global_localize_scan(occ_map, scan, hint=None, full_map=True)
        except Exception as exc:  # noqa: BLE001
            self._log(f"seed global localize failed: {exc}")
            return False
        if result.ambiguous:
            # A second place explains the scan nearly as well.
            self._log(
                f"seed global localize ambiguous (score={float(result.score):.3f} "
                f"second={float(result.second_best_score):.3f}); retrying"
            )
            return False
        score = float(result.score)
        if not math.isfinite(score) or score < self._seed_min_score:
            self._log(
                f"seed global localize weak (score={score:.3f} "
                f"ray_mae={result.ray_mae_m:.3f}); retrying"
            )
            return False
        pose = result.pose
        with self._lock:
            current = self._pose
        decision = self._pose_jump_gate.evaluate(current, pose, force=False)
        if not decision.should_apply:
            self._log(
                f"seed global localize awaiting confirm "
                f"{decision.confirm_count}/{decision.confirm_needed} "
                f"(shift={decision.shift_m:.2f} m score={score:.3f})"
            )
            return False
        with self._lock:
            self._pose = pose
            self._seed_localize_pending = False
            self._last_odom_pose = None
            self._last_odom_heading = None
            self._last_odom_time = None
            self._pending_match = None
            self._pending_count = 0
            self._last_match_score = score
        self._notify_pose_listeners(pose)
        self._log(
            f"seed global localize applied "
            f"x={pose.x:.2f} y={pose.y:.2f} th={pose.theta:.2f} "
            f"score={score:.3f} ray_mae={result.ray_mae_m:.3f} "
            f"jump={decision.status}"
        )
        return True

    def _spinning(self, yaw_rate: float, lin_rate: float) -> bool:
        turning = yaw_rate > _SPIN_HOLD_YAW_RATE or (
            self._spin_hold and yaw_rate > math.radians(5.0)
        )
        return turning and lin_rate < _SPIN_HOLD_LINEAR

    def _copy_scan(self, scan: conv.LaserScan2D) -> conv.LaserScan2D:
        xyz = getattr(scan, "cloud_xyz", None)
        xy = getattr(scan, "cloud_xy", None)
        return conv.LaserScan2D(
            ranges=np.array(scan.ranges, dtype=float, copy=True),
            angle_min=float(scan.angle_min),
            angle_increment=float(scan.angle_increment),
            range_min=float(scan.range_min),
            range_max=float(scan.range_max),
            sensor_pose=scan.sensor_pose,
            capture_pose=scan.capture_pose,
            cloud_xy=None if xy is None else np.array(xy, dtype=float, copy=True),
            cloud_xyz=None if xyz is None else np.array(xyz, dtype=float, copy=True),
        )

    def _copy_frames(self, frames: list) -> list:
        out = []
        for item in frames:
            if isinstance(item, tuple):
                out.append((item[0], self._copy_scan(item[1])))
            else:
                out.append(self._copy_scan(item))
        return out

    def _capture_pose(self, capture_motion: Optional[conv.Pose2D]) -> conv.Pose2D:
        with self._lock:
            pose = self._pose
        if capture_motion is not None:
            pose = conv.compose_poses(pose, conv.invert_pose(capture_motion))
        return conv.Pose2D(pose.x, pose.y, pose.theta)

    def _remember_spin_scan(
        self,
        scan: conv.LaserScan2D,
        now: float,
        capture_motion: Optional[conv.Pose2D],
    ) -> None:
        self._spin_hold.append(
            (
                self._copy_scan(scan),
                self._capture_pose(capture_motion),
                self._copy_frames(self._mapping_frames()),
                now,
            )
        )
        if len(self._spin_hold) > _SPIN_HOLD_MAX:
            self._spin_hold.clear()
            self._log("dropped mapping spin buffer; the turn ran too long")

    def _note_paint(self, state: str, now: float, *, fit: Optional[str] = None) -> None:
        """Record the latest mapping-paint decision for ``get_status``."""
        self._paint_state = str(state)
        self._paint_last_at = float(now)
        if fit is not None:
            self._paint_last_fit = str(fit)

    def _scan_map_fit(self, scan: conv.LaserScan2D, pose: conv.Pose2D) -> str:
        """``open``, ``fit``, or ``miss`` for painting ``scan`` at ``pose``.

        ``scan`` is the scan just read. With lidars at more than one height,
        each height is scored by itself and the best one decides; otherwise
        the merged scan is scored as one.
        """
        try:
            occ_map = self._occupancy_for_match()
        except Exception:  # noqa: BLE001
            return "open"
        votes = self._height_votes(occ_map, pose)
        if len(votes) >= 2:
            from .height_bands import BAND_M

            best = max(votes, key=lambda vote: vote.score)
            state = "fit" if best.score >= _HEIGHT_VOTE_MIN_SCORE else "miss"
            self._paint_fit_detail = {
                "rule": "best_height",
                "state": state,
                "score": round(best.score, 3),
                "pass_mark": _HEIGHT_VOTE_MIN_SCORE,
                "heights": [
                    {
                        "z_min_m": round(vote.band * BAND_M, 2),
                        "z_max_m": round((vote.band + 1) * BAND_M, 2),
                        "score": round(vote.score, 3),
                        "judged": vote.judged,
                    }
                    for vote in sorted(votes, key=lambda vote: vote.band)
                ],
            }
            return state
        state, score = scan_match.scan_map_overlap(
            occ_map,
            scan,
            pose,
            min_score=_MAP_INSERT_MIN_SCORE,
            occupied_lookup=self._occupied_lookup_for(occ_map),
        )
        self._paint_fit_detail = {
            "rule": "merged_scan",
            "state": state,
            "score": round(score, 3) if math.isfinite(score) else None,
            "pass_mark": _MAP_INSERT_MIN_SCORE,
        }
        return state

    def _height_votes(self, occ_map: OccupancyMap, pose: conv.Pose2D) -> list:
        """Per-height votes for the scan just read; empty with one height."""
        _bands, votes = self._heights_at(occ_map, pose)
        return votes

    def height_scans(self) -> dict:
        """Per-height scans of the last lidar read; empty with lidars at one height.

        For searches outside the tick (``global_localize``) that should not
        let one height's furniture hide another height's walls.
        """
        try:
            bands = self._band_scans(self._mapping_frames())
        except Exception:  # noqa: BLE001
            return {}
        return dict(bands) if len(bands) >= 2 else {}

    def _heights_at(self, occ_map: OccupancyMap, pose: conv.Pose2D) -> tuple:
        """``(band scans, votes)`` for the scan just read; empty with one height."""
        try:
            bands = self._band_scans(self._mapping_frames())
        except Exception:  # noqa: BLE001
            return {}, []
        if len(bands) < 2:
            return {}, []
        return bands, scan_match.height_votes(occ_map, bands, pose)

    # One height takes over the pose match from the merged scan only when
    # the map explains it this much better. Where every height agrees with
    # the map the merged scan has more walls to match and was the more
    # precise of the two on a robot's own keyframes.
    _MATCH_HEIGHT_MARGIN = 0.15

    def _match_pose(
        self, occ_map: OccupancyMap, scan: conv.LaserScan2D, scan_pose: conv.Pose2D
    ) -> tuple:
        """Pose match for the scan just read, and the scan it was made with.

        ``(pose_or_none, score, prior_score, rival_score, scan)``, as
        ``scan_match.refine_pose`` returns them. The merged scan is matched
        as always. With lidars at more than one height, each height that can
        judge the pose is matched too, and one the map explains clearly
        better takes over, including when its answer is to stay. The merged
        scan keeps the nearest return in each direction, so furniture at one
        height can pull the match off the walls another height sees: on a
        robot with lidars at 0.21 m and 1.2 m the merged scan scored 0.15
        and asked for a move of 45 cm and 8 degrees, which was rejected,
        while the 1.2 m lidar alone scored 0.66 for a move of 18 cm that put
        its walls back on the map.
        """
        lookup = self._occupied_lookup_for(occ_map)
        merged = scan_match.refine_pose(
            occ_map, scan, scan_pose, occupied_lookup=lookup
        )
        bands, votes = self._heights_at(occ_map, scan_pose)
        if len(votes) < 2:
            self._match_detail = {"rule": "merged_scan"}
            return (*merged, scan)
        from .height_bands import BAND_M

        best = None
        tried = []
        for vote in sorted(votes, key=lambda vote: vote.band):
            band_scan = bands[vote.band]
            found = scan_match.refine_pose(
                occ_map, band_scan, scan_pose, occupied_lookup=lookup
            )
            if not math.isfinite(found[1]):
                continue
            tried.append(
                {
                    "z_min_m": round(vote.band * BAND_M, 2),
                    "z_max_m": round((vote.band + 1) * BAND_M, 2),
                    "score": round(float(found[1]), 3),
                    "moves": found[0] is not None,
                }
            )
            if best is None or found[1] > best[0][1]:
                best = (found, band_scan, len(tried) - 1)
        merged_score = float(merged[1]) if math.isfinite(merged[1]) else float("-inf")
        detail = {
            "merged_score": round(merged_score, 3)
            if math.isfinite(merged_score)
            else None,
            "heights": tried,
        }
        if best is None or best[0][1] < merged_score + self._MATCH_HEIGHT_MARGIN:
            self._match_detail = {"rule": "merged_scan", **detail}
            return (*merged, scan)
        found, band_scan, index = best
        self._match_detail = {
            "rule": "best_height",
            "decided_by": {
                "z_min_m": tried[index]["z_min_m"],
                "z_max_m": tried[index]["z_max_m"],
            },
            **detail,
        }
        return (*found, band_scan)

    def _scan_fits_map(self, scan: conv.LaserScan2D, pose: conv.Pose2D) -> bool:
        """True when the map does not yet constrain ``pose``, or the scan lands on it."""
        return self._scan_map_fit(scan, pose) != "miss"

    # Full-circle heading search is a few ms; do not run it on every refused
    # paint tick while the robot is stuck in a featureless area.
    _HEADING_RECOVER_MIN_S = 0.4

    def _search_heading_for_scan(
        self, scan: conv.LaserScan2D, pose: conv.Pose2D
    ) -> tuple[Optional[conv.Pose2D], float]:
        try:
            occ_map = self._occupancy_for_match()
        except Exception:  # noqa: BLE001
            return None, float("-inf")
        lookup = self._occupied_lookup_for(occ_map)
        bands, votes = self._heights_at(occ_map, pose)
        if len(votes) < 2:
            return scan_match.search_heading(
                occ_map,
                scan,
                pose,
                min_score=_MAP_INSERT_MIN_SCORE,
                occupied_lookup=lookup,
            )
        # Each height searches with its own returns, and a heading counts
        # only if that height's walls then sit on the map.
        best: tuple[Optional[conv.Pose2D], float] = (None, float("-inf"))
        for vote in votes:
            found, _score = scan_match.search_heading(
                occ_map,
                bands[vote.band],
                pose,
                min_score=_MAP_INSERT_MIN_SCORE,
                occupied_lookup=lookup,
            )
            if found is None:
                continue
            agreement, judged = scan_match.wall_agreement(
                occ_map, bands[vote.band], found
            )
            if judged > 0 and agreement > best[1]:
                best = (found, float(agreement))
        if best[0] is None or best[1] < _HEIGHT_VOTE_MIN_SCORE:
            return None, best[1]
        return best

    def _paint_pose_by_heights(
        self, scan_pose: conv.Pose2D
    ) -> tuple[str, Optional[conv.Pose2D]]:
        """Where to paint the scan just read, by the best-agreeing height.

        ``("one_height", None)`` when there is nothing to decide here.
        ``("as_is", None)`` to paint at ``scan_pose``. ``("moved", pose)`` to
        paint a few centimetres away, where that height's walls sit on the
        map. ``("refuse", None)`` when no pose that close passes, or when the
        fit keeps improving toward the edge of the search: the pose is then
        off by more than a polish should fix, and painting at the edge would
        draw the walls part-way to where they belong. The pose matcher moves
        it first.
        """
        try:
            occ_map = self._occupancy_for_match()
        except Exception:  # noqa: BLE001
            return "one_height", None
        bands, votes = self._heights_at(occ_map, scan_pose)
        if len(votes) < 2:
            return "one_height", None
        best = max(votes, key=lambda vote: vote.score)
        if best.score >= _HEIGHT_VOTE_CONFIDENT:
            return "as_is", None
        found, score, edge_gain = scan_match.polish_on_walls(
            occ_map, bands[best.band], scan_pose
        )
        detail = dict(self._paint_fit_detail or {})
        farther = found is not None and edge_gain >= _POLISH_EDGE_GAIN
        if found is None or farther or score < _HEIGHT_VOTE_MIN_SCORE:
            detail.update(
                state="miss",
                polish="better_fit_farther_away"
                if farther
                else "no_pose_nearby_passes",
            )
            self._paint_fit_detail = detail
            return "refuse", None
        moved = (
            math.hypot(found.x - scan_pose.x, found.y - scan_pose.y) > 1e-6
            or abs(conv.normalize_angle(found.theta - scan_pose.theta)) > 1e-9
        )
        detail.update(
            state="fit",
            score=round(float(score), 3),
            polish="moved" if moved else "kept",
        )
        self._paint_fit_detail = detail
        return ("moved", found) if moved else ("as_is", None)

    def _snap_pose(self, pose: conv.Pose2D) -> None:
        with self._lock:
            self._pose = conv.Pose2D(pose.x, pose.y, pose.theta)
            # The tick already stored the pose it predicted. Leaving it
            # there makes the next sample read this step as motion.
            if self._last_tick_pose is not None:
                self._last_tick_pose = conv.Pose2D(pose.x, pose.y, pose.theta)

    def _snap_pose_yaw(self, yaw: float, *, clear_yaw_rate: bool = False) -> None:
        with self._lock:
            self._pose = conv.Pose2D(self._pose.x, self._pose.y, yaw)
            # The tick already stored the wheel heading. Leaving it there
            # makes the next sample look like another spin.
            if self._last_tick_pose is not None:
                self._last_tick_pose = conv.Pose2D(
                    self._last_tick_pose.x,
                    self._last_tick_pose.y,
                    yaw,
                )
            if clear_yaw_rate:
                self._last_yaw_rate = 0.0

    def _try_recover_heading_for_paint(
        self,
        scan: conv.LaserScan2D,
        scan_pose: conv.Pose2D,
        capture_motion: Optional[conv.Pose2D],
        now: float,
    ) -> bool:
        """Snap yaw to a map-fitting heading so a miss can still paint.

        XY is left alone — translation slip needs revisit / loop closure.
        Returns True when a heading was applied and the caller should paint.
        """
        if now - self._last_heading_recover_at < self._HEADING_RECOVER_MIN_S:
            return False
        self._last_heading_recover_at = now
        kind, polished = self._paint_pose_by_heights(scan_pose)
        if kind == "moved" and polished is not None:
            live = polished
            if capture_motion is not None:
                live = conv.compose_poses(polished, capture_motion)
            self._snap_pose(live)
            self._pose_polishes += 1
            return True
        found, found_score = self._search_heading_for_scan(scan, scan_pose)
        if found is None:
            return False
        live = found
        if capture_motion is not None:
            live = conv.compose_poses(found, capture_motion)
        self._snap_pose_yaw(live.theta)
        self._heading_recovers += 1
        self._log(
            "mapping heading recover "
            f"dtheta={math.degrees(conv.normalize_angle(found.theta - scan_pose.theta)):.1f}deg "
            f"score={found_score:.2f}"
        )
        return True

    def _flush_spin_hold(
        self,
        scan: conv.LaserScan2D,
        now: float,
        capture_motion: Optional[conv.Pose2D],
    ) -> None:
        pose = self._capture_pose(capture_motion)
        held = list(self._spin_hold)
        self._spin_hold = []
        held.append(
            (
                self._copy_scan(scan),
                pose,
                self._copy_frames(self._mapping_frames()),
                now,
            )
        )
        end = pose
        fit = self._scan_map_fit(scan, pose)
        if fit == "miss":
            found, found_score = self._search_heading_for_scan(scan, pose)
            if found is None:
                self._insert_skips_unmatched += len(held)
                self._note_paint("held_unmatched", now, fit="miss")
                self._log(
                    "dropped mapping spin; stopped scan does not match "
                    f"the map (score={found_score:.2f})"
                )
                return
            end = found
            # Spin-held poses are already in the capture frame; paint rewind
            # uses ``end`` directly, so snap the live pose the same way.
            self._snap_pose_yaw(found.theta, clear_yaw_rate=True)
        corrected = rewind_spin_poses([item[1] for item in held], end)
        for (held_scan, _pose, frames, held_now), paint_at in zip(held, corrected):
            self._paint_mapping_scan(held_scan, paint_at, held_now, frames=frames)

    def _paint_mapping_scan(
        self,
        scan: conv.LaserScan2D,
        pose_snap: conv.Pose2D,
        now: float,
        *,
        frames: Optional[list] = None,
    ) -> None:
        """Draw one mapping scan at ``pose_snap``. Caller already decided it fits."""
        scan = self._mask_dynamic_scan(scan, now)
        if frames is None:
            frames = self._mapping_frames()
        with self._lock:
            src = self._grid
            extend_only = not self._baseline_trusted_locked()
            protect = self._session_baseline if extend_only else None
        band_scans = self._band_scans(frames)
        if band_scans:
            band_scans = {
                band: self._mask_dynamic_scan(band_scan, now)
                for band, band_scan in band_scans.items()
            }
        primary_band = 0
        if band_scans:
            painted, bands, primary, extras, primary_band = self._paint_height_bands(
                pose_snap, band_scans, src, extend_only=extend_only, protect=protect
            )
        else:
            painted = occ.insert_scan(
                occ.copy_grid(src),
                pose_snap.x,
                pose_snap.y,
                pose_snap.theta,
                np.asarray(scan.ranges, dtype=float),
                float(scan.angle_min),
                float(scan.angle_increment),
                range_min=float(scan.range_min),
                range_max=float(scan.range_max)
                if math.isfinite(scan.range_max)
                else 30.0,
                extend_only=extend_only,
                protect=protect,
            )
            bands = None
            primary, extras = scan, None
        hook = None
        with self._lock:
            if self._grid is not src:
                return
            self._grid = painted
            if bands is not None:
                self._height_bands = bands
            self._last_insert_pose = pose_snap
            self._last_insert_at = now
            self._updates += 1
            self._note_paint(
                "extend_only" if extend_only else "painting", now, fit="fit"
            )
            if self._mode == MODE_MAPPING:
                hook = self._keyframe_hook
                nodes = len(self._graph)
                self._graph.add_scan(pose_snap, primary, band=primary_band, also=extras)
                if (
                    len(self._graph) > nodes
                    and self._loop_closure_enabled()
                    and now - self._loop_last_attempt_at
                    >= float(self._cfg.builtin_loop_check_interval_s)
                ):
                    self._loop_event.set()
            # The next scan is judged against this paint. Leaving the match
            # grid stale would let a wrong heading draw for another 20 scans.
            self._invalidate_occ_cache()
            if self._updates % 20 == 0:
                self._generation += 1
        if hook is not None:
            try:
                hook(scan, [], pose_snap)
            except Exception as exc:  # noqa: BLE001
                self._log(f"keyframe hook failed: {exc}")

    def _mapping_frames(self) -> list:
        fn = getattr(self._sensors, "mapping_frames", None)
        if not callable(fn):
            return []
        try:
            frames = fn()
        except Exception:  # noqa: BLE001
            return []
        return list(frames or [])

    def _band_scans(self, frames: list) -> dict:
        """Per-height scans when the sensors are not all in one plane."""
        clouds = []
        range_min = 0.05
        range_max = 25.0
        for item in frames:
            scan = item[1] if isinstance(item, tuple) else item
            xyz = getattr(scan, "cloud_xyz", None)
            if xyz is None:
                continue
            pts = np.asarray(xyz, dtype=float)
            if pts.size == 0 or pts.ndim != 2 or pts.shape[1] < 3:
                continue
            clouds.append(pts)
            range_min = min(range_min, float(getattr(scan, "range_min", range_min)))
            limit = float(getattr(scan, "range_max", range_max))
            if math.isfinite(limit):
                range_max = max(range_max, limit)
        if not clouds:
            return {}
        from .height_bands import band_scans

        return band_scans(
            clouds,
            num_bins=int(self._cfg.scan_bins),
            range_min=range_min,
            range_max=range_max,
        )

    def _paint_height_bands(
        self,
        pose: conv.Pose2D,
        scans: dict,
        src: LogOddsGrid,
        *,
        extend_only: bool = False,
        protect: Optional[LogOddsGrid] = None,
    ):
        from .height_bands import compress_bands, cover_bands

        with self._lock:
            bands = {b: occ.copy_grid(g) for b, g in self._height_bands.items()}
            if not bands and np.any(np.abs(src.log_odds) > 0.05):
                bands[0] = occ.copy_grid(src)
        for band, scan in scans.items():
            base = bands.get(band)
            if base is None:
                template = next(iter(bands.values()), src)
                base = LogOddsGrid(
                    log_odds=np.zeros_like(template.log_odds),
                    resolution=template.resolution,
                    origin_x=template.origin_x,
                    origin_y=template.origin_y,
                )
            limit = float(scan.range_max)
            bands[band] = occ.insert_scan(
                base,
                pose.x,
                pose.y,
                pose.theta,
                np.asarray(scan.ranges, dtype=float),
                float(scan.angle_min),
                float(scan.angle_increment),
                range_min=float(scan.range_min),
                range_max=limit if math.isfinite(limit) else 30.0,
                extend_only=extend_only,
                protect=protect,
            )
        bands = cover_bands(bands)
        fused = compress_bands(bands)
        items = list(scans.items())
        primary_band, primary = items[0]
        return fused, bands, primary, items[1:], int(primary_band)

    def _maybe_insert_scan(
        self,
        scan,
        now: float,
        *,
        capture_motion: Optional[conv.Pose2D] = None,
    ) -> None:
        """Ray-cast into the grid only after movement or a timeout.

        The paint runs off the pose lock and in numpy, so GetPosition and the
        nav control loop are not stuck behind a Python Bresenham. The scan is
        painted from the pose it was captured at.
        """
        with self._lock:
            pose = self._pose
            if capture_motion is not None:
                pose = conv.compose_poses(pose, conv.invert_pose(capture_motion))
            last = self._last_insert_pose
            if last is not None:
                moved = math.hypot(pose.x - last.x, pose.y - last.y)
                turned = abs(conv.normalize_angle(pose.theta - last.theta))
                if (
                    moved < 0.03
                    and turned < math.radians(1.5)
                    and now - self._last_insert_at < 1.0
                ):
                    return
            pose_snap = conv.Pose2D(pose.x, pose.y, pose.theta)
        # With lidars at more than one height, paint where the deciding
        # height's walls sit on the map, or not at all.
        kind, polished = self._paint_pose_by_heights(pose_snap)
        if kind == "refuse":
            self._insert_skips_unmatched += 1
            self._note_paint("held_unmatched", now, fit="miss")
            return
        if kind == "moved" and polished is not None:
            live = polished
            if capture_motion is not None:
                live = conv.compose_poses(polished, capture_motion)
            self._snap_pose(live)
            self._pose_polishes += 1
            pose_snap = polished
        self._paint_mapping_scan(scan, pose_snap, now)

    def _poses_agree(self, a: conv.Pose2D, b: conv.Pose2D) -> bool:
        return math.hypot(a.x - b.x, a.y - b.y) <= 0.08 and abs(
            conv.normalize_angle(a.theta - b.theta)
        ) <= math.radians(5.0)

    def _blend_pose(
        self,
        prior: conv.Pose2D,
        target: conv.Pose2D,
        *,
        alpha: float,
        max_xy: float,
        max_yaw: float,
    ) -> conv.Pose2D:
        """Move partially toward ``target`` and clamp the step size."""
        alpha = min(max(alpha, 0.0), 1.0)
        x = prior.x + alpha * (target.x - prior.x)
        y = prior.y + alpha * (target.y - prior.y)
        th = conv.normalize_angle(
            prior.theta + alpha * conv.normalize_angle(target.theta - prior.theta)
        )
        dx = x - prior.x
        dy = y - prior.y
        dist = math.hypot(dx, dy)
        if dist > max_xy and dist > 1e-9:
            scale = max_xy / dist
            x = prior.x + dx * scale
            y = prior.y + dy * scale
        dth = conv.normalize_angle(th - prior.theta)
        if abs(dth) > max_yaw:
            th = conv.normalize_angle(prior.theta + math.copysign(max_yaw, dth))
        return conv.Pose2D(x, y, th)

    # A correction this small is drift tracking, not a peak jump — apply it
    # immediately. Requiring confirmation + tiny clamps for these let odom
    # drift outrun the correction rate (pose "arrived" before the robot).
    _SMALL_CORRECTION_M = 0.15
    _SMALL_CORRECTION_RAD = math.radians(8.0)

    # Continuous local refine is only trusted as drift tracking when the
    # published pose already explains the scan. Below this, odom-only until
    # global_localize / manual seed — otherwise the ±0.3 m window walks
    # toward corridor twins (including while nav is suspended/paused).
    _PRIOR_TRUST_SCORE = 0.15

    # While a goal is active the pose moves by at most a drift-sized step per
    # match, and only when the published pose already fits the scan, the base
    # is not turning hard, and no second wall scores almost as well. A flat
    # corridor ridge ties with a cell 0.4 m away and the margin refuses it.
    _DRIVE_TRUST_SCORE = 0.25
    _RIVAL_MARGIN = 0.08
    # A peak this strong with no rival is a fix even when the prior is lost:
    # the wide refine window found the body up to ~0.6 m from its pose.
    _RECOVER_MIN_SCORE = 0.45

    def _peak_is_unique(self) -> bool:
        """True when no other wall in the window scores close to the winner.

        A window with one blob (or no recorded search) counts as unique.
        """
        best = float(self._last_match_score)
        rival = float(self._last_match_rival_score)
        if not math.isfinite(best) or not math.isfinite(rival):
            return True
        return best - rival >= self._RIVAL_MARGIN

    def _match_is_strong(self) -> bool:
        score = float(self._last_match_score)
        return (
            math.isfinite(score)
            and score >= self._RECOVER_MIN_SCORE
            and self._peak_is_unique()
        )

    def _calm_for_correction(self) -> bool:
        """A smeared turning scan is never applied."""
        return float(self._last_yaw_rate) <= _SPIN_HOLD_YAW_RATE

    def _navigation_active(self) -> bool:
        """True when builtin nav has an in-flight goal (MoveOnMap / route)."""
        try:
            from ..runtime import any_navigation_active

            return bool(any_navigation_active())
        except Exception:  # noqa: BLE001 - registry may be mid-reconfigure
            return False

    # Heading-only step while driving. Lower score floor than a full match:
    # XY may be off by a corridor length while the walls still fix the yaw.
    # Each apply turns the pose a few degrees so the controller sees a drift,
    # not a kick.
    _YAW_ONLY_MIN_SCORE = 0.20
    _YAW_ONLY_MAX_RAD = math.radians(24.0)
    _YAW_ONLY_STEP_RAD = math.radians(4.0)
    _YAW_ONLY_ALPHA = 0.5

    def _yaw_only_fix(
        self, occ_map, scan: conv.LaserScan2D, scan_pose: conv.Pose2D
    ) -> Optional[tuple]:
        """``(dyaw, best, prior, rival)`` from a heading search at the scan pose."""
        try:
            yaw, best, prior, rival = scan_match.refine_yaw(
                occ_map,
                scan,
                scan_pose,
                occupied_lookup=self._occupied_lookup_for(occ_map),
            )
        except Exception:  # noqa: BLE001 - diagnostics only; never stall the tick
            return None
        if yaw is None:
            return None
        return (conv.normalize_angle(yaw - scan_pose.theta), best, prior, rival)

    def _apply_yaw_only(self, predicted: conv.Pose2D, yaw_fix: tuple) -> bool:
        dyaw, best, prior, rival = yaw_fix
        if not math.isfinite(best) or best < self._YAW_ONLY_MIN_SCORE:
            return False
        if abs(dyaw) > self._YAW_ONLY_MAX_RAD:
            return False
        if math.isfinite(rival) and best - rival < self._RIVAL_MARGIN:
            return False
        if math.isfinite(prior) and best < prior + scan_match._required_improvement(  # noqa: SLF001
            prior, 0.0, dyaw
        ):
            return False
        step = max(
            -self._YAW_ONLY_STEP_RAD,
            min(self._YAW_ONLY_STEP_RAD, self._YAW_ONLY_ALPHA * dyaw),
        )
        if abs(step) < math.radians(0.25):
            return False
        self._pose = conv.Pose2D(
            predicted.x, predicted.y, conv.normalize_angle(predicted.theta + step)
        )
        self._yaw_only_applies += 1
        return True

    def _note_yaw_correction(self, predicted: conv.Pose2D) -> None:
        """Signed yaw the scan just pulled the pose by (heading drift ledger)."""
        d = conv.normalize_angle(self._pose.theta - predicted.theta)
        if self._yaw_corr_since is None:
            self._yaw_corr_since = time.monotonic()
        self._yaw_corr_sum += d
        self._yaw_corr_count += 1

    def _reset_yaw_ledger(self) -> None:
        self._yaw_corr_sum = 0.0
        self._yaw_corr_count = 0
        self._yaw_corr_since = None

    def _heading_diagnostics(self) -> dict:
        """How the heading sensor and the scan have disagreed since the seed.

        ``bias_deg_s`` is the net yaw the scan has corrected per second; a
        steady value is a gyro/heading bias the odometry carries, and its
        sign says which way the sensor under-reads.
        """
        elapsed = None
        bias = None
        if self._yaw_corr_since is not None:
            elapsed = max(0.0, time.monotonic() - self._yaw_corr_since)
            if elapsed >= 30.0:
                bias = math.degrees(self._yaw_corr_sum) / elapsed
        return {
            "snaps_rejected": self._heading_snaps,
            "scan_corrections": self._yaw_corr_count,
            "scan_corrected_deg": round(math.degrees(self._yaw_corr_sum), 2),
            "window_s": None if elapsed is None else round(elapsed, 1),
            "bias_deg_s": None if bias is None else round(bias, 4),
        }

    def set_match_outcome_hook(self, hook) -> None:
        self._match_outcome_hook = hook

    def set_anchor_motion_hook(self, hook) -> None:
        """``hook(old_poses, new_poses)`` after a pose-graph node moves.

        Camera keyframes anchored to that node follow the same motion. The
        hook must not call back into the engine.
        """
        self._anchor_motion_hook = hook

    def _node_poses_locked(self) -> dict:
        return {
            i: conv.Pose2D(float(n.pose.x), float(n.pose.y), float(n.pose.theta))
            for i, n in enumerate(self._graph.nodes)
        }

    def _emit_anchor_motion(self, old: dict, new: dict) -> None:
        hook = self._anchor_motion_hook
        if hook is None or not old:
            return
        changed = False
        for i, prev in old.items():
            cur = new.get(i)
            if cur is None:
                continue
            if (
                abs(prev.x - cur.x) > 1e-6
                or abs(prev.y - cur.y) > 1e-6
                or abs(conv.normalize_angle(prev.theta - cur.theta)) > 1e-6
            ):
                changed = True
                break
        if not changed:
            return
        try:
            hook(old, new)
        except Exception as exc:  # noqa: BLE001
            self._log(f"anchor motion hook failed: {exc}")

    def _emit_match_outcome(self, result: dict) -> None:
        hook = self._match_outcome_hook
        if hook is None:
            return
        try:
            hook(result)
        except Exception:  # noqa: BLE001
            pass

    def _note_match_outcome(
        self,
        *,
        applied: bool,
        matched: Optional[conv.Pose2D],
        score: float,
        prior_score: float,
    ) -> None:
        """Split match results so UI does not treat 'prior already good' as reject."""
        if applied:
            self._match_accepts += 1
            self._emit_match_outcome(
                {
                    "status": "corrected",
                    "corrected": True,
                    "score": score,
                    "prior_score": prior_score,
                }
            )
            return
        # Held: usable prior / candidate that we chose not to apply. Failed:
        # no peak or dead score (real miss).
        prior_ok = math.isfinite(prior_score) and prior_score >= 0.35
        score_ok = math.isfinite(score)
        if matched is not None or (prior_ok and score_ok):
            self._match_held += 1
            # Published pose already fits the scan — not lost. Watchdog
            # nav_hold / low_quality must not keep advertising lost while
            # every tick is holding for this reason.
            if prior_ok and score_ok:
                self._emit_match_outcome(
                    {
                        "status": "previous_better",
                        "score": score if score_ok else prior_score,
                        "prior_score": prior_score,
                    }
                )
            return
        self._match_failed += 1

    def _apply_match(
        self,
        predicted: conv.Pose2D,
        matched: Optional[conv.Pose2D],
        odom: Optional[conv.OdomReading],
        *,
        yaw_fix: Optional[tuple] = None,
    ) -> bool:
        """Apply a blended match. Returns True if pose was corrected.

        ``yaw_fix`` is the heading-only search for this scan; while driving it
        is applied whenever the full match is held, so a heading slip closes
        even when the position along a corridor cannot be trusted.
        """
        del odom  # prediction is delta-based; no map->odom re-anchor needed
        driving = self._navigation_active()
        if self._apply_full_match(predicted, matched, driving):
            self._note_yaw_correction(predicted)
            return True
        if (
            driving
            and yaw_fix is not None
            and self._calm_for_correction()
            and self._apply_yaw_only(predicted, yaw_fix)
        ):
            self._note_yaw_correction(predicted)
            return True
        return False

    def _apply_full_match(
        self,
        predicted: conv.Pose2D,
        matched: Optional[conv.Pose2D],
        driving: bool,
    ) -> bool:
        if matched is None:
            return self._hold(predicted)

        # A scan taken mid-spin is smeared and lags the wheels; matching it
        # pulls the heading back toward where the turn started. Odometry
        # carries the turn and the first still scan settles it.
        if not self._calm_for_correction():
            return self._hold(predicted)
        # During MoveOnMap / routes the pose keeps following odometry and a
        # match may pull it back by a drift-sized step. A wide sideways search
        # applied while driving once walked the pose onto a parallel wall, so
        # a driving step needs a fitting prior (or a strong lone peak) and a
        # winner with no rival.

        dist = math.hypot(matched.x - predicted.x, matched.y - predicted.y)
        dyaw = abs(conv.normalize_angle(matched.theta - predicted.theta))
        small = dist <= self._SMALL_CORRECTION_M and dyaw <= self._SMALL_CORRECTION_RAD
        prior = float(self._last_prior_score)
        prior_ok = math.isfinite(prior) and prior >= self._PRIOR_TRUST_SCORE
        strong = self._match_is_strong()

        if small:
            # Bad prior while idle/paused: never creep toward twins.
            if not prior_ok:
                return self._hold(predicted)
            if driving and not (
                prior >= self._DRIVE_TRUST_SCORE and self._peak_is_unique()
            ):
                return self._hold(predicted)
            # Continuous drift correction: no confirmation needed.
            self._pending_match = None
            self._pending_count = 0
            self._pose = self._blend_pose(
                predicted,
                matched,
                alpha=0.6,
                max_xy=self._SMALL_CORRECTION_M,
                max_yaw=self._SMALL_CORRECTION_RAD,
            )
            if driving:
                self._drive_applies += 1
            return True

        # Large jump: a lone peak and two agreeing frames, from a trusted prior
        # or, when the prior is lost, a strong match. While driving only the
        # strong case applies, walked in at the drift step so the controller
        # sees no jump. Two near-equal peaks are a twin, never a direction.
        if not self._peak_is_unique():
            return self._hold(predicted)
        if not prior_ok and not strong:
            return self._hold(predicted)
        if driving and not strong:
            return self._hold(predicted)

        if self._pending_match is not None and self._poses_agree(
            matched, self._pending_match
        ):
            self._pending_count += 1
            self._pending_match = matched
        else:
            self._pending_match = matched
            self._pending_count = 1

        if self._pending_count < 2:
            self._pose = predicted
            return False

        if driving:
            max_xy = self._SMALL_CORRECTION_M
            max_yaw = self._SMALL_CORRECTION_RAD
            self._drive_applies += 1
        else:
            max_xy = 0.25
            max_yaw = math.radians(12.0)
        self._pose = self._blend_pose(
            predicted, matched, alpha=0.6, max_xy=max_xy, max_yaw=max_yaw
        )
        # Keep the streak so a persistent target keeps applying every match.
        self._pending_count = 2
        return True

    def _hold(self, predicted: conv.Pose2D) -> bool:
        """Stay on odometry and forget any half-confirmed jump."""
        self._pending_match = None
        self._pending_count = 0
        self._pose = predicted
        return False

    # Ignore accel smaller than this so gravity leftover and sensor noise do
    # not walk the pose while the cart is sitting still.
    _ACCEL_DEADBAND_M_S2 = 0.20
    _ACCEL_SPEED_MAX_M_S = 0.8
    # How fast a constant reading is absorbed into the baseline. A parked
    # tilt must not keep integrating; a real shove stays ahead of this.
    _ACCEL_BIAS_TAU_S = 1.5
    # A resting gyro faster than this is a real turn. Slower rates are the
    # IMU's zero (Wit already near 0, Livox a small bias) and do not turn.
    _YAW_STILL_RAD_S = math.radians(5.0)
    # Seed the resting yaw rate from the first sample only when it is modest.
    # A cart that powers on already spinning is not treated as bias.
    _YAW_BIAS_SEED_MAX_RAD_S = math.radians(30.0)

    def _imu_yaw_delta(self, dth: float, dt: float) -> float:
        """Yaw step for an IMU-only cart.

        The first modest gyro rate is that IMU's zero (a Wit sits near 0; a
        Livox can sit on a bias). Only a change above the still threshold
        turns the pose, so a parked cart does not rotate to a new heading.
        """
        rate = dth / dt if dt > 0.0 else 0.0
        if self._imu_yaw_bias is None and abs(rate) <= self._YAW_BIAS_SEED_MAX_RAD_S:
            self._imu_yaw_bias = rate
        bias = 0.0 if self._imu_yaw_bias is None else self._imu_yaw_bias
        residual = rate - bias
        if abs(residual) <= self._YAW_STILL_RAD_S:
            if self._imu_yaw_bias is not None:
                self._imu_yaw_bias += residual * (1.0 - math.exp(-dt / 2.0))
            return 0.0
        return residual * dt

    def _twist_with_accel_prior(
        self, odom: conv.OdomReading, dt: float
    ) -> tuple[float, float]:
        """Body twist for one predict step.

        Wheel velocity is used as reported. With ``imu_odom_mode=accel_only``
        and no wheel speed, a *change* in forward acceleration (``ax`` after
        the IMU mount yaw) is integrated into a short-lived forward speed.
        The steady reading, including gravity left over from a tilt, is the
        baseline and does not move the pose. When the reading returns to that
        baseline the speed is dropped, so stopping does not coast. Lateral
        accel is ignored.
        """
        vx, vy = float(odom.vx), float(odom.vy)
        if getattr(self._cfg, "imu_odom_mode", "") != IMU_ODOM_ACCEL_ONLY:
            return vx, vy
        if odom.ax is None or odom.ay is None:
            return vx, vy
        if abs(vx) > 1e-3 or abs(vy) > 1e-3:
            self._imu_forward_m_s = 0.0
            self._imu_ax_bias = None
            self._imu_yaw_bias = None
            return vx, vy
        ax = float(odom.ax)
        if self._imu_ax_bias is None:
            self._imu_ax_bias = ax
        residual = ax - self._imu_ax_bias
        # Always pull the baseline toward the reading. A resting offset bigger
        # than the deadband (Livox tilt) must be absorbed; otherwise it is
        # integrated forever and the parked cart slides. A short shove stays
        # ahead of this slow follow.
        self._imu_ax_bias += residual * (1.0 - math.exp(-dt / self._ACCEL_BIAS_TAU_S))
        residual = ax - self._imu_ax_bias
        if abs(residual) < self._ACCEL_DEADBAND_M_S2:
            self._imu_forward_m_s = 0.0
            speed = 0.0
        else:
            speed = self._imu_forward_m_s + residual * dt
            speed = max(
                -self._ACCEL_SPEED_MAX_M_S, min(self._ACCEL_SPEED_MAX_M_S, speed)
            )
            self._imu_forward_m_s = speed
        if (
            getattr(self._cfg, "base_velocity_convention", "viam")
            in BASE_VELOCITY_Y_FORWARD
        ):
            return 0.0, speed
        return speed, 0.0

    # Matches ``TypedMovementSensorOdom.MAX_HOLD_GAP_S``. Past this the reader stops
    # inventing motion from the last twist, so a stalled read cannot justify
    # more yaw than that hold either.
    _ODOM_YAW_HOLD_MAX_S = 3.0
    # Fastest turn either cart makes. A heading step past this rate over one
    # sample (at least one nominal period, at most this window) is a sensor
    # snap, not the body turning: 35° in 0.1 s is 350°/s.
    _MAX_BODY_YAW_RATE = math.radians(120.0)
    _YAW_STEP_WINDOW_S = 0.5

    def _plausible_yaw_step(self, gap_s: float, prev_yaw_rate: float) -> float:
        """Most yaw one odom sample can honestly carry.

        The body's top rate over the sample gap (never less than a nominal
        period, never more than half a second), or the turn already underway
        held across a stalled read for as long as the reader holds it.
        """
        gap = max(0.0, float(gap_s))
        window = min(max(gap, self._period), self._YAW_STEP_WINDOW_S)
        hold = min(gap, self._ODOM_YAW_HOLD_MAX_S)
        return max(self._MAX_BODY_YAW_RATE * window, abs(prev_yaw_rate) * hold)

    def _predict(self, odom: Optional[conv.OdomReading], now: float) -> conv.Pose2D:
        if odom is None:
            return self._pose

        if odom.pose is not None:
            # Absolute odom pose: apply the *relative* motion since the last
            # sample onto the current map pose. Composing map_to_odom with the
            # absolute pose let IMU/magnetometer heading snaps (merged into
            # odom pose theta) teleport the map pose every tick — the source
            # of correct↔wrong pose flapping.
            prev = self._last_odom_pose
            prev_at = self._last_odom_pose_at
            self._last_odom_pose = odom.pose
            self._last_odom_pose_at = now
            self._last_odom_time = now
            # Rate from the sample before this one: the turn already underway.
            # This sample's own vtheta can arrive with a heading snap.
            prev_yaw_rate = abs(float(self._last_odom_twist[2]))
            self._last_odom_twist = (odom.vx, odom.vy, odom.vtheta)
            self._imu_forward_m_s = 0.0
            self._imu_ax_bias = None
            self._imu_yaw_bias = None
            if prev is None:
                if odom.heading_rad is not None:
                    self._last_odom_heading = odom.heading_rad
                elif odom.pose is not None:
                    self._last_odom_heading = odom.pose.theta
                return self._pose
            delta = conv.compose_poses(conv.invert_pose(prev), odom.pose)
            gap_s = (now - prev_at) if prev_at is not None else 0.0
            max_yaw = self._plausible_yaw_step(gap_s, prev_yaw_rate)
            # Prefer dedicated heading_sensor deltas for yaw so velocity-only
            # wheel odom does not dead-reckon heading from gyro vtheta alone.
            # A step the body cannot have turned is a magnetometer snap; the
            # wheel delta stands in for it.
            if odom.heading_rad is not None:
                if self._last_odom_heading is not None:
                    heading_delta = conv.normalize_angle(
                        odom.heading_rad - self._last_odom_heading
                    )
                    if abs(heading_delta) <= max_yaw:
                        delta = conv.Pose2D(delta.x, delta.y, heading_delta)
                    else:
                        self._heading_snaps += 1
                self._last_odom_heading = odom.heading_rad
            else:
                self._last_odom_heading = odom.pose.theta
            # Gate implausible jumps (heading snap, odom reset). Translation
            # scales with the gap because the reader zero-order-holds the last
            # twist across it. Yaw does not: the most a missed sample can
            # honestly contain is the turn already underway, and only for as
            # long as that hold lasts. A parked cart cannot absorb a
            # magnetometer flip just because the read was late.
            max_xy = max(0.5, 0.6 * gap_s)
            if math.hypot(delta.x, delta.y) > max_xy or abs(delta.theta) > max_yaw:
                self._log(
                    "builtin SLAM: rejected odom jump "
                    f"dx={delta.x:.2f} dy={delta.y:.2f} "
                    f"dth={math.degrees(delta.theta):.0f}deg"
                )
                return self._pose
            return conv.compose_poses(self._pose, delta)

        # Twist integration in the *map* frame. Never snap map yaw to an
        # absolute IMU/magnetometer heading — that frame is not map-aligned
        # and was yanking localization after every tick.
        dt = 0.0
        gap_s = 0.0
        if self._last_odom_time is not None:
            gap_s = max(0.0, now - self._last_odom_time)
            dt = min(gap_s, 0.5)
        self._last_odom_time = now
        prev_yaw_rate = abs(float(self._last_odom_twist[2]))
        if dt <= 0.0:
            if odom.heading_rad is not None and self._last_odom_heading is None:
                self._last_odom_heading = odom.heading_rad
            self._last_odom_twist = (odom.vx, odom.vy, odom.vtheta)
            return self._pose

        dth = odom.vtheta * dt
        if odom.heading_rad is not None:
            if self._last_odom_heading is not None:
                heading_delta = conv.normalize_angle(
                    odom.heading_rad - self._last_odom_heading
                )
                # Reject magnetometer jumps; fall back to gyro integration.
                if abs(heading_delta) <= self._plausible_yaw_step(gap_s, prev_yaw_rate):
                    dth = heading_delta
                else:
                    self._heading_snaps += 1
            self._last_odom_heading = odom.heading_rad

        if (
            getattr(self._cfg, "imu_odom_mode", "") == IMU_ODOM_ACCEL_ONLY
            and abs(float(odom.vx)) <= 1e-3
            and abs(float(odom.vy)) <= 1e-3
        ):
            dth = self._imu_yaw_delta(dth, dt)

        if self._lidar_odom_active(odom):
            self._yaw_check_gyro += float(odom.vtheta) * dt
        c = math.cos(self._pose.theta)
        s = math.sin(self._pose.theta)
        if self._lidar_odom_active(odom) and self._lidar_odom_fresh(now):
            fwd, left = self._lidar_odom_twist(now, dt)
            if (
                getattr(self._cfg, "base_velocity_convention", "viam")
                in BASE_VELOCITY_Y_FORWARD
            ):
                self._last_odom_twist = (-left, fwd, odom.vtheta)
            else:
                self._last_odom_twist = (fwd, left, odom.vtheta)
            return conv.Pose2D(
                self._pose.x + (c * fwd - s * left) * dt,
                self._pose.y + (s * fwd + c * left) * dt,
                conv.normalize_angle(self._pose.theta + dth),
            )

        vx, vy = self._twist_with_accel_prior(odom, dt)
        self._last_odom_twist = (vx, vy, odom.vtheta)
        if (
            getattr(self._cfg, "base_velocity_convention", "viam")
            in BASE_VELOCITY_Y_FORWARD
        ):
            # Sensor-native Y-forward / X-right → map (theta=0 faces +X).
            dx = (c * vy + s * vx) * dt
            dy = (s * vy - c * vx) * dt
        else:
            dx = (c * vx - s * vy) * dt
            dy = (s * vx + c * vy) * dt
        return conv.Pose2D(
            self._pose.x + dx,
            self._pose.y + dy,
            conv.normalize_angle(self._pose.theta + dth),
        )
