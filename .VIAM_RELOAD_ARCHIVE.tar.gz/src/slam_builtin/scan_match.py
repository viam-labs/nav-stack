"""Local correlative scan-to-map matching for continuous tracking."""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import List, Mapping, Optional, Tuple

import numpy as np

from ..geom import conversions as conv
from ..nav.localize.global_localize import (
    OccupancyMap,
    _inflate_occupied,
    _score_pose,
    scan_endpoints_base_link,
)


def occupancy_map_from_int16(
    grid: np.ndarray,
    *,
    resolution: float,
    origin_x: float,
    origin_y: float,
) -> OccupancyMap:
    return OccupancyMap(
        grid=np.asarray(grid, dtype=np.int16),
        resolution=float(resolution),
        origin_x=float(origin_x),
        origin_y=float(origin_y),
    )


# Endpoints within this many cells of a wall count as hits.
_INFLATE_CELLS = 2


def occupied_lookup(
    occ_map: OccupancyMap, inflate_cells: int = _INFLATE_CELLS
) -> np.ndarray:
    """Dilated wall mask every matcher here scores against.

    A full-grid dilation per call was the single largest cost of the SLAM tick
    (``scan_map_fit`` runs on every scan, ``refine_pose`` on every match). The
    engine computes this once per occupancy-cache epoch and passes it in.
    """
    return _inflate_occupied(occ_map.grid >= 50, int(inflate_cells))


def _lookup_or_build(
    occ_map: OccupancyMap,
    lookup: Optional[np.ndarray],
    inflate_cells: int = _INFLATE_CELLS,
) -> np.ndarray:
    if lookup is not None and lookup.shape == occ_map.grid.shape:
        return lookup
    return occupied_lookup(occ_map, inflate_cells)


def score_pose(
    occ_map: OccupancyMap,
    scan_xy: np.ndarray,
    pose: conv.Pose2D,
    *,
    occupied_lookup: np.ndarray,
) -> float:
    return _score_pose(
        occ_map,
        scan_xy,
        pose,
        occupied_lookup=occupied_lookup,
        min_in_map_points=20,
        min_in_map_ratio=0.2,
    ).score


def _required_improvement(prior_score: float, dist_m: float, dyaw_rad: float) -> float:
    """Larger jumps and already-good priors need a clearer score win.

    Prevents A↔B peak flipping when two discrete poses score within noise.
    Kept mild: odom drift is real and must stay correctable — an overly
    strict bar let the pose run ahead of the robot (goals "reached" early)
    until a manual refine snapped it back.
    """
    base = 0.06 if prior_score >= 0.25 else 0.03
    return base + 0.10 * dist_m + 0.08 * (abs(dyaw_rad) / (math.pi / 4.0))


# Fewer judged beams than this and the map cannot say anything about the
# pose. Off-grid and unknown cells are the same thing here: not yet mapped.
_MIN_KNOWN_POINTS = 20
_MIN_KNOWN_RATIO = 0.2
# A candidate may judge this much less of the scan than the prior. Any more
# and it is winning by moving its misses into unmapped space.
_COVERAGE_SHED = 0.05


def _candidate_scores_with_coverage(
    occ_map: OccupancyMap,
    scan_xy: np.ndarray,
    cand_x: np.ndarray,
    cand_y: np.ndarray,
    yaw: float,
    *,
    occupied_lookup: np.ndarray,
    min_known_points: int = _MIN_KNOWN_POINTS,
    min_known_ratio: float = _MIN_KNOWN_RATIO,
) -> Tuple[np.ndarray, np.ndarray]:
    """Score and coverage for many XY origins at one yaw.

    The score is the fraction of *judged* beams the map explains: endpoints
    on a wall count +1, endpoints in known free space -0.7, and beams that
    land in unknown or off-grid cells do not count either way. Dividing by
    the judged beams keeps a pose at the edge of the explored area on the
    same scale as one in a finished room; the old form divided by every beam
    inside the grid, so a pose that saw half unexplored space could score at
    most 0.5 and every threshold meant something different there.

    ``coverage`` is the judged fraction of the whole scan. Callers compare it
    against the prior's so a candidate cannot win by shedding beams.

    The engine calls this at ~10 Hz from a background thread; a Python loop
    over thousands of candidates starved the module event loop (nav drive
    RPCs were timing out), so all candidates are scored with numpy at once.
    """
    c = math.cos(yaw)
    s = math.sin(yaw)
    rx = c * scan_xy[:, 0] - s * scan_xy[:, 1]
    ry = s * scan_xy[:, 0] + c * scan_xy[:, 1]

    # (n_candidates, n_points)
    wx = cand_x[:, None] + rx[None, :]
    wy = cand_y[:, None] + ry[None, :]

    grid = occ_map.grid
    height, width = grid.shape
    res = occ_map.resolution
    cols = np.floor((wx - occ_map.origin_x) / res).astype(np.int32)
    rows = np.floor((wy - occ_map.origin_y) / res).astype(np.int32)
    inside = (rows >= 0) & (rows < height) & (cols >= 0) & (cols < width)
    rows_c = np.clip(rows, 0, height - 1)
    cols_c = np.clip(cols, 0, width - 1)

    cells = grid[rows_c, cols_c]
    hits = occupied_lookup[rows_c, cols_c] & inside
    # Any mapped cell that is not itself a wall counts against the beam that
    # ends there, including the mid-probability band the map has only seen
    # through once (leaving it out let a heading 30° wrong score 0.9 on the
    # few beams that still crossed a wall) and the inflated ring around a
    # wall (a beam there is near a wall, +1 - 0.7, which is the gradient
    # that pulls the peak onto the wall cells themselves).
    free = (cells >= 0) & (cells < 50) & inside
    known = hits | free

    total = scan_xy.shape[0]
    n_known = known.sum(axis=1)
    denom = np.maximum(n_known, 1)
    scores = (hits.sum(axis=1) - 0.7 * free.sum(axis=1)) / denom
    coverage = n_known / float(max(total, 1))
    min_points = max(min_known_points, int(total * min_known_ratio))
    scores[n_known < min_points] = float("-inf")
    return scores, coverage


def _candidate_scores(
    occ_map: OccupancyMap,
    scan_xy: np.ndarray,
    cand_x: np.ndarray,
    cand_y: np.ndarray,
    yaw: float,
    *,
    occupied_lookup: np.ndarray,
    min_coverage: float = 0.0,
) -> np.ndarray:
    """Scores only; candidates judging less than ``min_coverage`` are ``-inf``."""
    scores, coverage = _candidate_scores_with_coverage(
        occ_map, scan_xy, cand_x, cand_y, yaw, occupied_lookup=occupied_lookup
    )
    if min_coverage > 0.0:
        scores[coverage < min_coverage] = float("-inf")
    return scores


def _prior_score_and_coverage(
    occ_map: OccupancyMap,
    scan_xy: np.ndarray,
    pose: conv.Pose2D,
    *,
    occupied_lookup: np.ndarray,
) -> Tuple[float, float]:
    scores, coverage = _candidate_scores_with_coverage(
        occ_map,
        scan_xy,
        np.array([pose.x]),
        np.array([pose.y]),
        pose.theta,
        occupied_lookup=occupied_lookup,
    )
    return float(scores[0]), float(coverage[0])


# Farther than this from the winning cell, a high score is a second wall
# rather than the same peak sampled on the next grid point.
_RIVAL_SEP_M = 0.40


def scan_map_fit(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    pose: conv.Pose2D,
    *,
    min_score: float = 0.5,
    occupied_lookup: Optional[np.ndarray] = None,
) -> str:
    """``open`` when the map cannot judge ``pose``, else ``fit`` or ``miss``.

    Unknown cells do not count. A heading that drops returns into empty space
    the map already knows is a miss, even if part of the scan is new ground.
    ``occupied_lookup`` is the cached ``occupied_lookup(occ_map)``.
    """
    return scan_map_overlap(
        occ_map, scan, pose, min_score=min_score, occupied_lookup=occupied_lookup
    )[0]


def scan_map_overlap(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    pose: conv.Pose2D,
    *,
    min_score: float = 0.5,
    occupied_lookup: Optional[np.ndarray] = None,
) -> Tuple[str, float]:
    """:func:`scan_map_fit` with the score it was decided on (NaN for ``open``)."""
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return "open", float("nan")
    c = math.cos(pose.theta)
    s = math.sin(pose.theta)
    wx = pose.x + c * scan_xy[:, 0] - s * scan_xy[:, 1]
    wy = pose.y + s * scan_xy[:, 0] + c * scan_xy[:, 1]
    grid = occ_map.grid
    height, width = grid.shape
    res = occ_map.resolution
    cols = np.floor((wx - occ_map.origin_x) / res).astype(np.int32)
    rows = np.floor((wy - occ_map.origin_y) / res).astype(np.int32)
    inside = (rows >= 0) & (rows < height) & (cols >= 0) & (cols < width)
    if int(inside.sum()) < 20:
        return "open", float("nan")
    rows_c = np.clip(rows, 0, height - 1)
    cols_c = np.clip(cols, 0, width - 1)
    lookup = _lookup_or_build(occ_map, occupied_lookup)
    hits = lookup[rows_c, cols_c] & inside
    free = (grid[rows_c, cols_c] >= 0) & (grid[rows_c, cols_c] < 50) & inside
    known = hits | free
    n_known = int(known.sum())
    if n_known / float(inside.sum()) < 0.25:
        return "open", float("nan")
    # Score only the beams the map can judge. Points past the edge or in
    # unknown cells are how the map grows; they must not veto a scan whose
    # overlap hits walls.
    overlap = (float(hits.sum()) - 0.7 * float(free.sum())) / float(n_known)
    return ("fit" if overlap >= min_score else "miss"), overlap


# A height's vote counts a return as on a wall only within this many cells.
# The wider ring the matcher uses gives a return two cells out partial
# credit, which is a gradient for a search and too soft for a yes or no.
_VOTE_TOLERANCE_CELLS = 1
# A height with fewer returns than this share of the fullest height is too
# thin a view to vote (one slice of a depth camera). The count is of
# returns, not of returns the map could judge: at a pose that is off, a
# height's wall returns slip behind the walls into unmapped space while
# another height's furniture returns stay judged, and the clean height must
# not lose its vote for that.
_VOTE_MIN_SHARE = 0.5


@dataclass(frozen=True)
class HeightVote:
    """How well the returns at one height sit on the map at a pose."""

    band: int
    score: float
    judged: int


def wall_agreement(
    occ_map: OccupancyMap, scan: conv.LaserScan2D, pose: conv.Pose2D
) -> Tuple[float, int]:
    """Score and judged-return count for ``scan`` at ``pose``.

    Of the returns that land where the map knows something: +1 for each
    within a cell of a wall, -0.7 for each in free space farther from every
    wall than that. ``(nan, 0)`` when too little of the scan lands on mapped
    ground to judge, by the same limits as :func:`scan_map_fit`.
    """
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return float("nan"), 0
    c = math.cos(pose.theta)
    s = math.sin(pose.theta)
    wx = pose.x + c * scan_xy[:, 0] - s * scan_xy[:, 1]
    wy = pose.y + s * scan_xy[:, 0] + c * scan_xy[:, 1]
    grid = occ_map.grid
    height, width = grid.shape
    res = occ_map.resolution
    cols = np.floor((wx - occ_map.origin_x) / res).astype(np.int32)
    rows = np.floor((wy - occ_map.origin_y) / res).astype(np.int32)
    inside = (rows >= 0) & (rows < height) & (cols >= 0) & (cols < width)
    n_inside = int(inside.sum())
    if n_inside < 20:
        return float("nan"), 0
    # Look around each return instead of dilating the whole grid: a few
    # hundred returns, against a grid of a million cells.
    near = np.zeros(scan_xy.shape[0], dtype=bool)
    reach = range(-_VOTE_TOLERANCE_CELLS, _VOTE_TOLERANCE_CELLS + 1)
    for dr in reach:
        for dc in reach:
            r = rows + dr
            col = cols + dc
            ok = (r >= 0) & (r < height) & (col >= 0) & (col < width)
            cells = grid[np.clip(r, 0, height - 1), np.clip(col, 0, width - 1)]
            near |= ok & (cells >= 50)
    near &= inside
    own = grid[np.clip(rows, 0, height - 1), np.clip(cols, 0, width - 1)]
    free = (own >= 0) & (own < 50) & inside & ~near
    judged = int(near.sum() + free.sum())
    if judged / float(n_inside) < 0.25:
        return float("nan"), 0
    return (float(near.sum()) - 0.7 * float(free.sum())) / float(judged), judged


def polish_on_walls(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    pose: conv.Pose2D,
    *,
    xy_half_m: float = 0.075,
    xy_step_m: float = 0.025,
    yaw_half_deg: float = 2.0,
    yaw_step_deg: float = 1.0,
) -> Tuple[Optional[conv.Pose2D], float, float]:
    """Best pose within a few centimetres of ``pose``, by :func:`wall_agreement`.

    The pose matcher steps in 5 cm and 2 degrees and stops short of its
    target on purpose, so it leaves a residue about that size. A height vote
    only credits returns within a cell of a wall, and that residue is enough
    to fail it on sparse walls. This closes the gap with the vote's own
    score.

    Returns ``(pose, score, edge_gain)``. ``pose`` is the best candidate
    strictly inside the window. ``edge_gain`` is how much better the best
    candidate on the window's edge scores than that: a clear gain means the
    scan fits better still farther out, so the pose is off by more than a
    polish should fix and painting here would draw the walls part-way to
    where they belong. Along a corridor the fit barely changes with position,
    so a small gain there is not that.

    A candidate may not judge fewer returns than ``pose`` does (it would be
    winning by moving its misses into unmapped space), and among near-equal
    candidates the one closest to ``pose`` is kept, so a wall that fits
    anywhere along its length does not slide the pose.
    """
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return None, float("nan"), 0.0
    _score_here, judged_here = wall_agreement(occ_map, scan, pose)
    if judged_here <= 0:
        return None, float("nan"), 0.0
    grid = occ_map.grid
    height, width = grid.shape
    res = occ_map.resolution
    # One dilation of the grid, then one lookup per return and candidate.
    near_wall = _inflate_occupied(grid >= 50, _VOTE_TOLERANCE_CELLS)
    known_free = (grid >= 0) & (grid < 50)
    offsets = np.arange(-xy_half_m, xy_half_m + 1e-9, xy_step_m)
    ox, oy = np.meshgrid(offsets, offsets)
    ox, oy = ox.ravel(), oy.ravel()
    yaws = np.radians(np.arange(-yaw_half_deg, yaw_half_deg + 1e-9, yaw_step_deg))
    edge_xy = xy_half_m - 0.5 * xy_step_m
    edge_yaw = math.radians(yaw_half_deg - 0.5 * yaw_step_deg)
    floor = judged_here * (1.0 - _COVERAGE_SHED)
    inner = []
    edge_top = float("-inf")
    for dyaw in yaws:
        yaw = pose.theta + float(dyaw)
        c, s = math.cos(yaw), math.sin(yaw)
        rx = c * scan_xy[:, 0] - s * scan_xy[:, 1]
        ry = s * scan_xy[:, 0] + c * scan_xy[:, 1]
        cols = np.floor(
            (pose.x + ox[:, None] + rx[None, :] - occ_map.origin_x) / res
        ).astype(np.int32)
        rows = np.floor(
            (pose.y + oy[:, None] + ry[None, :] - occ_map.origin_y) / res
        ).astype(np.int32)
        inside = (rows >= 0) & (rows < height) & (cols >= 0) & (cols < width)
        rows_c = np.clip(rows, 0, height - 1)
        cols_c = np.clip(cols, 0, width - 1)
        near = near_wall[rows_c, cols_c] & inside
        free = known_free[rows_c, cols_c] & inside & ~near
        n_near = near.sum(axis=1)
        n_free = free.sum(axis=1)
        judged = n_near + n_free
        score = (n_near - 0.7 * n_free) / np.maximum(judged, 1)
        yaw_on_edge = abs(float(dyaw)) >= edge_yaw
        for i in np.flatnonzero(judged >= floor):
            on_edge = yaw_on_edge or abs(ox[i]) >= edge_xy or abs(oy[i]) >= edge_xy
            if on_edge:
                edge_top = max(edge_top, float(score[i]))
            else:
                inner.append((float(score[i]), float(ox[i]), float(oy[i]), float(dyaw)))
    if not inner:
        return None, float("nan"), 0.0
    top = max(row[0] for row in inner)
    near_top = [row for row in inner if row[0] >= top - 0.02]
    score, dx, dy, dyaw = min(
        near_top,
        key=lambda row: math.hypot(row[1], row[2]) + 0.05 * abs(math.degrees(row[3])),
    )
    found = conv.Pose2D(
        pose.x + dx, pose.y + dy, conv.normalize_angle(pose.theta + dyaw)
    )
    return found, score, max(0.0, edge_top - top)


def height_votes(
    occ_map: OccupancyMap,
    band_scans: Mapping[int, conv.LaserScan2D],
    pose: conv.Pose2D,
) -> List[HeightVote]:
    """One vote per height that the map can judge at ``pose``.

    The lidars are bolted to one robot, so a wrong pose shifts every height
    together. When the walls at one height sit on the map and another height
    does not, the pose is right and that other height is seeing something
    new, such as furniture that moved. Scoring the merged scan cannot tell:
    it keeps the nearest return in each direction, which is the clutter.
    """
    votes = []
    returns = {}
    for band, scan in band_scans.items():
        score, judged = wall_agreement(occ_map, scan, pose)
        if judged > 0:
            votes.append(HeightVote(int(band), float(score), int(judged)))
            returns[int(band)] = int(scan_endpoints_base_link(scan).shape[0])
    if not votes:
        return []
    floor = _VOTE_MIN_SHARE * max(returns.values())
    return [v for v in votes if returns[v.band] >= floor]


def score_at_pose(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    pose: conv.Pose2D,
    *,
    occupied_lookup: Optional[np.ndarray] = None,
) -> float:
    """How well ``scan`` lands on ``occ_map`` at ``pose``.

    ``-inf`` when too little of the scan overlaps the map to judge. A high
    score means returns sit on walls already drawn; near or below zero they
    land in empty space.
    """
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return float("-inf")
    if scan_xy.shape[0] > 120:
        pick = np.linspace(0, scan_xy.shape[0] - 1, 120, dtype=np.int32)
        scan_xy = scan_xy[pick]
    lookup = _lookup_or_build(occ_map, occupied_lookup)
    return float(
        _candidate_scores(
            occ_map,
            scan_xy,
            np.array([pose.x]),
            np.array([pose.y]),
            pose.theta,
            occupied_lookup=lookup,
        )[0]
    )


def search_heading(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    pose: conv.Pose2D,
    *,
    yaw_step_deg: float = 4.0,
    min_score: float = 0.5,
    occupied_lookup: Optional[np.ndarray] = None,
) -> Tuple[Optional[conv.Pose2D], float]:
    """Best heading at ``pose``'s position. XY stays put.

    Used after an in-place spin, when wheel yaw can be tens of degrees off
    and the narrow tracking window would not see the walls.
    """
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return None, float("-inf")
    if scan_xy.shape[0] > 120:
        pick = np.linspace(0, scan_xy.shape[0] - 1, 120, dtype=np.int32)
        scan_xy = scan_xy[pick]
    lookup = _lookup_or_build(occ_map, occupied_lookup)
    _wheel_score, wheel_cov = _prior_score_and_coverage(
        occ_map, scan_xy, pose, occupied_lookup=lookup
    )
    min_cov = max(0.0, wheel_cov - _COVERAGE_SHED)
    step = math.radians(yaw_step_deg)
    n = max(1, int(round(2.0 * math.pi / step)))
    scored: list[tuple[float, float]] = []
    for i in range(n):
        yaw = conv.normalize_angle(pose.theta + i * step)
        score = float(
            _candidate_scores(
                occ_map,
                scan_xy,
                np.array([pose.x]),
                np.array([pose.y]),
                yaw,
                occupied_lookup=lookup,
                min_coverage=min_cov,
            )[0]
        )
        scored.append((score, yaw))
    # A centered hall scores the same forwards and backwards. Among headings
    # that tie the best, stay with the one nearest the wheels.
    best_score = max(item[0] for item in scored)
    near = [
        item
        for item in scored
        if math.isfinite(item[0]) and item[0] >= best_score - 0.05
    ]
    if not near:
        return None, best_score
    _score, best_yaw = min(
        near, key=lambda item: abs(conv.normalize_angle(item[1] - pose.theta))
    )
    chosen = conv.Pose2D(pose.x, pose.y, best_yaw)
    # Points past the grid edge lower every heading by about the same amount.
    # Keep a heading whose overlap sits on the walls.
    if (
        best_score < min_score
        and scan_map_fit(
            occ_map, scan, chosen, min_score=min_score, occupied_lookup=lookup
        )
        != "fit"
    ):
        return None, best_score
    return chosen, best_score


def _search_window(
    occ_map: OccupancyMap,
    scan_xy: np.ndarray,
    lookup: np.ndarray,
    center: conv.Pose2D,
    *,
    xy_half_m: float,
    xy_step_m: float,
    yaw_half_deg: float,
    yaw_step_deg: float,
    peaks: list,
    min_coverage: float = 0.0,
) -> Tuple[Optional[conv.Pose2D], float]:
    """Best pose in a square window around ``center``.

    Appends ``(score, x, y)`` of each yaw slice's winner and of its best cell
    at least ``_RIVAL_SEP_M`` away to ``peaks`` so the caller can judge
    whether a second wall scores almost as well. Candidates that judge less
    than ``min_coverage`` of the scan are out.
    """
    offsets = np.arange(-xy_half_m, xy_half_m + 1e-9, xy_step_m)
    ox, oy = np.meshgrid(offsets, offsets)
    cand_x = center.x + ox.ravel()
    cand_y = center.y + oy.ravel()

    yaw_half = math.radians(yaw_half_deg)
    yaw_step = math.radians(yaw_step_deg)
    n_yaw = max(1, int(round(2.0 * yaw_half / yaw_step)) + 1)
    rival_sep2 = _RIVAL_SEP_M * _RIVAL_SEP_M

    best_pose: Optional[conv.Pose2D] = None
    best_score = float("-inf")
    for it in range(n_yaw):
        dth = -yaw_half + it * yaw_step
        yaw = conv.normalize_angle(center.theta + dth)
        scores = _candidate_scores(
            occ_map,
            scan_xy,
            cand_x,
            cand_y,
            yaw,
            occupied_lookup=lookup,
            min_coverage=min_coverage,
        )
        idx = int(np.argmax(scores))
        local_score = float(scores[idx])
        if not math.isfinite(local_score):
            continue
        peaks.append((local_score, float(cand_x[idx]), float(cand_y[idx])))
        dx = cand_x - cand_x[idx]
        dy = cand_y - cand_y[idx]
        far = (dx * dx + dy * dy) >= rival_sep2
        if bool(np.any(far)):
            far_scores = np.where(far, scores, float("-inf"))
            far_idx = int(np.argmax(far_scores))
            far_score = float(far_scores[far_idx])
            if math.isfinite(far_score):
                peaks.append(
                    (far_score, float(cand_x[far_idx]), float(cand_y[far_idx]))
                )
        if local_score > best_score:
            best_score = local_score
            best_pose = conv.Pose2D(float(cand_x[idx]), float(cand_y[idx]), yaw)
    return best_pose, best_score


# A second heading this far from the winner is a different alignment.
_YAW_RIVAL_SEP_RAD = math.radians(8.0)


def refine_yaw(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    prior: conv.Pose2D,
    *,
    yaw_half_deg: float = 24.0,
    yaw_step_deg: float = 2.0,
    inflate_cells: int = _INFLATE_CELLS,
    max_scan_points: int = 120,
    occupied_lookup: Optional[np.ndarray] = None,
) -> Tuple[Optional[float], float, float, float]:
    """Heading that best explains ``scan`` with XY held at ``prior``.

    Yaw is the axis a skid-steer loses fastest and the one a corridor still
    observes: both walls fix the heading even when the position along the
    hall is a toss-up. Returns ``(yaw_or_none, best, prior_score, rival)``
    where ``rival`` is the best score at least ``_YAW_RIVAL_SEP_RAD`` from
    the winner (``-inf`` when the window holds one peak).
    """
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return None, float("-inf"), float("-inf"), float("-inf")
    if max_scan_points > 0 and scan_xy.shape[0] > max_scan_points:
        pick = np.linspace(0, scan_xy.shape[0] - 1, max_scan_points, dtype=np.int32)
        scan_xy = scan_xy[pick]
    lookup = _lookup_or_build(occ_map, occupied_lookup, inflate_cells)
    cx = np.array([prior.x])
    cy = np.array([prior.y])
    prior_score, prior_cov = _prior_score_and_coverage(
        occ_map, scan_xy, prior, occupied_lookup=lookup
    )
    min_cov = max(0.0, prior_cov - _COVERAGE_SHED)

    def score(yaw: float) -> float:
        return float(
            _candidate_scores(
                occ_map,
                scan_xy,
                cx,
                cy,
                yaw,
                occupied_lookup=lookup,
                min_coverage=min_cov,
            )[0]
        )

    half = math.radians(yaw_half_deg)
    step = math.radians(yaw_step_deg)
    n = max(1, int(round(2.0 * half / step)) + 1)
    scored: list[tuple[float, float]] = []
    for it in range(n):
        yaw = conv.normalize_angle(prior.theta - half + it * step)
        s = score(yaw)
        if math.isfinite(s):
            scored.append((s, yaw))
    if not scored:
        return None, float("-inf"), prior_score, float("-inf")
    best, best_yaw = max(scored, key=lambda item: item[0])
    rival = float("-inf")
    for s, yaw in scored:
        if abs(conv.normalize_angle(yaw - best_yaw)) < _YAW_RIVAL_SEP_RAD:
            continue
        rival = max(rival, s)
    return best_yaw, best, prior_score, rival


# Above this the published pose already explains the scan and the search
# stays tight (alias guard). Below it the body may have slipped further than
# the fine window and a coarse pass looks first.
_ALIGNED_PRIOR_SCORE = 0.35


def refine_pose(
    occ_map: OccupancyMap,
    scan: conv.LaserScan2D,
    prior: conv.Pose2D,
    *,
    xy_half_m: float = 0.30,
    xy_step_m: float = 0.05,
    yaw_half_deg: float = 12.0,
    yaw_step_deg: float = 2.0,
    wide_xy_half_m: float = 0.60,
    wide_xy_step_m: float = 0.10,
    wide_yaw_half_deg: float = 24.0,
    wide_yaw_step_deg: float = 4.0,
    inflate_cells: int = _INFLATE_CELLS,
    min_score: float = 0.08,
    max_scan_points: int = 120,
    occupied_lookup: Optional[np.ndarray] = None,
) -> Tuple[Optional[conv.Pose2D], float, float, float]:
    """Search around ``prior`` for the pose that explains ``scan``.

    A prior that already fits gets a tight fine window. A prior that does not
    gets a coarse pass over the ``wide_*`` window first (a skid or a spin
    leaves the body well outside the fine box), then the fine window around
    that winner. Both passes cost about the same as one fine window.

    Returns ``(pose_or_none, best_score, prior_score, rival_score)``.
    ``rival_score`` is the best peak at least ``_RIVAL_SEP_M`` from the winner,
    or ``-inf`` when the window has only one blob. Rejects candidates that
    do not beat the prior by a distance-weighted margin (anti-oscillation).
    """
    scan_xy = scan_endpoints_base_link(scan)
    if scan_xy.shape[0] < 20:
        return None, float("-inf"), float("-inf"), float("-inf")
    if max_scan_points > 0 and scan_xy.shape[0] > max_scan_points:
        pick = np.linspace(0, scan_xy.shape[0] - 1, max_scan_points, dtype=np.int32)
        scan_xy = scan_xy[pick]

    lookup = _lookup_or_build(occ_map, occupied_lookup, inflate_cells)
    prior_score, prior_cov = _prior_score_and_coverage(
        occ_map, scan_xy, prior, occupied_lookup=lookup
    )
    min_cov = max(0.0, prior_cov - _COVERAGE_SHED)

    peaks: list[tuple[float, float, float]] = []
    center = prior
    coarse_pose: Optional[conv.Pose2D] = None
    coarse_score = float("-inf")
    if prior_score >= _ALIGNED_PRIOR_SCORE:
        xy_half_m = min(xy_half_m, 0.20)
        yaw_half_deg = min(yaw_half_deg, 8.0)
    elif wide_xy_half_m > xy_half_m or wide_yaw_half_deg > yaw_half_deg:
        coarse_pose, coarse_score = _search_window(
            occ_map,
            scan_xy,
            lookup,
            prior,
            xy_half_m=max(wide_xy_half_m, xy_half_m),
            xy_step_m=wide_xy_step_m,
            yaw_half_deg=max(wide_yaw_half_deg, yaw_half_deg),
            yaw_step_deg=wide_yaw_step_deg,
            peaks=peaks,
            min_coverage=min_cov,
        )
        if coarse_pose is not None:
            # Fine pass only needs to cover one coarse cell around the winner.
            center = coarse_pose
            xy_half_m = min(xy_half_m, wide_xy_step_m)
            yaw_half_deg = min(yaw_half_deg, wide_yaw_step_deg)

    best_pose, best_score = _search_window(
        occ_map,
        scan_xy,
        lookup,
        center,
        xy_half_m=xy_half_m,
        xy_step_m=xy_step_m,
        yaw_half_deg=yaw_half_deg,
        yaw_step_deg=yaw_step_deg,
        peaks=peaks,
        min_coverage=min_cov,
    )
    if coarse_pose is not None and coarse_score > best_score:
        best_pose, best_score = coarse_pose, coarse_score

    # A cell next to the winner is the same blob. A rival is another pose
    # far enough away to be a different wall.
    rival_sep2 = _RIVAL_SEP_M * _RIVAL_SEP_M
    rival_score = float("-inf")
    if best_pose is not None:
        for score, x, y in peaks:
            if (x - best_pose.x) ** 2 + (y - best_pose.y) ** 2 < rival_sep2:
                continue
            if score > rival_score:
                rival_score = score

    if best_pose is None or best_score < min_score:
        return None, best_score, prior_score, rival_score

    dist = math.hypot(best_pose.x - prior.x, best_pose.y - prior.y)
    dyaw = abs(conv.normalize_angle(best_pose.theta - prior.theta))
    need = _required_improvement(prior_score, dist, dyaw)
    if best_score < prior_score + need:
        return None, best_score, prior_score, rival_score
    return best_pose, best_score, prior_score, rival_score
