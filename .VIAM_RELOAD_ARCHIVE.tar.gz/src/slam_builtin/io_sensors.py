"""Sync lidar + odom reads for the builtin SLAM engine (no ROS)."""

from __future__ import annotations

import asyncio
import concurrent.futures
import math
import time
from dataclasses import replace
from typing import Mapping, Optional, Sequence

import numpy as np
from viam.utils import struct_to_dict

from ..config import (
    CLOUD_FRAME_CAMERA_OPTICAL,
    LIDAR_SCAN_GET_LASER_SCAN,
    LIDAR_SCAN_POINT_CLOUD,
    LidarConfig,
    SlamConfig,
)
from ..geom import conversions as conv
from ..shm import imushm, pcshm


def _abandon_future(fut: concurrent.futures.Future) -> None:
    """Cancel a wedged RPC and swallow its result so it is not left unread."""

    def _done(finished: concurrent.futures.Future) -> None:
        try:
            finished.result()
        except Exception:  # noqa: BLE001
            pass

    if fut.done():
        _done(fut)
    else:
        fut.add_done_callback(_done)
        fut.cancel()


def _get_laser_scan_not_implemented(exc: BaseException) -> bool:
    if isinstance(exc, NotImplementedError):
        return True
    msg = str(exc).lower()
    return (
        "not implemented" in msg
        or "does not support get_laser_scan" in msg
        or "docommand not implemented" in msg
        or "did not return get_laser_scan" in msg
    )


def _scan_content_key(scan: conv.LaserScan2D) -> int:
    """Cheap identity for one lidar revolution (dedupe repeated fetches)."""
    ranges = np.asarray(scan.ranges, dtype=np.float32)
    return hash((ranges.size, ranges.tobytes()))


def _shm_error_is_stale(detail: object) -> bool:
    return "frame too old" in str(detail).lower()


class BuiltinSensors:
    """Thread-safe-ish sensor facade used from the SLAM background loop."""

    def __init__(
        self,
        *,
        cfg: SlamConfig,
        cameras: Mapping[str, object],
        movement_sensor,
        heading_sensor,
        shm_lidar,
        loop: asyncio.AbstractEventLoop,
        logger=None,
        skip_get_laser_scan: Optional[set] = None,
        scan_max_age_s: float = 2.0,
        odom_reader=None,
    ):
        self._cfg = cfg
        self._cameras = dict(cameras or {})
        self._movement = movement_sensor
        self._heading = heading_sensor
        self._shm = shm_lidar
        self._loop = loop
        self._logger = logger
        self._odom_reader = odom_reader
        self._skip_get_laser_scan = (
            skip_get_laser_scan if skip_get_laser_scan is not None else set()
        )
        self._scan_max_age_s = float(scan_max_age_s)
        self._scan_cache: Optional[conv.LaserScan2D] = None
        self._scan_cache_at = 0.0  # first time this exact scan content was seen
        # Best estimate of when the lidar took it: shm writer stamp, or when
        # the gRPC read that returned it was sent. Later than the real capture
        # by the driver's own buffering, never earlier.
        self._scan_captured_at = float("nan")
        self._read_captured_at: dict[str, float] = {}
        self._scan_cache_key: Optional[int] = None
        self._scan_fetch_at = 0.0
        # True after a fetch returned nothing. The next successful read is a
        # new observation even if the bytes match the pre-gap cloud (drivers
        # often replay the last frame when a camera or lidar comes back).
        self._scan_had_gap = False
        # Lidars whose gRPC read is still in flight. That is not a dropout.
        self._lidar_pending: set[str] = set()
        # Last per-sensor scans, including depth cameras left out of the match.
        self._mapping_frames: list = []
        # One gRPC scan read per lidar. A dead camera that ignores cancel must
        # not stack a new GetPointCloud on every tick — that wedges the module
        # loop, so localization stays blind after the device returns.
        self._lidar_futs: dict[str, tuple[concurrent.futures.Future, float]] = {}
        self._heading_debug: dict = {"source": "none", "heading_rad": None}
        # Gyro-integrated yaw fallback from heading_sensor AngularVelocity
        # (wit-motion exposes deg/s); used only when no absolute orientation.
        self._gyro_heading_rad: Optional[float] = None
        self._gyro_heading_t: Optional[float] = None
        # False while async framesystem mount resolve is in flight — avoid
        # painting keyframes with identity mounts before FS applies.
        self._mounts_ready: bool = True
        # Wheel odom is a gRPC round-trip on the shared module loop. Never
        # block the SLAM tick on it: keep one read in flight, collect it when
        # done, and let the reader's zero-order hold bridge the gap. Blocking
        # 1 s + cancel per tick froze the map pose (IMU fallback has vx=0)
        # whenever soft-loc / global_localize owned the loop.
        self._odom_fut: Optional[concurrent.futures.Future] = None
        self._odom_fut_at = 0.0
        self._odom_last_ok_at: Optional[float] = None
        self._odom_reads = 0
        self._odom_misses = 0  # tick with no fresh wheel sample
        self._odom_failures = 0
        self._odom_timeouts = 0
        self._odom_source = "none"
        self._imu_shm: Optional[imushm.Reader] = None
        if cfg.imu_shm_name:
            try:
                self._imu_shm = imushm.Reader(
                    cfg.imu_shm_name,
                    region_size=int(cfg.imu_shm_region_size),
                )
                self._log(f"builtin SLAM reading IMU shm {cfg.imu_shm_name}")
            except Exception as exc:  # noqa: BLE001
                self._log(f"IMU shm open failed ({cfg.imu_shm_name}): {exc}")
                self._imu_shm = None

    def _log(self, msg: str) -> None:
        if self._logger is not None:
            try:
                self._logger(msg)
            except Exception:  # noqa: BLE001
                pass

    def _run(self, coro, timeout: float = 2.0):
        if self._loop.is_closed():
            if asyncio.iscoroutine(coro):
                coro.close()
            raise RuntimeError("event loop is closed")
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            return fut.result(timeout=timeout)
        except TimeoutError:
            fut.cancel()
            raise

    # Do not hammer the lidar faster than it can publish a revolution.
    _SCAN_MIN_REFETCH_S = 0.04
    # Healthy GetPointCloud returns in a few milliseconds. Don't block the
    # SLAM tick longer than this while one read is already in flight.
    _LIDAR_RPC_WAIT_S = 0.05
    # Abandon a read that has not finished (dead camera / lidar). The next
    # tick starts a fresh call instead of waiting on the wedged one.
    _LIDAR_RPC_STUCK_S = 5.0

    def get_scan(
        self, max_age_s: float = 2.0, *, fresh: bool = False
    ) -> Optional[conv.LaserScan2D]:
        """Latest merged 2D scan.

        ``fresh=False`` (nav/costmap consumers): reuse the cached scan while it
        is younger than ``max_age_s``.

        ``fresh=True`` (SLAM engine): always re-fetch (rate-limited to the lidar
        period) so the scan is captured at the same time as the odom/heading it
        is paired with. Re-using one scan for ``max_age_s`` while the heading
        prior kept rotating smeared every wall into a ring during turns. The
        same object is returned while the lidar content has not changed, so the
        caller can skip matching/inserting a scan it already consumed.

        Sensors with ``obstacles_only=true`` are omitted (nav costmap reads them
        via ViamWorldIO instead). Depth cameras (``camera_optical``) are read
        for mapping bands but left out of this merged scan, so they cannot
        move the pose. A camera-only robot still matches on those scans.
        """
        if not self._mounts_ready:
            return None
        now = time.monotonic()
        cached = self._scan_cache
        if cached is not None:
            age = now - self._scan_cache_at
            if not fresh and age <= max_age_s:
                return cached
            if fresh and now - self._scan_fetch_at < self._SCAN_MIN_REFETCH_S:
                return cached if age <= max_age_s else None
        lidars: Sequence[LidarConfig] = self._cfg.lidars
        if not lidars:
            return self._stale_or_none(max_age_s, now, fresh)
        self._scan_fetch_at = now
        frames = []
        match = []
        captured = []
        for lidar in lidars:
            if lidar.obstacles_only:
                continue
            scan = self._read_lidar_scan_sync(lidar, max_age_s=max_age_s)
            if scan is None:
                continue
            frames.append((lidar, scan))
            captured.append(self._read_captured_at.get(lidar.name, now))
            if lidar.cloud_frame != CLOUD_FRAME_CAMERA_OPTICAL:
                match.append(scan)
        self._mapping_frames = frames
        if not match:
            match = [scan for _, scan in frames]
        captured_at = sum(captured) / len(captured) if captured else now
        if not match:
            # An in-flight read is not a dropout. Only a finished miss (camera
            # down, empty cloud) should let the next identical frame count
            # as a new observation.
            if not self._lidar_pending:
                self._scan_had_gap = True
            return self._stale_or_none(max_age_s, now, fresh)
        merged = (
            match[0]
            if len(match) == 1
            else conv.merge_scans(match, self._cfg.scan_bins)
        )
        key = _scan_content_key(merged)
        if cached is not None and key == self._scan_cache_key:
            age = now - self._scan_cache_at
            if age <= max_age_s:
                # Same revolution, still fresh: keep the object so SLAM does
                # not match one spin's scan at every new heading.
                self._scan_had_gap = False
                return cached
            if self._scan_had_gap:
                # Dropout, then the driver replayed that cloud. It is a new
                # observation — a distinct object so localization resumes.
                merged = replace(merged)
                self._scan_cache = merged
                self._scan_cache_key = key
                self._scan_cache_at = now
                self._scan_captured_at = min(captured_at, now)
                self._scan_had_gap = False
                return merged
            return None
        self._scan_cache = merged
        self._scan_cache_key = key
        self._scan_cache_at = now
        self._scan_captured_at = min(captured_at, now)
        self._scan_had_gap = False
        return merged

    def _stale_or_none(
        self, max_age_s: float, now: float, fresh: bool
    ) -> Optional[conv.LaserScan2D]:
        cached = self._scan_cache
        if not fresh:
            # Legacy nav behaviour: last known scan is better than nothing.
            return cached
        if cached is not None and now - self._scan_cache_at <= max_age_s:
            return cached
        return None

    def scan_age_s(self) -> float:
        """Seconds since the current cached scan content was first seen."""
        if self._scan_cache is None:
            return float("nan")
        return max(0.0, time.monotonic() - self._scan_cache_at)

    def mapping_frames(self) -> list:
        """Per-sensor scans from the last ``get_scan`` read.

        Includes depth cameras omitted from the match scan. ``obstacles_only``
        sensors are still absent.
        """
        return list(self._mapping_frames)

    def scan_captured_at(self) -> float:
        """Monotonic time the current cached scan was captured (NaN if none)."""
        if self._scan_cache is None:
            return float("nan")
        return self._scan_captured_at

    def _pcd_to_scan(self, raw: bytes, lidar: LidarConfig) -> conv.LaserScan2D:
        pts = conv.parse_pcd(raw)
        max_pts = 4000 if lidar.obstacles_only else 0
        pts = conv.prepare_lidar_point_cloud(
            pts,
            cloud_frame=lidar.cloud_frame,
            points_in_base_link=lidar.points_in_base_link,
            x=lidar.x,
            y=lidar.y,
            z=lidar.z,
            theta=lidar.theta,
            pitch=lidar.pitch,
            roll=lidar.roll,
            z_min=lidar.z_min,
            z_max=lidar.z_max,
            max_points=max_pts,
            footprint_length_m=lidar.footprint_length_m,
            footprint_width_m=lidar.footprint_width_m,
            footprint_radius_m=lidar.footprint_radius_m,
        )
        scan = conv.points_to_scan(
            pts,
            angle_min=-math.pi,
            angle_max=math.pi,
            num_bins=self._cfg.scan_bins,
            range_min=lidar.min_range,
            range_max=lidar.max_range,
        )
        if pts.shape[0]:
            r = np.hypot(pts[:, 0], pts[:, 1])
            keep = (r >= lidar.min_range) & (r <= lidar.max_range)
            kept = pts[keep]
            scan.cloud_xy = np.ascontiguousarray(kept[:, :2], dtype=float)
            if kept.shape[1] >= 3:
                scan.cloud_xyz = np.ascontiguousarray(kept[:, :3], dtype=float)
        return scan

    def _try_shm_scan(
        self, lidar: LidarConfig, *, max_age_s: float
    ) -> Optional[conv.LaserScan2D]:
        if not lidar.shm_name or self._shm is None:
            return None
        age_limit = self._scan_max_age_s if self._scan_max_age_s > 0 else max_age_s
        got = self._shm.try_read(
            lidar.shm_name,
            lidar.shm_region_size,
            max_age_s=age_limit if age_limit > 0 else None,
        )
        if got is None:
            stats = self._shm.status().get(pcshm.normalize_name(lidar.shm_name), {})
            detail = stats.get("last_error") or "no complete frame"
            if lidar.shm_required or _shm_error_is_stale(detail):
                self._log(
                    f"lidar {lidar.name} shm {lidar.shm_name!r} unavailable: {detail}"
                )
                return None
            self._shm.note_fallback(lidar.shm_name)
            return None
        raw, age = got
        self._read_captured_at[lidar.name] = time.monotonic() - max(0.0, float(age))
        return self._pcd_to_scan(raw, lidar)

    def _read_lidar_scan_sync(
        self, lidar: LidarConfig, *, max_age_s: float
    ) -> Optional[conv.LaserScan2D]:
        self._lidar_pending.discard(lidar.name)
        shm_scan = self._try_shm_scan(lidar, max_age_s=max_age_s)
        if shm_scan is not None:
            return shm_scan
        if lidar.shm_name and lidar.shm_required:
            return None
        cam = self._cameras.get(lidar.name)
        if cam is None:
            return None
        return self._poll_lidar_grpc(cam, lidar)

    def _poll_lidar_grpc(self, cam, lidar: LidarConfig) -> Optional[conv.LaserScan2D]:
        """One in-flight scan RPC. A stuck call is abandoned, not piled up."""
        name = lidar.name
        now = time.monotonic()
        slot = self._lidar_futs.get(name)
        if slot is not None:
            fut, started = slot
            if fut.done():
                self._lidar_futs.pop(name, None)
                self._read_captured_at[name] = started
                try:
                    return fut.result()
                except Exception:  # noqa: BLE001
                    return None
            if now - started <= self._LIDAR_RPC_STUCK_S:
                self._lidar_pending.add(name)
                return None
            _abandon_future(fut)
            self._lidar_futs.pop(name, None)
            self._log(
                f"lidar {name} scan read stuck for {now - started:.1f}s; retrying"
            )
        if self._loop.is_closed():
            return None
        try:
            fut = asyncio.run_coroutine_threadsafe(
                self._read_lidar_scan_grpc(cam, lidar), self._loop
            )
        except Exception:  # noqa: BLE001
            return None
        self._lidar_futs[name] = (fut, now)
        try:
            result = fut.result(timeout=self._LIDAR_RPC_WAIT_S)
        except TimeoutError:
            self._lidar_pending.add(name)
            return None
        except Exception:  # noqa: BLE001
            self._lidar_futs.pop(name, None)
            return None
        self._lidar_futs.pop(name, None)
        self._read_captured_at[name] = now
        return result

    async def _read_lidar_scan_grpc(
        self, cam, lidar: LidarConfig
    ) -> Optional[conv.LaserScan2D]:
        timeout = 1.0
        scan_source = lidar.scan_source
        name = lidar.name

        async def _from_point_cloud() -> Optional[conv.LaserScan2D]:
            data = await cam.get_point_cloud(timeout=timeout)
            raw = data[0] if isinstance(data, tuple) else data
            return self._pcd_to_scan(raw, lidar)

        async def _from_get_laser_scan() -> Optional[conv.LaserScan2D]:
            raw_payload = await cam.do_command({"command": "get_laser_scan"})
            payload = (
                struct_to_dict(raw_payload)
                if not isinstance(raw_payload, dict)
                else raw_payload
            )
            mir_pts = conv.points_from_mir_laser_scan_payload(payload)
            if mir_pts.sensor_scan is not None and conv.scan_has_returns(
                mir_pts.sensor_scan
            ):
                return mir_pts.sensor_scan
            if mir_pts.base_link.size > 0:
                return conv.points_to_scan(
                    mir_pts.base_link,
                    angle_min=-math.pi,
                    angle_max=math.pi,
                    num_bins=self._cfg.scan_bins,
                    range_min=lidar.min_range,
                    range_max=lidar.max_range,
                )
            return None

        if scan_source == LIDAR_SCAN_POINT_CLOUD or name in self._skip_get_laser_scan:
            try:
                return await _from_point_cloud()
            except Exception:  # noqa: BLE001
                return None

        if scan_source == LIDAR_SCAN_GET_LASER_SCAN:
            try:
                return await _from_get_laser_scan()
            except Exception:  # noqa: BLE001
                return None

        # auto
        try:
            return await _from_get_laser_scan()
        except Exception as exc:  # noqa: BLE001
            if _get_laser_scan_not_implemented(exc):
                self._skip_get_laser_scan.add(name)
            else:
                self._log(f"lidar {name} get_laser_scan failed: {exc}")
        try:
            return await _from_point_cloud()
        except Exception:  # noqa: BLE001
            return None

    # Wait this long for an in-flight wheel read so scan + odom stay paired on
    # a healthy loop (RPC normally returns in a few ms).
    _ODOM_WAIT_S = 0.08
    # An in-flight read older than this is presumed wedged; cancel and retry.
    _ODOM_STUCK_S = 5.0

    def _poll_odom_wheels(self) -> Optional[conv.OdomReading]:
        """Latest wheel sample without stalling the caller on a busy loop."""
        if self._loop.is_closed():
            return None
        now = time.monotonic()
        fut = self._odom_fut
        if (
            fut is not None
            and not fut.done()
            and now - self._odom_fut_at > self._ODOM_STUCK_S
        ):
            fut.cancel()
            self._odom_timeouts += 1
            fut = None
        if fut is None:
            try:
                fut = asyncio.run_coroutine_threadsafe(
                    self._read_odom_wheels(), self._loop
                )
            except Exception:  # noqa: BLE001
                self._odom_failures += 1
                return None
            self._odom_fut = fut
            self._odom_fut_at = now
        try:
            sample = fut.result(timeout=self._ODOM_WAIT_S)
        except concurrent.futures.TimeoutError:
            # Leave it running; collect on a later tick.
            self._odom_misses += 1
            return None
        except (concurrent.futures.CancelledError, asyncio.CancelledError):
            self._odom_fut = None
            return None
        except Exception:  # noqa: BLE001
            self._odom_fut = None
            self._odom_failures += 1
            return None
        self._odom_fut = None
        self._odom_reads += 1
        self._odom_last_ok_at = time.monotonic()
        return sample

    def odom_status(self) -> dict:
        """Wheel-odom read health for SLAM diagnostics."""
        now = time.monotonic()
        fut = self._odom_fut
        out: dict = {
            "source": self._odom_source,
            "reads": self._odom_reads,
            "misses": self._odom_misses,
            "failures": self._odom_failures,
            "timeouts": self._odom_timeouts,
            "inflight_s": (
                round(now - self._odom_fut_at, 3)
                if fut is not None and not fut.done()
                else 0.0
            ),
            "age_s": (
                round(now - self._odom_last_ok_at, 3)
                if self._odom_last_ok_at is not None
                else None
            ),
        }
        reader = self._odom_reader
        debug = getattr(reader, "debug_dict", None) if reader is not None else None
        if callable(debug):
            try:
                d = debug()
                out["last_sample_gap_s"] = d.get("last_sample_gap_s")
                out["gap_hold_events"] = d.get("gap_hold_events")
            except Exception:  # noqa: BLE001
                pass
        return out

    def get_odom(self) -> Optional[conv.OdomReading]:
        # Prefer wheel/movement odometry when configured. IMU shm is a fallback
        # for IMU-only setups; it must not starve a velocity-only wheeled sensor
        # or skip the dedicated heading_sensor merge.
        if self._movement is not None:
            sample = self._poll_odom_wheels()
            if sample is not None:
                headed = self._apply_heading_prefer_shm(sample)
                if headed is not None:
                    self._odom_source = "wheels"
                    return headed
        sample = self._odom_from_imu_shm()
        if sample is None:
            self._odom_source = "none" if self._movement is None else "wheels_pending"
            return None
        self._odom_source = (
            "imu_shm" if self._movement is None else "imu_shm_while_wheels_pending"
        )
        if sample.heading_rad is not None and self._heading is None:
            return sample
        headed = self._apply_heading_prefer_shm(sample)
        return headed if headed is not None else sample

    def _apply_heading_prefer_shm(
        self, sample: conv.OdomReading
    ) -> Optional[conv.OdomReading]:
        """Merge heading without touching the event loop when IMU shm is fresh."""
        if self._heading is None and self._imu_shm is None:
            return sample
        shm = self._apply_heading_from_shm(sample)
        if shm is not None:
            return shm
        if self._heading is None:
            return sample
        try:
            return self._run(self._apply_heading(sample), timeout=1.0)
        except Exception:  # noqa: BLE001
            return sample

    def _apply_heading_from_shm(
        self, sample: conv.OdomReading
    ) -> Optional[conv.OdomReading]:
        """Absolute yaw (+ gyro rate) from wit-imu shm — no gRPC / event loop."""
        reader = self._imu_shm
        if reader is None:
            return None
        try:
            frame = reader.read_latest(max_age_s=float(self._cfg.imu_shm_max_age_s))
        except Exception:  # noqa: BLE001
            return None
        if frame is None or frame.yaw is None:
            return None
        cfg = self._cfg
        now = time.monotonic()
        raw = float(frame.yaw)
        gz_rad_s = math.radians(float(frame.gz or 0.0))
        heading = raw
        if cfg.heading_sensor_invert:
            heading = conv.normalize_angle(-heading)
            gz_rad_s = -gz_rad_s
        if cfg.heading_sensor_yaw_deg:
            heading = conv.normalize_angle(
                heading - math.radians(cfg.heading_sensor_yaw_deg)
            )
        self._gyro_heading_rad = raw
        self._gyro_heading_t = now
        # Prefer Wit gyro rate over sparse wheel ω when the chassis is spinning.
        if abs(gz_rad_s) > 1e-4 or abs(sample.vtheta) < 1e-6:
            sample = conv.OdomReading(
                sample.vx,
                sample.vy,
                gz_rad_s,
                pose=sample.pose,
                heading_rad=sample.heading_rad,
                ax=sample.ax,
                ay=sample.ay,
            )
        sample = conv.merge_odom_heading(sample, heading)
        sync = getattr(self._odom_reader, "sync_heading", None)
        if callable(sync):
            sync(heading)
        self._heading_debug = {
            "source": "imu_shm",
            "heading_rad": heading,
            "heading_deg": round(math.degrees(heading), 3),
            "ahrs_yaw_deg": round(math.degrees(raw), 3),
            "ahrs_source": "imu_shm",
            "gyro_z_deg_s": round(math.degrees(gz_rad_s), 3),
        }
        return sample

    def _odom_from_imu_shm(self) -> Optional[conv.OdomReading]:
        reader = self._imu_shm
        if reader is None:
            return None
        try:
            frame = reader.read_latest(max_age_s=float(self._cfg.imu_shm_max_age_s))
        except Exception:  # noqa: BLE001
            return None
        if frame is None:
            return None
        cfg = self._cfg
        sample = conv.parse_odom_from_readings(
            {
                "angular_velocity": {"x": frame.gx, "y": frame.gy, "z": frame.gz},
                "linear_acceleration": {"x": frame.ax, "y": frame.ay, "z": frame.az},
                "orientation": {
                    "roll": frame.roll,
                    "pitch": frame.pitch,
                    "yaw": frame.yaw,
                },
            }
        )
        # SHM orientation is an absolute yaw prior for IMU-only odom.
        if sample.heading_rad is None and frame.yaw is not None:
            sample = conv.merge_odom_heading(sample, float(frame.yaw))
        if cfg.movement_sensor_upside_down:
            sample = conv.apply_sensor_upside_down(sample)
        if cfg.movement_sensor_yaw_deg:
            sample = conv.apply_sensor_mount_yaw(
                sample, math.radians(cfg.movement_sensor_yaw_deg)
            )
        return sample

    async def _apply_heading(self, sample: conv.OdomReading) -> conv.OdomReading:
        """Merge dedicated heading_sensor into ``sample``.

        Priority (``viam-modules/wit-motion`` API surfaces):

        1. Absolute orientation (``GetOrientation`` / readings euler yaw) → the
           heading prior, ``source`` = ``orientation_euler`` / ``orientation`` /
           ``readings`` / ``compass``.
        2. Only when no absolute orientation is readable: integrate
           ``GetAngularVelocity.z`` (deg/s) → ``source: gyro_integrated`` and
           use the gyro rate as odom ``vtheta``.

        ``gyro_z_deg_s`` is always reported for diagnostics when readable.
        """
        from ..odom.source import read_typed_heading

        cfg = self._cfg
        if self._heading is None:
            self._heading_debug = {"source": "none", "heading_rad": None}
            return sample

        now = time.monotonic()
        gz_rad_s: Optional[float] = None
        try:
            av = await self._heading.get_angular_velocity()
            # wit-motion / Viam: AngularVelocity is degrees/sec.
            gz_rad_s = math.radians(float(getattr(av, "z", 0.0) or 0.0))
        except Exception:  # noqa: BLE001
            gz_rad_s = None

        ahrs_yaw, ahrs_source, heading_dbg = await read_typed_heading(self._heading)
        heading_dbg = dict(heading_dbg)
        if gz_rad_s is not None:
            heading_dbg["gyro_z_deg_s"] = round(math.degrees(gz_rad_s), 3)

        # ``raw`` is in the sensor frame; invert / yaw_deg are applied to the
        # output only, never folded back into the integrator state.
        if ahrs_yaw is not None:
            heading_dbg["ahrs_yaw_deg"] = round(math.degrees(ahrs_yaw), 3)
            heading_dbg["ahrs_source"] = ahrs_source
            raw = float(ahrs_yaw)
            source = ahrs_source
            # Keep the gyro fallback continuous with the absolute heading.
            self._gyro_heading_rad = raw
            self._gyro_heading_t = now
        elif gz_rad_s is not None:
            if self._gyro_heading_rad is None or self._gyro_heading_t is None:
                self._gyro_heading_rad = 0.0
            else:
                dt = max(0.0, min(now - self._gyro_heading_t, 0.5))
                self._gyro_heading_rad = conv.normalize_angle(
                    float(self._gyro_heading_rad) + gz_rad_s * dt
                )
            self._gyro_heading_t = now
            raw = float(self._gyro_heading_rad)
            source = "gyro_integrated"
            vtheta = -gz_rad_s if cfg.heading_sensor_invert else gz_rad_s
            sample = conv.OdomReading(
                sample.vx,
                sample.vy,
                vtheta,
                pose=sample.pose,
                heading_rad=sample.heading_rad,
                ax=sample.ax,
                ay=sample.ay,
            )
        else:
            self._heading_debug = {
                "source": "none",
                "heading_rad": None,
                **heading_dbg,
            }
            return sample

        heading = raw
        if cfg.heading_sensor_invert:
            heading = conv.normalize_angle(-heading)
        if cfg.heading_sensor_yaw_deg:
            heading = conv.normalize_angle(
                heading - math.radians(cfg.heading_sensor_yaw_deg)
            )

        sample = conv.merge_odom_heading(sample, heading)
        sync = getattr(self._odom_reader, "sync_heading", None)
        if callable(sync):
            sync(heading)
        self._heading_debug = {
            "source": source,
            "heading_rad": heading,
            "heading_deg": round(math.degrees(heading), 3),
            **heading_dbg,
        }
        return sample

    async def _read_odom_wheels(self) -> conv.OdomReading:
        """Wheel / movement_sensor twist (+pose) without heading_sensor RPCs."""
        cfg = self._cfg
        if self._odom_reader is not None:
            sample = await self._odom_reader.read()
        else:
            sample = conv.parse_odom_from_readings(await self._movement.get_readings())
        if cfg.movement_sensor_upside_down:
            sample = conv.apply_sensor_upside_down(sample)
        if cfg.movement_sensor_yaw_deg:
            sample = conv.apply_sensor_mount_yaw(
                sample, math.radians(cfg.movement_sensor_yaw_deg)
            )
        return sample

    async def _read_odom(self) -> conv.OdomReading:
        return await self._apply_heading(await self._read_odom_wheels())

    def odom_debug(self) -> dict:
        """Raw typed-getter snapshot from the last odom read (if any)."""
        reader = self._odom_reader
        out: dict = {"source": "get_readings"}
        if reader is not None:
            debug = getattr(reader, "debug_dict", None)
            out = debug() if callable(debug) else {"source": "typed"}
        heading = dict(self._heading_debug)
        if heading:
            out = {**out, "heading": heading}
        return out

    def heading_debug(self) -> dict:
        """Last dedicated heading_sensor snapshot for ``sensor_probe``."""
        return dict(self._heading_debug)
