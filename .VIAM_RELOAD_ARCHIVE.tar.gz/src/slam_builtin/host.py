"""Duck-typed SLAM host for ``slam_backend: builtin``."""

from __future__ import annotations

import math
from pathlib import Path
from typing import Callable, Dict, List, Optional

from ..config import SLAM_BACKEND_BUILTIN
from ..geom import conversions as conv
from .engine import BuiltinSlamEngine


class BuiltinSlamHost:
    """SLAM surface used by ``SlamService`` for builtin occupancy mapping.

    Implements the methods ``slam.py`` calls on ``runtime.manager`` /
    ``manager.node``. ``node`` is self (same object) so
    ``mgr.node.get_map()`` works.
    """

    def __init__(self, engine: BuiltinSlamEngine):
        self._engine = engine
        self.node = self
        self._map_updates_enabled = True
        self._visible_generation = 0
        self._still_keyframe_hook: Optional[
            Callable[[conv.LaserScan2D, List, conv.Pose2D], None]
        ] = None

    @property
    def engine(self) -> BuiltinSlamEngine:
        return self._engine

    # -- Lifecycle ------------------------------------------------------------
    def start(self, io_provider=None, loop=None) -> None:
        del io_provider, loop
        self._engine.start()

    def shutdown(self) -> None:
        self._engine.stop()

    def start_slam(self, map_stem: Optional[Path], mode: str) -> None:
        map_dir = Path(map_stem).parent if map_stem is not None else None
        self._engine.configure_mode(mode, map_dir)

    def stop_slam(self) -> None:
        pass

    def slam_running(self) -> bool:
        return bool(self._engine.diagnostics().get("running"))

    def reset_slam_map(self) -> bool:
        self._engine.reset_map()
        return True

    def clear_obstacles(self, x_m: float, y_m: float, radius_m: float) -> dict:
        return self._engine.clear_obstacles(x_m, y_m, radius_m)

    def clear_region(
        self, x_min: float, y_min: float, x_max: float, y_max: float
    ) -> dict:
        return self._engine.clear_region(x_min, y_min, x_max, y_max)

    def add_obstacles(self, x_m: float, y_m: float, radius_m: float) -> dict:
        return self._engine.add_obstacles(x_m, y_m, radius_m)

    def save_map(self, map_stem: Path) -> Dict:
        return self._engine.save_map(Path(map_stem).parent)

    def start_repair(self, map_stem: Path, *, apply="auto") -> Dict:
        return self._engine.start_repair(
            Path(map_stem).parent, apply=apply, reason="manual"
        )

    def repair_status(self) -> Dict:
        return self._engine.repair_status()

    def undo_repair(self, map_stem: Path) -> Dict:
        return self._engine.undo_repair(Path(map_stem).parent)

    def optimize_pose_graph(self, map_stem: Path) -> Dict:
        del map_stem
        out = dict(self._engine.optimize_pose_graph())
        out["slam_backend"] = SLAM_BACKEND_BUILTIN
        return out

    def set_initial_pose(self, pose: conv.Pose2D) -> None:
        self._engine.set_pose(pose)

    def relocalize(
        self,
        pose: conv.Pose2D,
        *,
        position_variance_m2: float = 4.0,
        yaw_variance_rad2: float = 0.0,
    ) -> None:
        del position_variance_m2, yaw_variance_rad2
        # Ignore tiny nudges the continuous matcher already owns. Periodic
        # relocalize can report a 0.2–0.3 m drift fix — the old 0.35 m gate
        # dropped those while manual global_localize (apply_map_pose_correction)
        # still worked, which looked like "auto refine finds the right spot".
        current = self._engine.get_pose()
        dist = math.hypot(pose.x - current.x, pose.y - current.y)
        dyaw = abs(conv.normalize_angle(pose.theta - current.theta))
        if dist <= 0.15 and dyaw <= math.radians(8.0):
            return
        self._engine.set_pose(pose)

    def get_pose_in_map(self) -> Optional[conv.Pose2D]:
        return self._engine.get_pose()

    def get_pose_in_map_at(self, t: float) -> Optional[conv.Pose2D]:
        """Map pose at monotonic time ``t`` (``None`` outside recent history)."""
        return self._engine.get_pose_at(t)

    def pose_restored_from_disk(self) -> bool:
        return self._engine.pose_restored_from_disk()

    def apply_map_pose_correction(
        self,
        pose: conv.Pose2D,
        *,
        score: Optional[float] = None,
        force: bool = False,
    ) -> Dict:
        return self._engine.apply_map_pose_correction(pose, score=score, force=force)

    def set_still_keyframe_hook(self, hook) -> None:
        self._still_keyframe_hook = hook
        self._engine.set_keyframe_hook(self._forward_still_keyframe)

    def _forward_still_keyframe(
        self,
        scan: conv.LaserScan2D,
        band_points: List,
        pose: conv.Pose2D,
    ) -> None:
        hook = self._still_keyframe_hook
        if hook is None:
            return
        hook(scan, band_points, pose)

    def slam_bridge_status(self) -> Dict:
        vx, vy, vtheta = self._engine.get_odom_twist()
        return {"odom_velocity": {"vx": vx, "vy": vy, "vtheta": vtheta}}

    def nav_status(self) -> Dict:
        return {"active": False, "number_of_recoveries": 0, "state": "idle"}

    def mapping_revisit_interval_s(self, default_s: float) -> float:
        """Health-aware revisit cadence (shorter while the map is tearing)."""
        return float(self._engine.mapping_revisit_interval_s(default_s))

    def slam_diagnostics(self) -> Dict:
        d = self._engine.diagnostics()
        d["slam_backend"] = SLAM_BACKEND_BUILTIN
        d["map_backend"] = "builtin"

        d["bridge"] = {"ok": True, "slam_backend": SLAM_BACKEND_BUILTIN}
        return d

    def get_base_scan(self, max_age_s: float = 1.0):
        return self._engine._sensors.get_scan(max_age_s)  # noqa: SLF001

    def record_cmd_vel(
        self, vx: float, vy: float, vtheta: float, *, source: str = "nav"
    ) -> None:
        # No external cmd_vel history on the builtin path.
        del vx, vy, vtheta, source

    # -- Map / pose surface (self.node = self) -------------------------------
    def get_map(self) -> Optional[dict]:
        if not self._map_updates_enabled:
            return None
        return self._engine.get_map()

    def set_map_updates_enabled(self, enabled: bool) -> None:
        self._map_updates_enabled = bool(enabled)

    def flush_map_subscription(self) -> int:
        self._visible_generation = int(self._engine.diagnostics().get("generation", 0))
        return self._visible_generation
