"""Odometry / heading sensor adapters."""
