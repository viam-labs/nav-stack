"""Viam-backed WorldIO: SLAM + lidars + base."""

from __future__ import annotations

import asyncio
import base64
import concurrent.futures
import math
import time
from typing import Callable, Mapping, Optional, Sequence, Set

import numpy as np
from viam.proto.common import Vector3
from viam.utils import struct_to_dict

from ...config import (
    LIDAR_SCAN_GET_LASER_SCAN,
    LIDAR_SCAN_POINT_CLOUD,
    LidarConfig,
    body_twist_to_viam_set_velocity,
)
from ...geom import conversions as conv
from ...shm import pcshm
from ...slam_client import parse_get_grid, slam_pose_to_pose2d
from .viz_store import NavVizStore


def _abandon_future(fut: concurrent.futures.Future) -> None:
    """Cancel a wedged RPC and swallow its result so it is not left unread."""

    def _done(finished: concurrent.futures.Future) -> None:
        try:
            finished.result()
        except Exception:  # noqa: BLE001
            pass

    if fut.done():
        _done(fut)
    else:
        fut.add_done_callback(_done)
        fut.cancel()


def _get_laser_scan_not_implemented(exc: BaseException) -> bool:
    if isinstance(exc, NotImplementedError):
        return True
    msg = str(exc).lower()
    return (
        "not implemented" in msg
        or "does not support get_laser_scan" in msg
        or "docommand not implemented" in msg
        or "did not return get_laser_scan" in msg
    )


def _shm_error_is_stale(detail: object) -> bool:
    return "frame too old" in str(detail).lower()


def get_grid_response_to_map(resp: Mapping) -> Optional[dict]:
    """Convert a ``get_grid`` DoCommand response to a bridge-style map dict."""
    parsed = parse_get_grid(dict(resp))
    if parsed is None:
        return None
    rows, cols, cell_size, x_min, y_min, cells = parsed
    grid = np.asarray(cells, dtype=np.int16).reshape(rows, cols)
    return {
        "grid": grid,
        "resolution": float(cell_size),
        "origin_x": float(x_min),
        "origin_y": float(y_min),
    }


def map_dict_to_get_grid(map_data: dict) -> dict:
    """Encode a bridge-style map dict as a ``get_grid`` DoCommand payload."""
    grid = np.asarray(map_data["grid"], dtype=np.int16)
    rows, cols = int(grid.shape[0]), int(grid.shape[1])
    # int8 little/big endian are identical, so the raw buffer is the packed
    # signed-byte stream (the old ``struct.pack(*tolist())`` built a Python
    # int per cell).
    raw = np.ascontiguousarray(
        np.clip(grid.reshape(-1), -1, 100).astype(np.int8)
    ).tobytes()
    return {
        "rows": rows,
        "cols": cols,
        "cellSize": float(map_data["resolution"]),
        "xMin": float(map_data["origin_x"]),
        "yMin": float(map_data["origin_y"]),
        "data": base64.b64encode(raw).decode("ascii"),
    }


class ViamWorldIO:
    """WorldIO over Viam SLAM / Camera / Base resources."""

    def __init__(
        self,
        *,
        slam,
        base,
        loop: asyncio.AbstractEventLoop,
        cameras: Optional[Mapping[str, object]] = None,
        lidars: Optional[Sequence[LidarConfig]] = None,
        base_velocity_convention: str = "viam",
        viz: Optional[NavVizStore] = None,
        shm_lidar=None,
        scan_max_age_s: float = 2.0,
        obstacles_only_period_s: float = 0.20,
        drive_timeout_s: float = 5.0,
        map_cache_s: float = 1.0,
        scan_bins: int = 360,
        logger=None,
        pose_provider: Optional[Callable[[], Optional[conv.Pose2D]]] = None,
        pose_at_provider: Optional[Callable[[float], Optional[conv.Pose2D]]] = None,
        map_provider: Optional[Callable[[], Optional[dict]]] = None,
        scan_provider: Optional[Callable[[float], Optional[conv.LaserScan2D]]] = None,
        localization_hold_provider: Optional[Callable[[], Optional[dict]]] = None,
        localization_check_provider: Optional[Callable[[], Optional[dict]]] = None,
    ):
        self._slam = slam
        self._base = base
        self._base_name = str(
            getattr(base, "name", None) or getattr(base, "_name", None) or base
        )
        self._loop = loop
        self._cameras = dict(cameras or {})
        self._lidars = list(lidars or [])
        self._convention = base_velocity_convention
        self._viz = viz
        self._shm_lidar = shm_lidar
        self._scan_max_age_s = float(scan_max_age_s)
        self._drive_timeout_s = drive_timeout_s
        self._map_cache_s = map_cache_s
        self._scan_bins = scan_bins
        self._logger = logger
        # Prefer in-process SLAM engine reads over gRPC GetPosition/get_grid.
        # Same-module dependency RPCs share the module event loop with the nav
        # worker's run_coroutine_threadsafe waits and can return the SLAM API's
        # origin placeholder (0,0,0) or stall — which freezes bearing_error.
        self._pose_provider = pose_provider
        # Map pose at a past monotonic time. Scans are stamped with the pose
        # they were taken from; stamping the pose at read time drew every
        # obstacle shifted by speed × latency (rotated during a turn).
        self._pose_at_provider = pose_at_provider
        # lidar name -> monotonic capture estimate of the last frame read.
        self._read_captured_at: dict[str, float] = {}
        self._map_provider = map_provider
        self._scan_provider = scan_provider
        self._localization_hold_provider = localization_hold_provider
        self._localization_check_provider = localization_check_provider
        self._zone_masks = None  # optional ZoneMaskPublisher from BuiltinNavHost
        self._skip_get_laser_scan: set[str] = set()
        self._map_cache: Optional[dict] = None
        self._map_cache_at = 0.0
        self._scan_cache: Optional[conv.LaserScan2D] = None
        self._scan_cache_at = 0.0
        self._scan_cache_pose: Optional[conv.Pose2D] = None
        # Obstacles-only depth cams: never await GetPointCloud on the nav tick.
        # A fire-and-forget refresh fills this cache; the control loop only reads it
        # so RealSense PCD cannot starve SetVelocity on the shared module loop.
        self._per_lidar_scan: dict[str, tuple[conv.LaserScan2D, float]] = {}
        # Base-frame XYZ of obstacles_only returns to remember after they leave
        # the vertical view. ``cart_height_m`` 0 means the camera's own z band,
        # up to ``z_max``.
        self._above_cart_pts: dict[str, np.ndarray] = {}
        self._above_cart_enabled = False
        self._cart_height_m = 0.0
        # Depth is async + slow; keep it fresh enough that motion compensation works.
        # Configurable via NavConfig.obstacles_only_rate_hz (default 5 Hz).
        self._obstacles_only_period_s = max(0.0, float(obstacles_only_period_s))
        # Beyond this pose shift, cached depth is dropped (avoids phantom obstacles).
        self._obstacles_max_shift_m = 0.30
        self._obstacles_max_shift_rad = math.radians(20.0)
        self._obstacles_refresh_inflight: Set[str] = set()
        # name -> (generation, monotonic start). A hung refresh is superseded.
        self._obstacles_job_gen: dict[str, tuple[int, float]] = {}
        # One gRPC scan read per lidar so a dead camera cannot stack
        # GetPointCloud calls on the module loop until nav-stack restarts.
        self._lidar_futs: dict[str, tuple[concurrent.futures.Future, float]] = {}
        self._last_drive: Optional[dict] = None
        self._pose_source: str = "none"
        # In-flight Base.SetVelocity future. Never cancel mid-RPC: control ticks
        # are faster than a busy module loop, and cancelling made every command
        # land as ``superseded`` while the robot sat still → stall timeout.
        # Latest cmd is coalesced into ``_drive_followup`` and sent after the
        # current RPC finishes. Also never cancel just because the waiter timed
        # out (soft-loc / global_localize holding the loop).
        self._pending_drive_fut: Optional[concurrent.futures.Future] = None
        self._drive_followup: Optional[tuple] = None  # (make_coro, intent)
        # Last twist we accepted (scheduled or skipped-as-duplicate). Used to
        # skip redundant SetVelocity when the control tick is faster than the
        # base RPC — identical cmds need not hit the module loop.
        self._last_desired_twist: Optional[tuple[float, float, float]] = None
        # Many wheeled bases stop if SetVelocity is not refreshed (command
        # watchdog). Skipping identical twists forever left nav advertising
        # cmd_vtheta while the base had timed out — live: spin commanded,
        # pose frozen, setPower still worked (rc23).
        self._last_desired_at: float = 0.0
        self._drive_refresh_s: float = 0.20
        self._drive_calls = 0
        self._drive_skipped = 0
        self._drive_coalesced = 0
        self._drive_rtt_last_s: Optional[float] = None
        self._drive_rtt_ema_s: Optional[float] = None
        # How long the control thread waits for SetVelocity to be scheduled /
        # ack'd. Soft-loc cycles often occupy the loop for seconds; waiting the
        # full drive_timeout_s made every tick look like a hard IO failure even
        # though a later manual SetVelocity worked fine.
        self._drive_ack_timeout_s = min(0.35, max(0.05, float(drive_timeout_s)))

    def _log(self, msg: str) -> None:
        if self._logger is not None:
            try:
                self._logger(msg)
            except Exception:  # noqa: BLE001
                pass

    def _run(self, coro, timeout: float = 2.0):
        if self._loop.is_closed():
            if asyncio.iscoroutine(coro):
                coro.close()
            raise RuntimeError("event loop is closed")
        fut = asyncio.run_coroutine_threadsafe(coro, self._loop)
        try:
            return fut.result(timeout=timeout)
        except TimeoutError as exc:
            fut.cancel()
            # concurrent.futures.TimeoutError has empty str(); make it actionable.
            raise TimeoutError(f"Viam IO timed out after {timeout:.1f}s") from exc

    def _schedule_drive(self, make_coro, intent: dict, *, wait_s: float) -> None:
        """Queue Base.SetVelocity on the module loop without starving on wait.

        Soft-loc / global_localize often occupy the shared loop for longer than
        a control tick. Blocking then cancelling the future made every hold look
        like a base failure, and cancelling on the *next* tick made every drive
        ``superseded`` before the base ever moved.
        """
        if self._loop.is_closed():
            raise RuntimeError("event loop is closed")

        intent["pending"] = True
        intent.pop("error", None)
        intent["issued"] = False

        fut = self._pending_drive_fut
        if fut is not None and not fut.done():
            # Keep the in-flight RPC; send this cmd after it finishes.
            self._drive_followup = (make_coro, intent)
            intent["coalesced"] = True
            self._drive_coalesced += 1
            self._last_drive = dict(intent)
            return

        self._drive_followup = None
        self._drive_calls += 1
        self._last_drive = dict(intent)

        async def _issue():
            current_make = make_coro
            current_intent = intent
            while True:
                t0 = time.monotonic()
                try:
                    await current_make()
                    rtt = time.monotonic() - t0
                    self._drive_rtt_last_s = rtt
                    if self._drive_rtt_ema_s is None:
                        self._drive_rtt_ema_s = rtt
                    else:
                        self._drive_rtt_ema_s = 0.8 * self._drive_rtt_ema_s + 0.2 * rtt
                    current_intent["issued"] = True
                    current_intent["error"] = None
                    current_intent["rtt_s"] = round(rtt, 4)
                    current_intent.pop("pending", None)
                    current_intent.pop("coalesced", None)
                except asyncio.CancelledError:
                    current_intent["issued"] = False
                    current_intent["error"] = "cancelled"
                    current_intent.pop("pending", None)
                    self._last_drive = dict(current_intent)
                    raise
                except Exception as exc:  # noqa: BLE001
                    current_intent["issued"] = False
                    current_intent["error"] = str(exc).strip() or type(exc).__name__
                    current_intent.pop("pending", None)
                    self._last_drive = dict(current_intent)
                    # Still drain follow-up (e.g. stop after a failed spin).
                else:
                    self._last_drive = dict(current_intent)

                follow = self._drive_followup
                self._drive_followup = None
                if follow is None:
                    return
                current_make, current_intent = follow
                current_intent["pending"] = True
                current_intent.pop("coalesced", None)
                self._drive_calls += 1
                self._last_drive = dict(current_intent)

        fut = asyncio.run_coroutine_threadsafe(_issue(), self._loop)
        self._pending_drive_fut = fut
        try:
            fut.result(timeout=max(0.0, float(wait_s)))
        except concurrent.futures.TimeoutError as exc:
            # Leave the RPC running — do not cancel. Caller sees pending.
            raise TimeoutError(f"Viam IO timed out after {wait_s:.1f}s") from exc
        finally:
            if self._pending_drive_fut is fut and fut.done():
                self._pending_drive_fut = None
        # Surface the intent that finished (may be a follow-up).
        finished = self._last_drive or intent
        if finished.get("error"):
            raise RuntimeError(finished["error"])

    def last_drive(self) -> Optional[dict]:
        """Most recent SetVelocity mapping (body rad/s → Viam mm/s + deg/s)."""
        return dict(self._last_drive) if self._last_drive else None

    def drive_stats(self) -> dict:
        """SetVelocity health for higher control-rate soak (RTT / skip / coalesce)."""
        return {
            "calls": self._drive_calls,
            "skipped": self._drive_skipped,
            "coalesced": self._drive_coalesced,
            "rtt_last_s": (
                None
                if self._drive_rtt_last_s is None
                else round(self._drive_rtt_last_s, 4)
            ),
            "rtt_ema_s": (
                None
                if self._drive_rtt_ema_s is None
                else round(self._drive_rtt_ema_s, 4)
            ),
            "pending": bool(
                self._pending_drive_fut is not None
                and not self._pending_drive_fut.done()
            ),
        }

    def pose_source(self) -> str:
        """How the last ``get_pose`` was obtained (``in_process`` / ``get_position`` / …)."""
        return self._pose_source

    def attach_zone_masks(self, publisher) -> None:
        """Wire the host's ``ZoneMaskPublisher`` for planner / speed limits."""
        self._zone_masks = publisher

    def zone_masks_for(self, map_data: Optional[dict] = None):
        """Rasterized keepout/speed masks for ``map_data`` (or the live map)."""
        pub = self._zone_masks
        if pub is None:
            return None
        return pub.masks_for(map_data if map_data is not None else self.get_map())

    def zone_mask_revision(self) -> int:
        pub = self._zone_masks
        if pub is None:
            return 0
        return int(pub.revision)

    def get_map(self) -> Optional[dict]:
        now = time.monotonic()
        if self._map_cache is not None and now - self._map_cache_at < self._map_cache_s:
            return self._map_cache
        if self._map_provider is not None:
            try:
                parsed = self._map_provider()
            except Exception:  # noqa: BLE001
                parsed = None
            if parsed is not None and parsed.get("grid") is not None:
                self._map_cache = parsed
                self._map_cache_at = now
                if self._viz is not None:
                    self._viz.set_map(parsed)
                return parsed
        try:
            resp = self._run(
                self._slam.do_command({"command": "get_grid"}),
                timeout=5.0,
            )
        except Exception:  # noqa: BLE001
            return self._map_cache
        if not isinstance(resp, Mapping):
            return self._map_cache
        payload: Mapping = resp
        if "rows" not in resp and isinstance(resp.get("grid"), Mapping):
            payload = resp["grid"]  # type: ignore[assignment]
        parsed = get_grid_response_to_map(payload)
        if parsed is None and "rows" in resp:
            parsed = get_grid_response_to_map(resp)
        if parsed is not None:
            self._map_cache = parsed
            self._map_cache_at = now
            if self._viz is not None:
                self._viz.set_map(parsed)
        return parsed

    def get_pose(self) -> Optional[conv.Pose2D]:
        """Map-frame pose in meters / radians from the configured SLAM service.

        Prefer **sync** sources so the control loop does not schedule
        ``GetPosition`` on the shared module event loop every tick (that
        starves ``Base.SetVelocity``). Order:

        1. Sync ``slam.get_position_pose2d()`` when the dependency is local SlamService.
        2. ``pose_provider`` (in-process registered SLAM service / engine).
        3. Async ``GetPosition`` only as a last resort (remote SLAM).
        """
        # Only call sync helpers declared on the SLAM class (local SlamService).
        # Instance MagicMock / gRPC stubs must not invent get_position_pose2d.
        if callable(getattr(type(self._slam), "get_position_pose2d", None)):
            try:
                p2 = self._slam.get_position_pose2d()
            except Exception as exc:  # noqa: BLE001
                self._log(f"get_position_pose2d failed: {exc}")
                p2 = None
            if p2 is not None:
                self._pose_source = "get_position_sync"
                if self._viz is not None:
                    self._viz.set_pose(p2)
                return p2

        if self._pose_provider is not None:
            try:
                p2 = self._pose_provider()
            except Exception as exc:  # noqa: BLE001
                self._log(f"pose_provider failed: {exc}")
                p2 = None
            if p2 is not None:
                self._pose_source = "in_process"
                if self._viz is not None:
                    self._viz.set_pose(p2)
                return p2

        via_api = self._pose_from_get_position()
        if via_api is not None:
            self._pose_source = "get_position"
            if self._viz is not None:
                self._viz.set_pose(via_api)
            return via_api

        self._pose_source = "none"
        return None

    def _pose_from_get_position(self) -> Optional[conv.Pose2D]:
        try:
            pose = self._run(self._slam.get_position(), timeout=2.0)
        except Exception:  # noqa: BLE001
            return None
        if pose is None:
            return None
        try:
            return slam_pose_to_pose2d(pose)
        except Exception:  # noqa: BLE001
            return None

    def _reusable_scan_cache(
        self, max_age_s: float, now: float, *, include_obstacles_only: bool
    ) -> Optional[conv.LaserScan2D]:
        """Last obstacle scan, only while it is still inside ``max_age_s``.

        ``max_age_s <= 0`` asks not to expire the cache. Returning a scan
        forever is how a dead lidar kept reporting 0.485 m of clearance
        while the body drove into the wall.
        """
        if not include_obstacles_only or self._scan_cache is None:
            return None
        if max_age_s <= 0.0 or now - self._scan_cache_at <= max_age_s:
            return self._scan_cache
        return None

    def get_scan(
        self, max_age_s: float = 2.0, *, include_obstacles_only: bool = True
    ) -> Optional[conv.LaserScan2D]:
        now = time.monotonic()
        pose = self.get_pose()
        # Merged cache includes depth; only reuse when the caller wants that.
        if (
            include_obstacles_only
            and self._scan_cache is not None
            and now - self._scan_cache_at <= max_age_s
            and self._scan_cache_pose is not None
            and pose is not None
        ):
            dtheta = abs(conv.normalize_angle(pose.theta - self._scan_cache_pose.theta))
            dist = math.hypot(
                pose.x - self._scan_cache_pose.x, pose.y - self._scan_cache_pose.y
            )
            if dtheta <= math.radians(12.0) and dist <= 0.12:
                return self._scan_cache
        if self._scan_provider is not None:
            try:
                provided = self._scan_provider(max_age_s)
            except Exception:  # noqa: BLE001
                provided = None
            if provided is not None:
                if pose is not None and provided.capture_pose is None:
                    provided = conv.LaserScan2D(
                        ranges=provided.ranges,
                        angle_min=provided.angle_min,
                        angle_increment=provided.angle_increment,
                        range_min=provided.range_min,
                        range_max=provided.range_max,
                        sensor_pose=provided.sensor_pose,
                        capture_pose=pose,
                    )
                if include_obstacles_only:
                    self._scan_cache = provided
                    self._scan_cache_at = now
                    self._scan_cache_pose = pose
                return provided
        if not self._lidars:
            # Provider miss, or no scan source at all. Same age bound as a
            # configured lidar that stops answering.
            return self._reusable_scan_cache(
                max_age_s, now, include_obstacles_only=include_obstacles_only
            )
        primary: list[conv.LaserScan2D] = []
        depth_scans: list[conv.LaserScan2D] = []
        for lidar in self._lidars:
            # Depth (obstacles_only) feeds avoidance: local costmap, DWA,
            # reactive slowing, and nose_clear. include_obstacles_only=False
            # is loc refine only — the occupancy map was built from lidar.
            if lidar.obstacles_only and not include_obstacles_only:
                continue
            scan = self._read_lidar_scan_sync(lidar, max_age_s=max_age_s)
            if scan is None:
                continue
            if pose is not None and lidar.obstacles_only:
                scan = self._align_obstacles_scan_to_pose(scan, pose)
                if scan is None:
                    continue
            if lidar.obstacles_only:
                depth_scans.append(scan)
            else:
                if pose is not None:
                    scan = self._warp_lidar_scan_to_pose(
                        scan, self._read_captured_at.get(lidar.name), pose
                    )
                primary.append(scan)
        if not primary and not depth_scans:
            return self._reusable_scan_cache(
                max_age_s, now, include_obstacles_only=include_obstacles_only
            )
        if not include_obstacles_only or not depth_scans:
            if not primary:
                # Lidar-only was requested but no primary lidar answered —
                # never fall back to depth (loc refine must not see the camera).
                return None
            merged = (
                primary[0]
                if len(primary) == 1
                else conv.merge_scans(primary, self._scan_bins)
            )
        elif not primary:
            merged = (
                depth_scans[0]
                if len(depth_scans) == 1
                else conv.merge_scans(depth_scans, self._scan_bins)
            )
        else:
            merged = (
                primary[0]
                if len(primary) == 1
                else conv.merge_scans(primary, self._scan_bins)
            )
            for depth in depth_scans:
                merged = conv.merge_lidar_and_depth_scans(
                    merged, depth, num_bins=self._scan_bins
                )
        if pose is not None:
            merged = conv.LaserScan2D(
                ranges=merged.ranges,
                angle_min=merged.angle_min,
                angle_increment=merged.angle_increment,
                range_min=merged.range_min,
                range_max=merged.range_max,
                sensor_pose=merged.sensor_pose,
                capture_pose=pose,
            )
        if include_obstacles_only:
            self._scan_cache = merged
            self._scan_cache_at = now
            self._scan_cache_pose = pose
        return merged

    def set_above_cart(
        self, enabled: bool, cart_height_m: Optional[float] = None
    ) -> None:
        """Remember depth returns that leave the vertical view.

        ``cart_height_m`` unset or <= 0 uses the camera's own band up to
        ``z_max``. A positive height keeps only returns above the cart.
        """
        self._above_cart_enabled = bool(enabled)
        try:
            height = float(cart_height_m) if cart_height_m else 0.0
        except (TypeError, ValueError):
            height = 0.0
        self._cart_height_m = (
            height if self._above_cart_enabled and height > 0.0 else 0.0
        )
        if not self._above_cart_enabled:
            self._above_cart_pts.clear()

    def get_above_cart_frames(self) -> list:
        """Latest overhead clouds as ``(stamp, xyz_base, lidar_cfg, capture_pose)``.

        ``xyz_base`` is in the robot frame at ``capture_pose``. An empty cloud
        is still returned so memory can drop a spot the camera can still see.
        """
        if not self._above_cart_enabled:
            return []
        out = []
        for lidar in self._lidars:
            if not lidar.obstacles_only:
                continue
            cached = self._per_lidar_scan.get(lidar.name)
            if cached is None or cached[0].capture_pose is None:
                continue
            pts = self._above_cart_pts.get(lidar.name)
            if pts is None:
                pts = np.empty((0, 3))
            out.append((cached[1], pts, lidar, cached[0].capture_pose))
        return out

    def get_depth_frames(self) -> list:
        """Latest ``obstacles_only`` frames as ``(stamp, scan, lidar_cfg)``.

        ``scan`` is base-frame at its own ``capture_pose`` (not warped to now)
        so the footprint guard can remember what left the camera's view.
        """
        out = []
        for lidar in self._lidars:
            if not lidar.obstacles_only:
                continue
            cached = self._per_lidar_scan.get(lidar.name)
            if cached is not None and cached[0].capture_pose is not None:
                out.append((cached[1], cached[0], lidar))
        return out

    def _map_pose_at(self, t: Optional[float]) -> Optional[conv.Pose2D]:
        """Map pose when a frame was captured; the current pose if unknown."""
        if t is not None and self._pose_at_provider is not None:
            try:
                pose = self._pose_at_provider(t)
            except Exception:  # noqa: BLE001
                pose = None
            if pose is not None:
                return pose
        return self._map_pose_now()

    def _map_pose_now(self) -> Optional[conv.Pose2D]:
        if self._pose_provider is not None:
            try:
                return self._pose_provider()
            except Exception:  # noqa: BLE001
                pass
        try:
            return self.get_pose()
        except Exception:  # noqa: BLE001
            return None

    def _stamp_capture_pose(
        self, scan: conv.LaserScan2D, pose: Optional[conv.Pose2D]
    ) -> conv.LaserScan2D:
        if pose is None:
            return scan
        return conv.LaserScan2D(
            ranges=scan.ranges,
            angle_min=scan.angle_min,
            angle_increment=scan.angle_increment,
            range_min=scan.range_min,
            range_max=scan.range_max,
            sensor_pose=scan.sensor_pose,
            capture_pose=pose,
        )

    def _align_obstacles_scan_to_pose(
        self, scan: conv.LaserScan2D, current: conv.Pose2D
    ) -> Optional[conv.LaserScan2D]:
        """Move a cached depth scan into the live base_link, or drop if too stale.

        Without this, async depth (~0.4–1 s old) is painted as if seen from the
        *current* pose — walls smear into free space and the local planner weaves.

        Important: never restamp ``capture_pose`` to ``current`` without warping
        the ranges. A prior "small motion" shortcut did that, then ``get_scan``
        stamped the merge as current — body-frame points stayed frozen while the
        pose advanced, so phantoms accumulated into a black local-costmap blob.
        """
        cap = scan.capture_pose
        if cap is None:
            # Unknown capture frame: safer to drop than invent obstacles.
            return None
        dtheta = abs(conv.normalize_angle(current.theta - cap.theta))
        dist = math.hypot(current.x - cap.x, current.y - cap.y)
        if dist > self._obstacles_max_shift_m or dtheta > self._obstacles_max_shift_rad:
            return None
        if dist < 1e-4 and dtheta < 1e-5:
            return self._stamp_capture_pose(scan, current)
        pts = scan.to_points()
        if pts.size == 0:
            return self._stamp_capture_pose(scan, current)
        pts3 = np.column_stack([pts, np.zeros(len(pts))])
        aligned = conv.transform_points_between_poses(pts3, cap, current)[:, :2]
        n_bins = int(len(scan.ranges)) if len(scan.ranges) else self._scan_bins
        rebuilt = conv.points_to_scan(
            aligned,
            angle_min=-math.pi,
            angle_max=math.pi,
            num_bins=max(n_bins, 8),
            range_min=float(scan.range_min),
            range_max=float(scan.range_max),
        )
        return self._stamp_capture_pose(rebuilt, current)

    def _warp_lidar_scan_to_pose(
        self,
        scan: conv.LaserScan2D,
        captured_at: Optional[float],
        current: conv.Pose2D,
    ) -> conv.LaserScan2D:
        """Re-express a lidar frame in the base frame at ``current``.

        The frame was taken a read latency ago. Every consumer pairs the
        merged scan with the current pose, so it is moved by the odometry
        motion since capture. Unknown capture pose or an implausible shift
        leaves the frame as read.
        """
        if captured_at is None or self._pose_at_provider is None:
            return scan
        try:
            cap = self._pose_at_provider(captured_at)
        except Exception:  # noqa: BLE001
            cap = None
        if cap is None:
            return scan
        dtheta = abs(conv.normalize_angle(current.theta - cap.theta))
        dist = math.hypot(current.x - cap.x, current.y - cap.y)
        if dist < 1e-3 and dtheta < 1e-3:
            return scan
        if dist > self._obstacles_max_shift_m or dtheta > self._obstacles_max_shift_rad:
            return scan
        pts = scan.to_points()
        if pts.size == 0:
            return scan
        pts3 = np.column_stack([pts, np.zeros(len(pts))])
        moved = conv.transform_points_between_poses(pts3, cap, current)[:, :2]
        n_bins = int(len(scan.ranges)) if len(scan.ranges) else self._scan_bins
        warped = conv.points_to_scan(
            moved,
            angle_min=-math.pi,
            angle_max=math.pi,
            num_bins=max(n_bins, 8),
            range_min=float(scan.range_min),
            range_max=float(scan.range_max),
        )
        if scan.cloud_xy is not None and len(scan.cloud_xy):
            cloud3 = np.column_stack([scan.cloud_xy, np.zeros(len(scan.cloud_xy))])
            warped.cloud_xy = np.ascontiguousarray(
                conv.transform_points_between_poses(cloud3, cap, current)[:, :2],
                dtype=float,
            )
        return warped

    def _remember_above_cart(self, raw_pts: np.ndarray, lidar: LidarConfig) -> None:
        if not lidar.obstacles_only or not self._above_cart_enabled:
            self._above_cart_pts.pop(lidar.name, None)
            return
        z_min = self._cart_height_m if self._cart_height_m > 0.0 else float(lidar.z_min)
        if z_min >= float(lidar.z_max):
            self._above_cart_pts[lidar.name] = np.empty((0, 3))
            return
        above = conv.prepare_lidar_point_cloud(
            raw_pts,
            cloud_frame=lidar.cloud_frame,
            points_in_base_link=lidar.points_in_base_link,
            x=lidar.x,
            y=lidar.y,
            z=lidar.z,
            theta=lidar.theta,
            pitch=lidar.pitch,
            roll=lidar.roll,
            z_min=z_min,
            z_max=lidar.z_max,
            max_points=2000,
            range_min=float(lidar.min_range),
            range_max=float(lidar.max_range),
            footprint_length_m=lidar.footprint_length_m,
            footprint_width_m=lidar.footprint_width_m,
            footprint_radius_m=lidar.footprint_radius_m,
        )
        self._above_cart_pts[lidar.name] = above if above.size else np.empty((0, 3))

    def _pcd_to_scan(self, raw: bytes, lidar: LidarConfig) -> conv.LaserScan2D:
        pts = conv.parse_pcd(raw)
        self._remember_above_cart(pts, lidar)
        # Depth cams are dense; crop by range/height then downsample so the
        # gRPC path (no shm) still spends its point budget on near obstacles.
        max_pts = 8000 if lidar.obstacles_only else 0
        pts = conv.prepare_lidar_point_cloud(
            pts,
            cloud_frame=lidar.cloud_frame,
            points_in_base_link=lidar.points_in_base_link,
            x=lidar.x,
            y=lidar.y,
            z=lidar.z,
            theta=lidar.theta,
            pitch=lidar.pitch,
            roll=lidar.roll,
            z_min=lidar.z_min,
            z_max=lidar.z_max,
            max_points=max_pts,
            range_min=float(lidar.min_range) if lidar.obstacles_only else 0.0,
            range_max=float(lidar.max_range) if lidar.obstacles_only else 0.0,
            footprint_length_m=lidar.footprint_length_m,
            footprint_width_m=lidar.footprint_width_m,
            footprint_radius_m=lidar.footprint_radius_m,
        )
        return conv.points_to_scan(
            pts,
            angle_min=-math.pi,
            angle_max=math.pi,
            num_bins=self._scan_bins,
            range_min=lidar.min_range,
            range_max=lidar.max_range,
        )

    def _try_shm_scan(
        self, lidar: LidarConfig, *, max_age_s: float
    ) -> Optional[conv.LaserScan2D]:
        """Sync shm read — no event-loop hop (control-loop hot path)."""
        if not lidar.shm_name or self._shm_lidar is None:
            return None
        age_limit = self._scan_max_age_s if self._scan_max_age_s > 0 else max_age_s
        got = self._shm_lidar.try_read(
            lidar.shm_name,
            lidar.shm_region_size,
            max_age_s=age_limit if age_limit > 0 else None,
        )
        if got is None:
            stats = self._shm_lidar.status().get(
                pcshm.normalize_name(lidar.shm_name), {}
            )
            detail = stats.get("last_error") or "no complete frame"
            if lidar.shm_required or _shm_error_is_stale(detail):
                self._log(
                    f"lidar {lidar.name} shm {lidar.shm_name!r} unavailable: {detail}"
                )
                return None
            self._shm_lidar.note_fallback(lidar.shm_name)
            return None
        raw, age = got
        self._read_captured_at[lidar.name] = time.monotonic() - max(0.0, float(age))
        return self._pcd_to_scan(raw, lidar)

    def _kick_obstacles_only_refresh(self, lidar: LidarConfig) -> None:
        """Schedule a non-blocking depth refresh on the module loop.

        Nav never waits for this. While ``get_point_cloud`` is awaiting network,
        ``SetVelocity`` can still run on the same loop. PCD parse runs in an
        executor so CPU work does not freeze drive commands.
        """
        name = lidar.name
        now = time.monotonic()
        if name in self._obstacles_refresh_inflight:
            slot = self._obstacles_job_gen.get(name)
            started_at = slot[1] if slot is not None else now
            if now - started_at < 5.0:
                return
            # The previous GetPointCloud never finished. Let a new one run
            # so a camera that comes back is not ignored until restart.
            self._obstacles_refresh_inflight.discard(name)
        cached = self._per_lidar_scan.get(name)
        now = time.monotonic()
        if cached is not None and now - cached[1] < self._obstacles_only_period_s:
            return
        if self._loop.is_closed():
            return
        cam = self._cameras.get(name)
        if cam is None and not lidar.shm_name:
            return
        self._obstacles_refresh_inflight.add(name)
        prev = self._obstacles_job_gen.get(name)
        gen = (prev[0] if prev is not None else 0) + 1
        self._obstacles_job_gen[name] = (gen, now)

        def _store(scan: conv.LaserScan2D, job_gen: int, captured_at: float) -> None:
            current = self._obstacles_job_gen.get(name)
            if current is None or current[0] != job_gen:
                return
            # Depth reads take 0.1–0.4 s. The pose when the read returned is
            # that far past where the camera actually was.
            self._per_lidar_scan[name] = (
                self._stamp_capture_pose(scan, self._map_pose_at(captured_at)),
                time.monotonic(),
            )

        async def _job(job_gen: int = gen) -> None:
            try:
                shm_scan = self._try_shm_scan(
                    lidar, max_age_s=max(2.0, self._obstacles_only_period_s * 2)
                )
                if shm_scan is not None:
                    _store(
                        shm_scan,
                        job_gen,
                        self._read_captured_at.get(name, time.monotonic()),
                    )
                    return
                if cam is None:
                    return
                requested_at = time.monotonic()
                data = await cam.get_point_cloud(timeout=2.0)
                raw = data[0] if isinstance(data, tuple) else data
                loop = asyncio.get_running_loop()
                scan = await loop.run_in_executor(
                    None, lambda: self._pcd_to_scan(raw, lidar)
                )
                if scan is not None:
                    _store(scan, job_gen, requested_at)
            except Exception as exc:  # noqa: BLE001
                self._log(f"obstacles_only lidar {name} refresh failed: {exc}")
            finally:
                current = self._obstacles_job_gen.get(name)
                if current is not None and current[0] == job_gen:
                    self._obstacles_refresh_inflight.discard(name)

        try:
            asyncio.run_coroutine_threadsafe(_job(), self._loop)
        except Exception:  # noqa: BLE001
            self._obstacles_refresh_inflight.discard(name)

    def _read_lidar_scan_sync(
        self, lidar: LidarConfig, *, max_age_s: float
    ) -> Optional[conv.LaserScan2D]:
        if lidar.obstacles_only:
            # Cache-only on the hot path — never block the nav worker / event loop
            # on RealSense GetPointCloud (that was starving SetVelocity → stall).
            self._kick_obstacles_only_refresh(lidar)
            cached = self._per_lidar_scan.get(lidar.name)
            if cached is None:
                return None
            scan, stamp = cached
            if max_age_s > 0.0 and time.monotonic() - float(stamp) > max_age_s:
                return None
            return scan

        # Prefer POSIX shm (memcpy) so the 10 Hz control loop never blocks on
        # gRPC GetPointCloud — that lag was causing no_scan spin / circles.
        shm_scan = self._try_shm_scan(lidar, max_age_s=max_age_s)
        if shm_scan is not None:
            return shm_scan
        if lidar.shm_name and lidar.shm_required:
            return None
        cam = self._cameras.get(lidar.name)
        if cam is None:
            return None
        return self._poll_lidar_grpc(cam, lidar)

    def _poll_lidar_grpc(self, cam, lidar: LidarConfig) -> Optional[conv.LaserScan2D]:
        """One in-flight scan RPC. A stuck call is abandoned, not piled up."""
        name = lidar.name
        now = time.monotonic()
        slot = self._lidar_futs.get(name)
        if slot is not None:
            fut, started = slot
            if fut.done():
                self._lidar_futs.pop(name, None)
                self._read_captured_at[name] = started
                try:
                    return fut.result()
                except Exception:  # noqa: BLE001
                    return None
            if now - started <= 5.0:
                return None
            _abandon_future(fut)
            self._lidar_futs.pop(name, None)
            self._log(
                f"lidar {name} scan read stuck for {now - started:.1f}s; retrying"
            )
        if self._loop.is_closed():
            return None
        try:
            fut = asyncio.run_coroutine_threadsafe(
                self._read_lidar_scan_grpc(cam, lidar), self._loop
            )
        except Exception:  # noqa: BLE001
            return None
        self._lidar_futs[name] = (fut, now)
        try:
            result = fut.result(timeout=0.05)
        except TimeoutError:
            return None
        except Exception:  # noqa: BLE001
            self._lidar_futs.pop(name, None)
            return None
        self._lidar_futs.pop(name, None)
        self._read_captured_at[name] = now
        return result

    async def _read_lidar_scan_grpc(
        self, cam, lidar: LidarConfig
    ) -> Optional[conv.LaserScan2D]:
        timeout = 1.0
        scan_source = lidar.scan_source
        name = lidar.name

        async def _from_point_cloud() -> Optional[conv.LaserScan2D]:
            data = await cam.get_point_cloud(timeout=timeout)
            raw = data[0] if isinstance(data, tuple) else data
            return self._pcd_to_scan(raw, lidar)

        async def _from_get_laser_scan() -> Optional[conv.LaserScan2D]:
            raw_payload = await cam.do_command({"command": "get_laser_scan"})
            payload = (
                struct_to_dict(raw_payload)
                if not isinstance(raw_payload, dict)
                else raw_payload
            )
            mir_pts = conv.points_from_mir_laser_scan_payload(payload)
            if mir_pts.base_link.size > 0:
                return conv.points_to_scan(
                    mir_pts.base_link,
                    angle_min=-math.pi,
                    angle_max=math.pi,
                    num_bins=self._scan_bins,
                    range_min=lidar.min_range,
                    range_max=lidar.max_range,
                )
            if mir_pts.sensor_scan is not None and conv.scan_has_returns(
                mir_pts.sensor_scan
            ):
                return mir_pts.sensor_scan
            return None

        if scan_source == LIDAR_SCAN_POINT_CLOUD or name in self._skip_get_laser_scan:
            try:
                return await _from_point_cloud()
            except Exception:  # noqa: BLE001
                return None

        if scan_source == LIDAR_SCAN_GET_LASER_SCAN:
            try:
                return await _from_get_laser_scan()
            except Exception:  # noqa: BLE001
                return None

        try:
            scan = await _from_get_laser_scan()
            if scan is not None:
                return scan
        except Exception as exc:  # noqa: BLE001
            if _get_laser_scan_not_implemented(exc):
                self._skip_get_laser_scan.add(name)
                self._log(f"lidar {name} has no get_laser_scan; using point cloud")
            else:
                self._log(f"lidar {name} get_laser_scan failed: {exc}")
        try:
            return await _from_point_cloud()
        except Exception:  # noqa: BLE001
            return None

    def set_velocity(self, vx: float, vy: float, vtheta: float) -> None:
        vx, vy, vtheta = _sanitize_base_cmd(vx, vy, vtheta)
        lx_mm, ly_mm, ang_deg_s = body_twist_to_viam_set_velocity(
            vx, vy, vtheta, self._convention
        )
        intent = {
            "body_vx_mps": vx,
            "body_vy_mps": vy,
            "body_vtheta_rad_s": vtheta,
            "viam_linear_x_mm_s": lx_mm,
            "viam_linear_y_mm_s": ly_mm,
            "viam_angular_z_deg_s": ang_deg_s,
            "base": self._base_name,
            "issued": False,
            "error": None,
        }
        desired = (vx, vy, vtheta)
        now = time.monotonic()
        if (
            desired == self._last_desired_twist
            and (now - self._last_desired_at) < self._drive_refresh_s
        ):
            # Control tick faster than meaningful cmd changes — don't pile
            # identical SetVelocity RPCs onto the module loop. Still refresh
            # periodically so base command watchdogs do not coast to a stop.
            self._drive_skipped += 1
            intent["issued"] = True
            intent["skipped"] = True
            self._last_drive = dict(intent)
            return
        self._last_desired_twist = desired
        self._last_desired_at = now

        def _make_coro():
            async def _issue_with_retry():
                try:
                    await self._base.set_velocity(
                        linear=Vector3(x=lx_mm, y=ly_mm, z=0.0),
                        angular=Vector3(x=0.0, y=0.0, z=ang_deg_s),
                    )
                    return
                except Exception as exc:  # noqa: BLE001
                    if not _is_near_zero_rpm_error(exc):
                        raise
                if vx > 0.0 and abs(vtheta) >= 0.08:
                    vx_retry = max(vx, 0.06 + 0.32 * abs(vtheta))
                    lx_mm_r, ly_mm_r, _ = body_twist_to_viam_set_velocity(
                        vx_retry, vy, vtheta, self._convention
                    )
                    intent["retry"] = {"kind": "widen_arc", "body_vx_mps": vx_retry}
                    intent["viam_linear_x_mm_s"] = lx_mm_r
                    intent["viam_linear_y_mm_s"] = ly_mm_r
                    await self._base.set_velocity(
                        linear=Vector3(x=lx_mm_r, y=ly_mm_r, z=0.0),
                        angular=Vector3(x=0.0, y=0.0, z=ang_deg_s),
                    )
                elif vx == 0.0 and abs(vtheta) >= 0.15:
                    intent["retry"] = {"kind": "spin"}
                    await self._base.set_velocity(
                        linear=Vector3(x=0.0, y=0.0, z=0.0),
                        angular=Vector3(x=0.0, y=0.0, z=ang_deg_s),
                    )
                else:
                    intent["retry"] = {"kind": "stop"}
                    await self._base.set_velocity(
                        linear=Vector3(x=0.0, y=0.0, z=0.0),
                        angular=Vector3(x=0.0, y=0.0, z=0.0),
                    )

            return _issue_with_retry()

        try:
            self._schedule_drive(
                _make_coro,
                intent,
                wait_s=self._drive_ack_timeout_s,
            )
        except TimeoutError:
            if intent.get("pending") and not intent.get("error"):
                # Command is still queued on the module loop; do not fail the tick.
                self._log(
                    f"SetVelocity ack slow on base {self._base_name!r} "
                    f"(loop busy; leaving command pending)"
                )
                return
            raise
        except Exception as exc:  # noqa: BLE001
            # Allow a retry of the same twist after a hard failure.
            self._last_desired_twist = None
            self._log(
                f"SetVelocity failed on base {self._base_name!r}: "
                f"{str(exc).strip() or type(exc).__name__}"
            )
            raise

    def stop(self) -> None:
        """Zero the base without blocking the control thread on a busy loop."""
        # Shares skip-duplicate + coalesce paths with set_velocity so loc_hold /
        # succeed / cancel do not re-issue SetVelocity(0) every tick.
        self.set_velocity(0.0, 0.0, 0.0)

    def set_viz_plan(
        self,
        path_xy: tuple,
        goal: Optional[tuple] = None,
    ) -> None:
        if self._viz is None:
            return
        self._viz.set_plan(path_xy, goal)

    def set_viz_costmap(self, costmap: dict) -> None:
        if self._viz is None:
            return
        self._viz.set_costmap(costmap)

    def set_viz_local_costmap(self, costmap: dict) -> None:
        if self._viz is None:
            return
        self._viz.set_local_costmap(costmap)

    def get_localization_hold(self) -> Optional[dict]:
        provider = self._localization_hold_provider
        if provider is None:
            return None
        try:
            hold = provider()
        except Exception:  # noqa: BLE001 - never block drive on status read
            return None
        return hold if isinstance(hold, dict) else None

    def get_localization_check(self) -> Optional[dict]:
        provider = self._localization_check_provider
        if provider is None:
            return None
        try:
            check = provider()
        except Exception:  # noqa: BLE001 - never block drive on status read
            return None
        return check if isinstance(check, dict) else None

    def slam_mode(self) -> Optional[str]:
        """``mapping`` or ``localizing`` from the in-process SLAM service."""
        slam = self._slam
        fn = getattr(slam, "slam_mode", None)
        if not callable(fn):
            return None
        try:
            mode = fn()
        except Exception:  # noqa: BLE001
            return None
        return str(mode) if mode else None

    def check_localization(
        self,
        *,
        allow_during_navigation: bool = True,
        full_map_escalation: str = "still_bad",
        apply: Optional[bool] = None,
        stopped_recovery: bool = False,
    ) -> Optional[dict]:
        """Run one SLAM local refine from the nav worker thread.

        ``allow_during_navigation`` bypasses the mid-nav skip without forcing
        apply, and keeps the cycle local (no hallway full-map search).
        ``stopped_recovery`` widens the search / allows a trusted larger apply
        while the base is already halted for bad loc.
        """
        slam = self._slam
        if slam is None or not hasattr(slam, "do_command"):
            return {"status": "unconfigured"}
        cmd = {
            "command": "check_localization",
            "full_map_escalation": str(full_map_escalation or "still_bad"),
            "allow_during_navigation": bool(allow_during_navigation),
            "stopped_recovery": bool(stopped_recovery),
        }
        if apply is not None:
            cmd["apply"] = bool(apply)
        # Full-map recovery can take longer than a local peel.
        timeout = 45.0 if stopped_recovery else 20.0
        return self._run(slam.do_command(cmd), timeout=timeout)

    def refine_stuck_pose(self) -> Optional[dict]:
        """Local scan match (~1 m) while the base is stopped on an unreachable start.

        Works in mapping and localizing. The match itself refuses a hallway jump.
        """
        slam = self._slam
        if slam is None or not hasattr(slam, "do_command"):
            return {"status": "unconfigured", "corrected": False}
        return self._run(
            slam.do_command({"command": "stuck_pose_refine"}),
            timeout=20.0,
        )


def _sanitize_base_cmd(
    vx: float, vy: float, vtheta: float
) -> tuple[float, float, float]:
    """Snap sub-deadband speeds to zero so Viam wheeled bases don't reject RPM.

    Diff-drive with tiny ``vx`` + large ``vtheta`` also drives one wheel through
    ~0 RPM — prefer pure spin in that case. Numbers live in ``base_envelope``.
    """
    from ..motion.base_envelope import sanitize_base_cmd

    return sanitize_base_cmd(vx, vy, vtheta)


def _is_near_zero_rpm_error(exc: BaseException) -> bool:
    msg = str(exc).lower()
    return "nearly 0" in msg or "rpm that is nearly" in msg
