"""Inflated costmap from an occupancy grid (pure numpy, no ROS)."""

from __future__ import annotations

import math
from typing import Optional, Tuple

import numpy as np

from ...geom import conversions as conv
from ..types import OccupancyGrid

# Cost layers (uint8): 0 free … 251 soft, 252 hard buffer, 253 inscribed
# (body), 254 lethal, 255 unknown. HARD_BUFFER and INSCRIBED are both
# non-traversable; they exist so viz can draw body vs clearance as two rings.
LETHAL = 254
INSCRIBED = 253
HARD_BUFFER = 252
UNKNOWN = 255
FREE = 0


def scan_world_points(
    pose: conv.Pose2D,
    scan: conv.LaserScan2D,
    *,
    max_beams: int = 360,
) -> np.ndarray:
    """Map-frame XY hits from a lidar scan (finite ranges only).

    Points are placed from the pose the scan was captured at when it carries
    one; ``pose`` is only the fallback.
    """
    pts = scan.to_points()
    if pts.size == 0:
        return np.zeros((0, 2), dtype=np.float64)
    if max_beams > 0 and pts.shape[0] > max_beams:
        pick = np.linspace(0, pts.shape[0] - 1, max_beams, dtype=np.int32)
        pts = pts[pick]
    frame = scan.capture_pose if scan.capture_pose is not None else pose
    cth = math.cos(frame.theta)
    sth = math.sin(frame.theta)
    wx = frame.x + cth * pts[:, 0] - sth * pts[:, 1]
    wy = frame.y + sth * pts[:, 0] + cth * pts[:, 1]
    finite = np.isfinite(wx) & np.isfinite(wy)
    return np.column_stack([wx[finite], wy[finite]])


def mark_points_on_occupancy(
    occ: OccupancyGrid,
    points: np.ndarray,
    *,
    radius_m: float,
) -> OccupancyGrid:
    """Mark occupied disks at world-frame points (for dynamic replanning)."""
    grid = occ.grid.copy()
    if points.size == 0:
        return OccupancyGrid(
            grid=grid,
            resolution=occ.resolution,
            origin_x=occ.origin_x,
            origin_y=occ.origin_y,
        )
    # Radius 0 marks only the point's own cell.
    cells = max(0, int(math.ceil(float(radius_m) / occ.resolution)))
    dy, dx = _disk_offsets(cells)
    for wx, wy in points:
        row, col = occ.world_to_cell(float(wx), float(wy))
        for ody, odx in zip(dy, dx):
            rr, cc = row + int(ody), col + int(odx)
            if occ.in_bounds(rr, cc):
                grid[rr, cc] = 100
    return OccupancyGrid(
        grid=grid,
        resolution=occ.resolution,
        origin_x=occ.origin_x,
        origin_y=occ.origin_y,
    )


def mark_local_costmap_on_occupancy(
    occ: OccupancyGrid,
    view,
    *,
    occupied_threshold: int = 50,
    radius_m: float = 0.08,
    max_points: int = 400,
) -> OccupancyGrid:
    """Paint novel raw local scan hits onto global occupancy for replanning.

    Scan-only marking can miss the blob that already tripped ``path_cost_ahead``
    (timing or a cached local view). Do not copy ``view.costs``: that layer also
    contains the already-inflated global map, and painting it as raw occupancy
    inflates static walls a second time and can falsely block the goal.
    """
    raw = np.asarray(view.occ.grid)
    ys, xs = np.nonzero(raw >= int(occupied_threshold))
    if ys.size == 0:
        return occ
    if ys.size > max_points:
        pick = np.linspace(0, ys.size - 1, max_points, dtype=np.int32)
        ys = ys[pick]
        xs = xs[pick]
    res = float(view.occ.resolution)
    wx = view.origin_x + (xs.astype(np.float64) + 0.5) * res
    wy = view.origin_y + (ys.astype(np.float64) + 0.5) * res
    # Lidar returns from mapped walls are not dynamic obstacles. The static
    # occupancy is already present and will be inflated exactly once below.
    novel: list[tuple[float, float]] = []
    for x, y in zip(wx, wy):
        row, col = occ.world_to_cell(float(x), float(y))
        if not occ.in_bounds(row, col):
            continue
        if int(occ.grid[row, col]) >= int(occupied_threshold):
            continue
        novel.append((float(x), float(y)))
    if not novel:
        return occ
    return mark_points_on_occupancy(
        occ, np.asarray(novel, dtype=np.float64), radius_m=radius_m
    )


def mark_path_block_from_local(
    occ: OccupancyGrid,
    path,
    pose,
    view,
    *,
    cost_threshold: int = 200,
    margin_m: float = 0.0,
    radius_m: float = 0.25,
    lookahead_m: float = 1.5,
    start_offset_m: float = 0.3,
    end_offset_m: float = 0.45,
    sample_step_m: float = 0.08,
) -> OccupancyGrid:
    """Seal path samples that the local costmap already flags as blocked.

    Corridor paint alone can be too thin / offset; copying every local inscribed
    cell can still leave a Lazy Theta* corridor within 25 cm of the old route
    (``same route``). Marking the blocked *path samples* with a fat disk forces
    a real peel.
    """
    from .local_costmap import max_cost_along_segment
    from .path_utils import closest_point_on_path

    pts = path.points
    if len(pts) < 2:
        return occ
    _, _, _, along = closest_point_on_path(pose, path)
    along += max(0.0, float(start_offset_m))
    seg_lens: list[float] = []
    cum = [0.0]
    for i in range(len(pts) - 1):
        length = math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
        seg_lens.append(length)
        cum.append(cum[-1] + length)
    total = cum[-1]
    target = min(
        max(0.0, total - max(0.0, float(end_offset_m))),
        along + max(float(lookahead_m), sample_step_m),
    )
    if target < along:
        return occ
    step = max(float(sample_step_m), occ.resolution * 0.5)
    blocked_pts: list[tuple[float, float]] = []
    d = max(0.0, along)
    while d <= target + 1e-9:
        for i in range(len(pts) - 1):
            if cum[i + 1] + 1e-9 < d:
                continue
            seg = seg_lens[i]
            t = 0.0 if seg < 1e-9 else (d - cum[i]) / seg
            t = max(0.0, min(1.0, t))
            x = pts[i][0] + t * (pts[i + 1][0] - pts[i][0])
            y = pts[i][1] + t * (pts[i + 1][1] - pts[i][1])
            c = max_cost_along_segment(view, x, y, x, y, margin_m=margin_m)
            if c >= cost_threshold:
                blocked_pts.append((x, y))
            break
        d += step
    if not blocked_pts:
        return occ
    return mark_points_on_occupancy(
        occ, np.asarray(blocked_pts, dtype=np.float64), radius_m=radius_m
    )


def mark_scan_on_occupancy(
    occ: OccupancyGrid,
    pose: conv.Pose2D,
    scan: conv.LaserScan2D,
    *,
    obstacle_radius_m: float = 0.05,
    occupied_threshold: int = 50,
) -> OccupancyGrid:
    """Copy ``occ`` with live scan hits marked occupied (for dynamic replanning).

    Hits that already land on mapped occupied cells are skipped so static walls
    are not painted again before ``build_costmap`` inflation (which would seal
    narrow gaps). ``obstacle_radius_m`` is hit thickness only — inflation is
    applied separately by ``build_costmap``.
    """
    hits = scan_world_points(pose, scan)
    if hits.size == 0:
        return occ
    novel = []
    for wx, wy in hits:
        row, col = occ.world_to_cell(float(wx), float(wy))
        if not occ.in_bounds(row, col):
            continue
        if int(occ.grid[row, col]) >= occupied_threshold:
            continue
        novel.append((float(wx), float(wy)))
    if not novel:
        return occ
    return mark_points_on_occupancy(
        occ, np.asarray(novel, dtype=np.float64), radius_m=obstacle_radius_m
    )


def mark_path_ahead_on_occupancy(
    occ: OccupancyGrid,
    path,
    pose,
    *,
    radius_m: float,
    lookahead_m: float = 2.5,
    sample_step_m: float = 0.08,
    start_offset_m: float = 0.0,
    end_offset_m: float = 0.45,
) -> OccupancyGrid:
    """Mark the current route segment ahead of the robot so replans must detour.

    ``start_offset_m`` skips the first stretch of route so the robot's own
    footprint is not painted lethal (which forced the start to snap sideways
    and made every retry infeasible in tighter rooms).
    """
    from .path_utils import closest_point_on_path

    pts = path.points
    if len(pts) < 2:
        return occ
    _, _, _, along = closest_point_on_path(pose, path)
    along += max(0.0, float(start_offset_m))
    seg_lens: list[float] = []
    cum = [0.0]
    for i in range(len(pts) - 1):
        length = math.hypot(pts[i + 1][0] - pts[i][0], pts[i + 1][1] - pts[i][1])
        seg_lens.append(length)
        cum.append(cum[-1] + length)
    total = cum[-1]
    target_end = min(
        max(0.0, total - max(0.0, float(end_offset_m))),
        along + max(float(lookahead_m), sample_step_m),
    )
    if target_end < along:
        return occ
    samples: list[tuple[float, float]] = []
    step = max(float(sample_step_m), occ.resolution * 0.5)
    d = max(0.0, along)
    while d <= target_end + 1e-9:
        for i in range(len(pts) - 1):
            if cum[i + 1] + 1e-9 < d:
                continue
            seg = seg_lens[i]
            if seg < 1e-9:
                t = 0.0
            else:
                t = (d - cum[i]) / seg
            t = max(0.0, min(1.0, t))
            x = pts[i][0] + t * (pts[i + 1][0] - pts[i][0])
            y = pts[i][1] + t * (pts[i + 1][1] - pts[i][1])
            samples.append((x, y))
            break
        d += step
    if not samples:
        return occ
    arr = np.asarray(samples, dtype=np.float64)
    return mark_points_on_occupancy(occ, arr, radius_m=radius_m)


def occupancy_from_map_dict(map_data: dict) -> OccupancyGrid:
    """Build OccupancyGrid from a get_map-style dict (grid + origin + resolution)."""
    grid = np.asarray(map_data["grid"], dtype=np.int16)
    if grid.ndim != 2:
        raise ValueError(f"occupancy grid must be 2D, got shape {grid.shape}")
    return OccupancyGrid(
        grid=grid,
        resolution=float(map_data["resolution"]),
        origin_x=float(map_data["origin_x"]),
        origin_y=float(map_data["origin_y"]),
    )


_DISK_OFFSET_CACHE: dict[int, Tuple[np.ndarray, np.ndarray]] = {}
_RING_OFFSET_CACHE: dict[int, Tuple[np.ndarray, np.ndarray]] = {}


def _disk_offsets(radius_cells: int) -> Tuple[np.ndarray, np.ndarray]:
    """Cached (dy, dx) offsets for a filled disk of ``radius_cells``."""
    r = int(radius_cells)
    cached = _DISK_OFFSET_CACHE.get(r)
    if cached is not None:
        return cached
    if r <= 0:
        out = (
            np.array([0], dtype=np.int32),
            np.array([0], dtype=np.int32),
        )
    else:
        ys, xs = [], []
        r2 = r * r
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if dx * dx + dy * dy <= r2:
                    ys.append(dy)
                    xs.append(dx)
        out = (np.asarray(ys, dtype=np.int32), np.asarray(xs, dtype=np.int32))
    _DISK_OFFSET_CACHE[r] = out
    return out


def _ring_offsets(radius_cells: int) -> Tuple[np.ndarray, np.ndarray]:
    """Cached Chebyshev ring offsets: ``max(|dy|, |dx|) == radius_cells``."""
    r = int(radius_cells)
    cached = _RING_OFFSET_CACHE.get(r)
    if cached is not None:
        return cached
    if r <= 0:
        out = (
            np.array([0], dtype=np.int32),
            np.array([0], dtype=np.int32),
        )
    else:
        ys, xs = [], []
        for dy in range(-r, r + 1):
            for dx in range(-r, r + 1):
                if max(abs(dy), abs(dx)) == r:
                    ys.append(dy)
                    xs.append(dx)
        out = (np.asarray(ys, dtype=np.int32), np.asarray(xs, dtype=np.int32))
    _RING_OFFSET_CACHE[r] = out
    return out


_FAR_CELLS = 1_000_000.0


def _limited_cell_distance(seed: np.ndarray, max_r: int) -> np.ndarray:
    """Euclidean centre-to-centre distance (cells) to the nearest True seed.

    Cells farther than ``max_r`` stay at ``_FAR_CELLS``. The distance is not
    rounded up: a ``ceil`` here, compared against a radius that was also
    rounded up to whole cells, kept up to one extra cell of keep-out on each
    wall and closed gaps 10 cm narrower than the configured footprint.
    The passes are numpy ufuncs, so a full-map rebuild does not hold the GIL
    the way a Python ring loop does — that stall was hitching the nav loop
    every time mapping bumped the costmap.
    """
    seed = np.asarray(seed, dtype=bool)
    h, w = seed.shape
    dist = np.full((h, w), _FAR_CELLS, dtype=np.float64)
    if max_r <= 0 or not seed.any():
        dist[seed] = 0.0
        return dist
    cap = int(max_r) * int(max_r)
    inf = cap + 1
    vert = np.full((h, w), inf, dtype=np.int32)
    vert[seed] = 0
    for dy in range(1, min(int(max_r), h - 1) + 1):
        d2 = dy * dy
        np.minimum(vert[dy:, :], d2, out=vert[dy:, :], where=seed[:-dy, :])
        np.minimum(vert[:-dy, :], d2, out=vert[:-dy, :], where=seed[dy:, :])
    # Horizontal reads the original column distances. In-place on ``vert``
    # would mix already-shifted columns into later offsets.
    best = vert.copy()
    for dx in range(1, min(int(max_r), w - 1) + 1):
        d2 = dx * dx
        np.minimum(best[:, dx:], vert[:, :-dx] + d2, out=best[:, dx:])
        np.minimum(best[:, :-dx], vert[:, dx:] + d2, out=best[:, :-dx])
    near = best <= cap
    if near.any():
        dist[near] = np.sqrt(best[near].astype(np.float64))
    return dist


def _ring_cell_distance(seed: np.ndarray, max_r: int) -> np.ndarray:
    """Same distances as ``_limited_cell_distance``, walked in Python.

    This is the localization path. Mapping uses the numpy field so a full-map
    rebuild does not freeze the control loop.
    """
    seed = np.asarray(seed, dtype=bool)
    h, w = seed.shape
    dist = np.full((h, w), _FAR_CELLS, dtype=np.float64)
    seed_y, seed_x = np.nonzero(seed)
    if seed_y.size:
        dist[seed_y, seed_x] = 0.0
    if max_r <= 0 or seed_y.size == 0:
        return dist
    r = int(max_r)
    cap = r * r
    offsets = [
        (dy * dy + dx * dx, dy, dx)
        for dy in range(-r, r + 1)
        for dx in range(-r, r + 1)
        if 0 < dy * dy + dx * dx <= cap
    ]
    offsets.sort()
    for d2, dy, dx in offsets:
        d = math.sqrt(d2)
        yy = seed_y + dy
        xx = seed_x + dx
        valid = (yy >= 0) & (yy < h) & (xx >= 0) & (xx < w)
        yy, xx = yy[valid], xx[valid]
        closer = dist[yy, xx] > d
        dist[yy[closer], xx[closer]] = d
    return dist


# Soft costs at/above this are shown as inflation in nav-camera / UI.
# Lower costs are planner-only clearance preference (invisible halo).
_VIZ_SOFT_MIN = 50
# Preference band past inflation. Kept above planner LOS soft cap so any-angle
# / string-pull cannot shortcut through it — that is what stops corner hugs.
# (8-connected search can still walk preference cells when no clear detour.)
_PREF_COST_HI = 48
_PREF_COST_LO = 32


def build_costmap(
    occ: OccupancyGrid,
    *,
    inflation_radius_m: float,
    robot_radius_m: float = 0.0,
    body_radius_m: Optional[float] = None,
    occupied_threshold: int = 50,
    cost_scaling_factor: float = 4.0,
    clearance_preference_m: float = 0.35,
    mapping: bool = False,
) -> np.ndarray:
    """Return (H, W) uint8 costmap.

    Occupied / unknown cells become lethal. Cells within ``robot_radius_m`` of
    a lethal cell are a hard (non-traversable) C-space disk (body + clearance).
    When ``body_radius_m`` is set and smaller than that, the disk is split for
    viz only: ``clearance_m`` from the wall → hard buffer (drawn), the rest of
    the disk → inscribed (hidden so corridors read as workspace). Both stay
    blocked for planning. Between the hard disk and
    ``max(inflation_radius_m, robot_radius_m)`` soft costs decay with clearance
    past the hard radius (Nav2-style).

    Soft outer radius matches configured ``inflation_radius_m`` (clamped to at
    least the hard disk) — that is what UIs show. An additional low-cost
    ``clearance_preference_m`` band past inflation biases planning toward open
    space when a detour exists; it is not drawn as inflation (see
    ``costs_to_occupancy_viz``). Preference costs sit above the planner LOS soft
    cap so Lazy Theta* / string-pull stay outside that band when clear space
    exists (narrow gaps remain solvable via 8-connected steps).
    """
    h, w = occ.height, occ.width
    costs = np.full((h, w), FREE, dtype=np.uint8)

    raw = occ.grid
    lethal_mask = (raw >= occupied_threshold) | (raw < 0)
    costs[lethal_mask] = LETHAL
    costs[raw < 0] = UNKNOWN  # unknown stays unknown; planner treats as lethal

    res = max(float(occ.resolution), 1e-6)
    # Hard block = body + clearance (robot_radius_m). Soft halo starts outside.
    inscribed_m = max(0.0, float(robot_radius_m))
    if body_radius_m is None:
        body_m = inscribed_m
    else:
        body_m = min(max(0.0, float(body_radius_m)), inscribed_m)
    inflate_m = max(float(inflation_radius_m), inscribed_m)
    prefer_m = max(0.0, float(clearance_preference_m))
    prefer_outer_m = inflate_m + prefer_m
    inscribed_cells = max(0, int(math.ceil(inscribed_m / res)))
    inflate_cells = max(
        inscribed_cells,
        max(0, int(math.ceil(inflate_m / res))),
    )
    prefer_cells = max(
        inflate_cells,
        max(0, int(math.ceil(prefer_outer_m / res))),
    )
    if inscribed_cells == 0 and inflate_cells == 0 and prefer_cells == 0:
        return costs

    # Seed from occupied (not unknown-only) so unknown voids don't inflate.
    seed = (raw >= occupied_threshold).astype(np.uint8)
    if not seed.any():
        return costs

    max_r = max(prefer_cells, inflate_cells, inscribed_cells)
    # Numpy field only while mapping. Localization keeps the ring dilation.
    if mapping:
        dist = _limited_cell_distance(seed.astype(bool), max_r)
    else:
        dist = _ring_cell_distance(seed, max_r)

    # Apply inflation costs on free cells (vectorized). Distances are compared
    # in metres against the configured radii, not in rounded-up cells.
    dist_all_m = dist * res
    eps = 1e-9
    free = costs == FREE
    within_soft = free & (dist_all_m <= inflate_m + eps)
    if within_soft.any():
        hard = within_soft & (dist_all_m <= inscribed_m + eps)
        if hard.any():
            # Workspace band = clearance past the wall (hard − body). The
            # remaining C-space (body inflation) stays blocked but is not drawn.
            clearance_m = max(0.0, inscribed_m - body_m)
            if clearance_m > 1e-9 and clearance_m < inscribed_m - eps:
                workspace = hard & (dist_all_m <= clearance_m + eps)
                costs[workspace] = HARD_BUFFER
                cspace = hard & ~workspace
                if cspace.any():
                    costs[cspace] = INSCRIBED
            else:
                costs[hard] = INSCRIBED
        soft = within_soft & ~hard
        if soft.any():
            dist_m = dist_all_m[soft]
            # Nav2-style: decay with clearance past the hard radius so the
            # outer soft edge stays meaningful and paths prefer open space.
            clearance_m = np.maximum(0.0, dist_m - inscribed_m)
            soft_costs = np.rint(
                (HARD_BUFFER - 1) * np.exp(-cost_scaling_factor * clearance_m)
            ).astype(np.int32)
            costs[soft] = np.clip(soft_costs, 1, HARD_BUFFER - 1).astype(np.uint8)

    # Planner-only preference past inflation (not shown in costmap viz).
    if prefer_m > 1e-6:
        prefer = (
            free & (dist_all_m > inflate_m + eps) & (dist_all_m <= prefer_outer_m + eps)
        )
        if prefer.any():
            dist_m = dist_all_m[prefer]
            # 0 at inflation edge → 1 at preference outer.
            frac = np.clip((dist_m - inflate_m) / prefer_m, 0.0, 1.0)
            pref_costs = np.rint(
                _PREF_COST_HI - (_PREF_COST_HI - _PREF_COST_LO) * frac
            ).astype(np.int32)
            costs[prefer] = np.clip(pref_costs, _PREF_COST_LO, _PREF_COST_HI).astype(
                np.uint8
            )

    return costs


def is_hard(cost: int) -> bool:
    """True for body, hard clearance, lethal, or unknown (non-traversable)."""
    return int(cost) >= HARD_BUFFER


def is_traversable(cost: int, *, allow_unknown: bool = False) -> bool:
    if cost >= LETHAL:
        return False
    if cost == UNKNOWN:
        return allow_unknown
    if is_hard(cost):
        return False
    return True


# OccupancyGrid-style values the nav-camera colours. Soft is kept at 1..80 so
# 90 stays reserved for the hard clearance ring (distinct from optional soft).
_VIZ_HARD_BUFFER = 90
_VIZ_SOFT_MAX = 80


def costs_to_occupancy_viz(costs: np.ndarray) -> np.ndarray:
    """Convert layered uint8 costs to OccupancyGrid-style int16 for nav-camera.

    Nav2 / nav_view colouring expects: -1 unknown, 0 free, 1..80 optional soft
    inflation, 90 hard clearance (workspace keep-out next to walls), 99
    inscribed (only when the hard disk was not split), 100 lethal.

    The C-space body disk (``INSCRIBED`` next to a ``HARD_BUFFER`` ring) renders
    as free so a corridor shows ``clearance_m`` of keep-out, not body+clearance.
    Planning still treats both as blocked.

    Planner-only clearance preference costs (below ``_VIZ_SOFT_MIN``) render as
    free so the UI inflation ring matches ``inflation_radius``.
    """
    c = np.asarray(costs)
    out = np.zeros(c.shape, dtype=np.int16)
    out[c == FREE] = 0
    out[c == UNKNOWN] = -1
    out[c == LETHAL] = 100
    # Hide C-space body inflation when the workspace clearance ring is present.
    hide_cspace = bool(np.any(c == HARD_BUFFER))
    out[c == INSCRIBED] = 0 if hide_cspace else 99
    out[c == HARD_BUFFER] = _VIZ_HARD_BUFFER
    mid = (c >= _VIZ_SOFT_MIN) & (c < HARD_BUFFER)
    if mid.any():
        # Map viz soft → 1..80 (leave 90 free for the hard-buffer ring).
        scaled = np.clip(
            np.rint(
                c[mid].astype(np.float32)
                * (float(_VIZ_SOFT_MAX) / float(HARD_BUFFER - 1))
            ),
            1,
            _VIZ_SOFT_MAX,
        ).astype(np.int16)
        out[mid] = scaled
    return out


def costmap_viz_dict(
    occ: OccupancyGrid,
    costs: np.ndarray,
) -> dict:
    """Bridge-style map dict the nav-camera can render as an inflated costmap."""
    return {
        "grid": costs_to_occupancy_viz(costs),
        "resolution": float(occ.resolution),
        "origin_x": float(occ.origin_x),
        "origin_y": float(occ.origin_y),
    }


def local_view_viz_dict(view) -> dict:
    """Rolling local costmap for operator UIs (already in map frame)."""
    return {
        "grid": costs_to_occupancy_viz(view.costs),
        "resolution": float(view.occ.resolution),
        "origin_x": float(view.origin_x),
        "origin_y": float(view.origin_y),
    }


def nearest_free_cell(
    costs: np.ndarray,
    row: int,
    col: int,
    *,
    max_radius_cells: int = 40,
) -> Optional[Tuple[int, int]]:
    """Find a traversable cell near ``(row, col)`` (inclusive of itself).

    On the first ring that has a free cell, pick the Euclidean-closest one so
    a wall-side dock snaps toward open space, not along the wall.
    """
    h, w = costs.shape
    if 0 <= row < h and 0 <= col < w and is_traversable(int(costs[row, col])):
        return row, col
    for r in range(1, max_radius_cells + 1):
        dys, dxs = _ring_offsets(r)
        rows = row + dys
        cols = col + dxs
        inb = (rows >= 0) & (rows < h) & (cols >= 0) & (cols < w)
        if not inb.any():
            continue
        rr = rows[inb]
        cc = cols[inb]
        free = np.asarray(costs)[rr, cc] < HARD_BUFFER
        if not free.any():
            continue
        rr = rr[free]
        cc = cc[free]
        rdy = dys[inb][free]
        rdx = dxs[inb][free]
        i = int(np.argmin(rdy * rdy + rdx * rdx))
        return int(rr[i]), int(cc[i])
    return None


def footprint_max_cost(
    costs: np.ndarray,
    occ: OccupancyGrid,
    x_m: float,
    y_m: float,
    *,
    robot_radius_m: float,
) -> int:
    """Maximum layered cost under a circular robot footprint."""
    res = occ.resolution
    cells = max(1, int(math.ceil(float(robot_radius_m) / res)))
    row, col = occ.world_to_cell(x_m, y_m)
    h, w = costs.shape
    dys, dxs = _disk_offsets(cells)
    rows = row + dys
    cols = col + dxs
    if ((rows < 0) | (rows >= h) | (cols < 0) | (cols >= w)).any():
        return LETHAL
    return int(np.asarray(costs)[rows, cols].max())


def footprint_traversable(
    costs: np.ndarray,
    occ: OccupancyGrid,
    x_m: float,
    y_m: float,
    *,
    robot_radius_m: float,
) -> bool:
    """True when the full robot disk at ``(x_m, y_m)`` is traversable."""
    return is_traversable(
        footprint_max_cost(costs, occ, x_m, y_m, robot_radius_m=robot_radius_m)
    )


def nearest_free_pose(
    costs: np.ndarray,
    occ: OccupancyGrid,
    x_m: float,
    y_m: float,
    *,
    robot_radius_m: float,
    max_radius_cells: int = 40,
) -> Optional[Tuple[float, float]]:
    """Find a nearby pose whose full footprint is traversable."""
    if footprint_traversable(costs, occ, x_m, y_m, robot_radius_m=robot_radius_m):
        return x_m, y_m
    row, col = occ.world_to_cell(x_m, y_m)
    h, w = costs.shape
    for r in range(1, max_radius_cells + 1):
        dys, dxs = _ring_offsets(r)
        for dy, dx in zip(dys.tolist(), dxs.tolist()):
            yy, xx = row + int(dy), col + int(dx)
            if not (0 <= yy < h and 0 <= xx < w):
                continue
            wx, wy = occ.cell_to_world(yy, xx)
            if footprint_traversable(costs, occ, wx, wy, robot_radius_m=robot_radius_m):
                return wx, wy
    return None
